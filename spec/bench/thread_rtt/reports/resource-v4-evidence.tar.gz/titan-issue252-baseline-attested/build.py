import datetime, hashlib, json, os, pathlib, subprocess, sys, time
root = pathlib.Path('/tmp/titan-issue252-baseline-attested')
source = root / 'source'
sdk = root / 'sdk'
logs = root / 'logs'
logs.mkdir(exist_ok=True)
env = os.environ.copy()
for key in ('ROCKS_TREE','TITAN_ROCKS_ROOT','TITAN_EXTRA_CPPFLAGS','TITAN_EXTRA_CFLAGS','TITAN_EXTRA_LDFLAGS','TITAN_NO_LINE_DIRECTIVES','LUA_PATH','LUA_CPATH','LUA_PATH_5_5','LUA_CPATH_5_5'):
    env.pop(key, None)
env.update(PREFIX=str(sdk), PATH=f'{sdk}/bin:/var/home/linuxbrew/.linuxbrew/bin:/usr/local/bin:/usr/bin:/bin', TITAN_BUILD_PROFILE='production', OPENSSL_MODE='system', OPENSSL_PKG_CONFIG='/usr/bin/pkg-config', TITAN_ABI_VERSION='2', TITAN_JOBS='4', MAKEFLAGS='-j4', CC='/usr/bin/gcc', AR='/usr/bin/ar', RANLIB='/usr/bin/ranlib')
selected = {key: env[key] for key in ('PREFIX','PATH','TITAN_BUILD_PROFILE','OPENSSL_MODE','OPENSSL_PKG_CONFIG','TITAN_ABI_VERSION','TITAN_JOBS','MAKEFLAGS','CC','AR','RANLIB')}
records = []
def run(name, argv, cwd):
    log = logs / (name + '.log')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    print(f'RUN {name}: {argv}', flush=True)
    with log.open('wb') as stream:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT)
    record = dict(name=name, argv=argv, cwd=str(cwd), env=selected, started=started, elapsed_seconds=time.monotonic()-clock, returncode=result.returncode, log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    records.append(record)
    (root/'BUILD-COMMANDS.json').write_text(json.dumps(records, indent=2, sort_keys=True)+'\n')
    print(f'END {name}: status={result.returncode}, seconds={record["elapsed_seconds"]:.3f}, log={log}', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
run('prepare-luarocks', ['/usr/bin/make','luarocks'], source)
original_rocks = '/tmp/titan-handoff-production-sdk-20261017/bin/luarocks'
for package, version in (('lpeglabel','1.6.2-1'),('inspect','3.1.3-0'),('argparse','0.7.2-1'),('luafilesystem','1.9.0-1')):
    run('pack-'+package, [original_rocks,'--tree=/tmp/titan-handoff-production-sdk-20261017','pack',package,version], root/'dependency-rocks')
    rocks = list((root/'dependency-rocks').glob(package+'-'+version+'.*.rock'))
    if len(rocks) != 1:
        raise RuntimeError(f'Expected exactly one packed dependency for {package}: {rocks}')
    run('install-'+package, [str(sdk/'bin/luarocks'),'install',str(rocks[0]),'--deps-mode=none'], source)
run('build-original-provider', [str(sdk/'bin/luarocks'),'make','--force','--deps-mode=none','titan-0.6.0-1.rockspec'], source)
before = json.loads((root/'SOURCE-BEFORE.json').read_text())
after = {rel: hashlib.sha256((source/rel).read_bytes()).hexdigest() for rel in before}
(root/'SOURCE-AFTER.json').write_text(json.dumps(after, indent=2, sort_keys=True)+'\n')
changed = [rel for rel in before if before[rel] != after[rel]]
if changed:
    raise RuntimeError(f'Build modified authored baseline inputs: {changed}')
(root/'BUILD-ATTESTATION.json').write_text(json.dumps(dict(source_archives=json.loads((root/'SOURCE-ARCHIVES.json').read_text()), source_before=str(root/'SOURCE-BEFORE.json'), source_after=str(root/'SOURCE-AFTER.json'), authored_inputs_unchanged=True, authored_file_count=len(before), build_commands=str(root/'BUILD-COMMANDS.json'), completed=datetime.datetime.now(datetime.timezone.utc).isoformat(), sdk=str(sdk)), indent=2, sort_keys=True)+'\n')
print(f'ATTESTED original provider built from {len(before)} unchanged authored inputs: {sdk}', flush=True)
