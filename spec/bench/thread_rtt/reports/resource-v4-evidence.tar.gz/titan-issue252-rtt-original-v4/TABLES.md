# Cross-thread RTT and component evidence

### Measured checkpoint provenance

| Input | Recorded evidence |
|---|---|
| ABI / SDK / language-server API | `2 / 0.6 / 1 (compile guard)` |
| Claimed source revision (builder-attested, not inferred) | `66d1aad63885246b42107b1131f1656a0386cc8b` |
| SDK profile | `production` |
| Complete generated-C flags (including optimization / LTO / debug) | `--std=c99 -O3 -Wall -Wno-unused-but-set-variable -Wno-unused-function -fPIC -g1 -flto=auto -ffat-lto-objects -fno-strict-aliasing` |
| Generated-C source-line directives | `True` |
| Full SDK content manifest SHA-256 | `d7905867300ce6517ba4764f27785cf7facc2c5ee065ed4d54882fed38cc1545` |
| Source hash-map SHA-256 | `3982eb1a81374295f47efb857284e1cbc6a0a3c54412dc971438c898fbc3503a` |
| Source probe recipe SHA-256 | `dcde3e6c1acf22d858ea88105c07356a2d0ce75fadcf226b991bf080e2da0299` |
| Original builder receipt SHA-256 | `c3da3cfd417f6738620430b58e567b266bd9d56d0cc888b60a90a8210dac514e` |
| Preserved native payload archive SHA-256 | `c2b6206a6491bbed19ff4b6c542da963d9a24e1f899a3d8f995d5b368370e47e` |
| Generated consumer SHA-256 | `3f1718f65b8f677681dfaa436fd3276a1b4c084a1f8f3826d2dd3833cda4074c` |
| Raw codec calling contract | `ordinary_consuming_value` |

<details><summary>Exact provider/source/tool/link evidence</summary>

```json
{
  "executable_sha256": {
    "instrumented": "374f26179e2ef2f2d40a8c527cfebd667ced511fee7c4a2c1b9bed92945e3507",
    "uninstrumented": "2276bc6894f990772a404c3c124592a728b305d51d0802ce897fc21772eeb15a"
  },
  "link_evidence": {
    "instrumented": "/tmp/titan-issue252-rtt-original-v4/logs/1792292446181720171-link-dependencies-instrumented.json",
    "uninstrumented": "/tmp/titan-issue252-rtt-original-v4/logs/1792292446176947732-link-dependencies-uninstrumented.json"
  },
  "lua_sha256": {
    "bin/lua": "4ff90fc0bccfffb89db1198b3807b2731b1f95686967a42d13f9b78f6f5561ee",
    "lib/liblua.a": "7decdb6e81469ca27cd6f8bc9f2eef0830c77dd6c5bc15cefc8a89fe1258f721"
  },
  "native_compile_argv": {
    "consumer_instrumented": [
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=bench",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/instrumented/bench.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/instrumented/bench.o.compile.tmp.lua_rqQnYz"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/instrumented/.titan-temporary.tmp.lua_rOEHR7.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/instrumented/.titan-temporary.tmp.lua_rOEHR7.o"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/instrumented/bench__entrypoint.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/instrumented/bench__entrypoint.o"
      ]
    ],
    "consumer_uninstrumented": [
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=bench",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/uninstrumented/bench.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/uninstrumented/bench.o.compile.tmp.lua_f1s9RC"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/uninstrumented/.titan-temporary.tmp.lua_HGaxAo.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/uninstrumented/.titan-temporary.tmp.lua_HGaxAo.o"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/uninstrumented/bench__entrypoint.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/uninstrumented/bench__entrypoint.o"
      ]
    ],
    "private_provider": [
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.async",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/async.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/async.o.compile.tmp.lua_Cn6XTX"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.coroutine",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/coroutine.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/coroutine.o.compile.tmp.lua_HfM9QR"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.fs",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/fs.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/fs.o.compile.tmp.lua_B2ws44"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.gc",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/gc.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/gc.o.compile.tmp.lua_YjfMp8"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.http",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/http/http.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/http/http.o.compile.tmp.lua_orKxUS"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.io",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/io.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/io.o.compile.tmp.lua_1WUmyl"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.iteration",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/iteration.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/iteration.o.compile.tmp.lua_Gc4aIi"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.json",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/json/json.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/json/json.o.compile.tmp.lua_Taq8FT"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.lua",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/lua/lua.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/lua/lua.o.compile.tmp.lua_mB3vje"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.math",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/math.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/math.o.compile.tmp.lua_ldqlDf"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.net",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/net.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/net.o.compile.tmp.lua_dtejLr"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.os",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/os.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/os.o.compile.tmp.lua_2RMSmP"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.path",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/path.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/path.o.compile.tmp.lua_ihc4Cq"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.peg",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/peg/peg.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/peg/peg.o.compile.tmp.lua_xlx9J1"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.protobuf",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/protobuf/protobuf.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/protobuf/protobuf.o.compile.tmp.lua_uDha0l"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.reflect",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/reflect.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/reflect.o.compile.tmp.lua_hpUdO2"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.sqlite3",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/sqlite3/sqlite3.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/sqlite3/sqlite3.o.compile.tmp.lua_sXaTvv"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.ssl",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/ssl.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/ssl.o.compile.tmp.lua_VAJ5Jk"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.string",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/string/string.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/string/string.o.compile.tmp.lua_3ijQ35"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.test",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/test.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/test.o.compile.tmp.lua_VOqkSO"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.thread",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/thread/thread.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/thread/thread.o.compile.tmp.lua_imDAxn"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.timer",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/timer.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/timer.o.compile.tmp.lua_NZqaV8"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.transfer",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/transfer.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/transfer.o.compile.tmp.lua_JApEXM"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.url",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/url.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/url.o.compile.tmp.lua_089PKo"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.uv",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/uv/uv.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/uv/uv.o.compile.tmp.lua_CCbpH1"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-original-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-original-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-baseline-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.websocket",
        "-c",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/websocket/websocket.c",
        "-o",
        "/tmp/titan-issue252-rtt-original-v4/work/provider/titan/websocket/websocket.o.compile.tmp.lua_GMyiiM"
      ]
    ]
  },
  "native_policy": {
    "ar": "/usr/bin/ar",
    "cc": "/usr/bin/gcc",
    "cc_version": "gcc (GCC) 16.2.1 20260819 (Red Hat 16.2.1-2)",
    "emit_line_directives": true,
    "libbacktrace_cflags": "-fPIC -g -O2",
    "lua_archive_sha256": "7decdb6e81469ca27cd6f8bc9f2eef0830c77dd6c5bc15cefc8a89fe1258f721",
    "lua_binary_sha256": "4ff90fc0bccfffb89db1198b3807b2731b1f95686967a42d13f9b78f6f5561ee",
    "lua_source_commit": "025bfc35df0885656de347fb7a7c377e90042a75",
    "native_dependency_versions": {
      "libuv": "1.53.0+spawn-close-v1",
      "llhttp": "9.4.3",
      "lpeglabel": "1.6.2-1@912b0b9e8641074408ffc2259e069b188e0c717b",
      "sqlite3": "3.53.4"
    },
    "openssl_mode": "system",
    "openssl_pkg_config": "/usr/bin/pkg-config",
    "openssl_version": "3.5.9",
    "ranlib": "/usr/bin/ranlib",
    "rock_host_cflags": "-O2 -fPIC",
    "runtime_cflags": "--std=c99 -O3 -flto=auto -ffat-lto-objects -Wall -Wno-unused-but-set-variable -Wno-unused-function -fPIC -g1",
    "sdk_header_replay": {
      "include/llhttp.h": {
        "sha256": "5bc82fa51b19aa8bee7d921038393fbfc74e8cc9bae0844c2d82c102fb8cfd68",
        "source": "llhttp-release-v9.4.3/include/llhttp.h"
      },
      "include/sqlite3.h": {
        "sha256": "919e7f2e8ed1d8f56ac17b412b8971c76aa5d1a879752cc6058f75e7d5910e1d",
        "source": "sqlite-autoconf-3530400/sqlite3.h"
      },
      "include/uv.h": {
        "sha256": "565b25538707aa7244eb197af397e566be591b26cb66b5742ed095063946a558",
        "source": "libuv-v1.53.0/include/uv.h"
      },
      "include/uv/aix.h": {
        "sha256": "bed77e4cf6c06f1224e681cbe607eff04713ca0c1e1f4a102e6a6565ee3f02aa",
        "source": "libuv-v1.53.0/include/uv/aix.h"
      },
      "include/uv/bsd.h": {
        "sha256": "963533ff4b16f72a204a8c760896a857c54d0ac50570f1793e3bef1f2ae8b35f",
        "source": "libuv-v1.53.0/include/uv/bsd.h"
      },
      "include/uv/darwin.h": {
        "sha256": "222b6dd3ce67cfbb735b14b1662f065fc23570d6969acf463b39d946b7590d8c",
        "source": "libuv-v1.53.0/include/uv/darwin.h"
      },
      "include/uv/errno.h": {
        "sha256": "4242edf790e4569ef349026ab4c6e31093334ee5fc02b16ed7a0d9fbacdffd16",
        "source": "libuv-v1.53.0/include/uv/errno.h"
      },
      "include/uv/linux.h": {
        "sha256": "adce0ed0821c8466a87a0a4c9e0df9ea7e4a4b24d099c7d7ed196f72a13f669d",
        "source": "libuv-v1.53.0/include/uv/linux.h"
      },
      "include/uv/os390.h": {
        "sha256": "98388ae32ce2c4390b82c3529539d2a476c44f590e960ed30a79f72b807ecd02",
        "source": "libuv-v1.53.0/include/uv/os390.h"
      },
      "include/uv/posix.h": {
        "sha256": "e9d7218b34e6e89b7b412891b7e2aa8b3a561c5ce9714c1f4def6c8a8593a6a6",
        "source": "libuv-v1.53.0/include/uv/posix.h"
      },
      "include/uv/sunos.h": {
        "sha256": "29d4b4ef48dc3c3ab32d75e0a85bcb80e084d42b32aae40d67fc1d882b93298a",
        "source": "libuv-v1.53.0/include/uv/sunos.h"
      },
      "include/uv/threadpool.h": {
        "sha256": "09ae41099af710289155be012df45c2fce04da6a02e813278b4558935e645938",
        "source": "libuv-v1.53.0/include/uv/threadpool.h"
      },
      "include/uv/tree.h": {
        "sha256": "34393c74082c71ddd5bd9ec4afe30ef03df7fa7bb64be5a50ae070cdfebb5c43",
        "source": "libuv-v1.53.0/include/uv/tree.h"
      },
      "include/uv/unix.h": {
        "sha256": "bfa9e31bccf6991f795074316d323eaeef5dcdf6b1b6b8b9d1093e871e6484db",
        "source": "libuv-v1.53.0/include/uv/unix.h"
      },
      "include/uv/version.h": {
        "sha256": "8e216f0998cae52664f5a9889a2ec921e43c7abf7970c4780ab4e1bb6262932c",
        "source": "libuv-v1.53.0/include/uv/version.h"
      },
      "include/uv/win.h": {
        "sha256": "414f87cfec6fe111b893c71894bb3bf4afd1ae8e9fc601aa6cf7fb54dc3a1ca7",
        "source": "libuv-v1.53.0/include/uv/win.h"
      }
    },
    "titan_build_profile": "production",
    "titan_cppflags": "-DOPENSSL_API_COMPAT=30000 -D_GNU_SOURCE",
    "titan_extra_cflags": "-fno-strict-aliasing",
    "titan_ldflags": "-lpthread -lrt -lssl -lcrypto"
  },
  "private_provider_files": {
    "/tmp/titan-issue252-rtt-original-v4/work/provider/titan.a": "db45604b7314352b5e185139940e29f8801cb29c33a62e498f3361f5540e5dd6",
    "/tmp/titan-issue252-rtt-original-v4/work/provider/titan.so": "10ba2b75635a210e583417c7a2984259e4b2c4e80abf371965c76e4bdf996caf"
  },
  "private_source_sha256": {
    "titan/async.titan": "b384f0e672566f34bbadbeb44c0c2c517e7e925f727df9b9c1a096ec402d43a7",
    "titan/async_receiver_native.h": "0fa7dd008ecb50fc84070eb52014e4223f57d66ab3f82bfeda793ebc475150db",
    "titan/async_signal_platform.h": "3a413448397988560fe12a07e288be7bab73124964c44bac749497b61b069296",
    "titan/coroutine.titan": "be5fd08a6fd6d3b0b2f6b798f4e3ad42c10d1fb5e88aced6209faa59b9e2144b",
    "titan/fs.titan": "a327d9b30d8f680bfb9faa24f514eec2812fede877ab46e3f9531c822e3b99f9",
    "titan/fs_platform.h": "00da49bdf0851c3a4e2f44ed74243ba40a7b41e3d528f41e50b953503b11d879",
    "titan/gc.titan": "03cabaf0a6e2a48be14280d898236fce5334d3cfa769abc4b7c7a4b1632bb638",
    "titan/http/client.titan": "deed2100ec9da07aa4796f90b05d2491846d04accaa9491805548bc8180855b2",
    "titan/http/headers.titan": "8827e4cd9ae5a18cf660289fee5acb0bd774daa97f7c10cc1e220e724c70557d",
    "titan/http/http.titan": "ff6cc19963ed720c9cc3db435cba78fd7b4457260dd49674d983a0c21f725ae2",
    "titan/http/native.titan": "c6dc067689edb2b9cfd7c012e2497806b7c405a500a024aecedcd1b0695f8390",
    "titan/http/pool.titan": "04e290cd0f8f50b120541339ed15b1aa573a49afd145c0d9e8b6d4cae1987646",
    "titan/http/server.titan": "0032dc51c27b386d06ee912f62e27e7fb122c45e84fc58bf1b1f1f2db1066cec",
    "titan/http/transfer.titan": "fbc27658c9752325e48e748f4fa60c148e6cd56e794254df8cfc42fc830411f4",
    "titan/http/upgrade.titan": "82660410330005aca4c3846eea3b3b46cd4196ac280684f14658d1f4b92884c8",
    "titan/io.titan": "a85aea6ee8d66da0d8fc594426b9e9da812c8701916cd37703548513f7c8b57a",
    "titan/iteration.titan": "c5d33ca7f159aef0e9c07163ae8871920f46ce73ad8a6c9565265ec5e636e3d7",
    "titan/json/decoder.titan": "d4def8fce5de08c7c87508ce0a411a1bafe4b9ac5dd6e318ab4062fd99f4a144",
    "titan/json/json.titan": "1fd824d91d9bee28e2093bebc3598fabdcec594d00aafad6d00a991f4643050a",
    "titan/json/numbers.titan": "88f8a136d374276e98d05e047ed32aaa03efd63e56f4a83c516d48d513f3b13a",
    "titan/json/parser.titan": "7f12a7ba9c72bcc3103f2f84939e23a968fd8c4619fa10e8d8495c5f89dffeb2",
    "titan/json/writer.titan": "6667abde3d9f08e1e5711a30ff1ab636288c5c286c9c6916d98e088c52732703",
    "titan/lua/lua.titan": "fe0b752e006c2d8eda5d16a1b4a93f8ff0328b41a30993ef8f53ed2f63ad362e",
    "titan/lua/native.h": "9b5cdc28cab74588ec8ac44085886300d900d7d547c467b171888e2094660d8a",
    "titan/lua/worker.titan": "a405570e4f22e7e42c0af38e29e0e15b9458b9b8ad4206d0c4a3e9d0c96ff88a",
    "titan/math.titan": "15005d85308ffd3e42a79e548f55c5e5d59cd33e8bb7d4cb2608fe1e0d593f3e",
    "titan/net.titan": "e0c586a511979ac7150b2308ef8581740b481cec13441ac3c1196ba1323c19dd",
    "titan/os.titan": "da276574dec7c8a4dee575782ab22a61184baf083d0739be5569597aa6031835",
    "titan/os_environment.h": "e6b805d75104076751c555af08c4ea80881dd93df104dec8ebefd6b12aca982b",
    "titan/os_platform.h": "2ca67def9f3c87a409a9a80c6458aa9d53d7bbc227c0b3a6c07cabafd226770c",
    "titan/path.titan": "43c194cf9b3b4b79c37f652e74b20f20ab77996bbd326ba188b1e4ee2c601086",
    "titan/path_platform.h": "c56729270bb299092c6ac7dd88ae117c97a874393520ce810ef1c8af03e6ecc8",
    "titan/peg/combinators.titan": "e630451865326ab2ccc9b4078f17c12412e6af19155539a28868df7f34751f11",
    "titan/peg/native.titan": "768cb146b1e578521fb97c2318053ff5fc80a7d5b1765d997518002f083e8fd0",
    "titan/peg/peg.titan": "f3771893b9b648af80027ab839ca27e9165a95b94b28ec1d6637b3fa40ece24a",
    "titan/peg/relabel.titan": "3b6bcccd8da929aa1d56da040bc53df9cd24413361536ac9b66d39a3ec186d0f",
    "titan/peg/relabel_parser.titan": "22df8b78c74e0e596d642f60be244f9f17ee20860a52e8d67d90c3cc14eef1d8",
    "titan/protobuf/decoder.titan": "a864fd7450aa83d286ec173a1928b2f6b07f310d484497b0d8ab6e373802be7f",
    "titan/protobuf/encoder.titan": "3c4cc2b49ca8ff3b45334af70ba72a0f5c84c7cd3639d72aafefcd2f040714b9",
    "titan/protobuf/native.h": "256dd809670f6f1a20a2951ff3783f96ce93341cff0408bd55d89af6fcb40d52",
    "titan/protobuf/protobuf.titan": "39cb281542ec090c7f9de94f5ac8eb690ed5f47dec253decc46f78841bdef24f",
    "titan/protobuf/schema.titan": "924b9d92ad0b2f82f61e82ef18cd0be5fbad1dcbbb53dccc929ea569c8294c8f",
    "titan/reflect.titan": "a611557c47f100f7b3f44badbd47dda0bf11b4d7869df7aa7c0d73214ba2fef9",
    "titan/sqlite3/bindings.titan": "17a46365e8c8cb93e329676d35a9e74d151cc9590489a8591c0fd7b6c04a103d",
    "titan/sqlite3/native.h": "ac82a1b9730c6e6692b9e08e3fd8b3d83337df66a6a2c6264a366040d9e992ef",
    "titan/sqlite3/row.titan": "58f91cec279562e60559ab66937a80d01fdd30532a2cff4622da1171b9181618",
    "titan/sqlite3/sqlite3.titan": "bae3cb85db17d0fd48ed4f0b9f3479ecda6842c3994bf25f7b8f2a67d597bc45",
    "titan/sqlite3/worker.titan": "421db60859260a0ed96ca325e0def109b8dbd661a0619870790140668fb23092",
    "titan/ssl.titan": "79b741432798a3f2b73ec85fa33851b1bd3cc3e43fd7a4315a8ea74213ca1fd0",
    "titan/string/bytes.titan": "9448b332fd42bf409b453158305890c8c12eb5eb18df1be9bc92342bcc9c8b3e",
    "titan/string/format.titan": "ff8794649730b36d0185cdecb28cbb9eb0a76ffd0b122e67864de3715b02ae34",
    "titan/string/format_native.h": "f3f97457a9296ea6e32e72e036b05e945f15eb8ef02cccdca8ea816a3ac76b75",
    "titan/string/pack.titan": "20bc7a5a3d4f8b499ae27246559040124886b9925cdf6f05b13167690d2a99c2",
    "titan/string/regex_api.titan": "281d06298980e53cdd2e133bbf5ae1ffbbd5e2dc49974979a17b1970362c6160",
    "titan/string/regex_compile.titan": "8aa476969a2854cdd921e112a5c6d6bf860a9c655261851f8f6cebe7bd0dd786",
    "titan/string/regex_parser.titan": "8402206160bceefe85d38abceb52588357afcf5991d753da4ec4a56c4b84b969",
    "titan/string/string.titan": "e1015dcb814d4c2173e8f14dbe506e3a9d5b96e814a58e818306960e0d2b72ea",
    "titan/test.titan": "1098b360eb4e1312cc3e41fb2c6bc258a68a9d9aba47da5fe7dbbc3a3843edcf",
    "titan/thread/channel.titan": "ce91242d1563becf5674c575192431042813ab4b435e2ebb10f5820293041659",
    "titan/thread/group.titan": "4fe8c6b4d535ea88a5d9e0ab92c2a570c78576e95682ca97ec10de44f9d7bf40",
    "titan/thread/native.h": "3f256682e2e58e8cdc64df768be99874791812c5de4db7dcaf15d02009ce0a10",
    "titan/thread/spawn.titan": "68148c5f0ad29b2de0e645183a0b5c91b036885e0c8d84943dd3869ce009724a",
    "titan/thread/thread.titan": "ea9740dd8dcf7087c37d9b862d5111288f08fd610a7a53f6586e62753c5e3720",
    "titan/timer.titan": "bcbbaf7ca0a83e6305b7c436523bbe938454254b1967a1e2c717417d44e69d1b",
    "titan/transfer.titan": "4e6c0181e4c9f69f62afca227e2b05b2530b9fa5a7188d1372b6c543ded8948c",
    "titan/url.titan": "c130c7e2736759cceed9f0c9955e457d9253c94cbe0784adb74d990b2891f9ab",
    "titan/uv/address-native.h": "a77fc869a5ddefee6dd053c0f1df552e6bb96a320a1f8bf0e2a5b3c28ac61525",
    "titan/uv/address.titan": "67d85cfbf9382484c49dd7e3b396963db5ef337508d2cbafc2dc50d9ea4f3c84",
    "titan/uv/callback.h": "de7a15347fe4586ffe9dd7a7f3dfc9931ed488a8babde23f81dfc53bd1d89bee",
    "titan/uv/callbacks.titan": "d605d2cd36704a1c1cd19eb5b988045865141738b94dd1d9c92c85b507b0832f",
    "titan/uv/capabilities.titan": "b79d72cb392a74828f1aa0a82a781b2d83ab09d7803c17a85986c899a4ad9b5f",
    "titan/uv/constants.titan": "58042ab8d85fe014a4dd3c940b0594710fdc76cf35f4e6eb64bc8eecc8bed330",
    "titan/uv/data.titan": "565de88997eba8034f5431ead7a80a2ed37aff12a8932aedf85a225d0474fb8a",
    "titan/uv/data_native.h": "68cf454e225b200572d5de46ada8b091d774a661ebe39b7160c18bf4c5d195c1",
    "titan/uv/dll.titan": "51aae662b051bb5fcd4bc61fd41e36e032c5ce95f45822f6e81fec347a214800",
    "titan/uv/dns.titan": "d79ae8118ee8d2d17e29ac050370d967f7096d4c56efdc5c7e4eef281f93d868",
    "titan/uv/fd-native.h": "310b9f22163030d72ae29bf32f06b63ac253db23ada7dce7ef5833ce3ef3dd9f",
    "titan/uv/fd.titan": "0d754b9e83e2d3506ae988d46bd160a3b9df867a751c43ba7ec6e8c8caff7953",
    "titan/uv/identifiers.titan": "a5b033d59b4593db7ed8512558468708b7cc55fe94555505ada36f32a3406d08",
    "titan/uv/network-native.h": "aa68b33b4533ccf0a9a21da5037c8a75d942b5cf0fcbfaf860501673ebb1b78d",
    "titan/uv/pipe_tty.titan": "c993616548c9e0957355ce7cfad76daef24b44353749c7af9f4648acd5c8b0c8",
    "titan/uv/platform-constants.h": "026ede031bc7ebb28ed0504d29a2a077175c152cf18d181120944bd43ac46a26",
    "titan/uv/platform_constants.titan": "c322cb9c80ffdb8406ab643ac935f8cc5ad7d7736e09711abb3e826e2d007255",
    "titan/uv/process.titan": "94145f180cc85848c118adec809c6e4efa153199053b874b5b035046f518e14d",
    "titan/uv/startup.titan": "31e0376df10ec0ef59257f59160b7e6958df301fb1e3d167544519dc35f2381f",
    "titan/uv/stream_ops.titan": "6ecb4e474f66c6507c8c7f29114e2c95cf84a0d6df62aa7b37f0ce1708037071",
    "titan/uv/stream_owners.titan": "8cc33b19287a8f4edd25e05e65270bda2f6bbefbc024da80187f6e3e5ba1de4e",
    "titan/uv/sync.titan": "95906e8bd3f522351014942298633dfba96872545ccdb94e1a401ca2bae03e8e",
    "titan/uv/sync_storage.h": "735846d522d0d8ac547b90b72c4104bd91bbf35ce77a9485ad57bd49f2eea579",
    "titan/uv/tcp.titan": "d60f9e62432719f0dd2f2387fb58ad185fef0861c7b1251923c085c36c4295e9",
    "titan/uv/thread-native.h": "3f21558b5d56f539bf293e25f21feaf20b13738d84591e6af7f26cc18762060a",
    "titan/uv/threading.titan": "31272c0fea232f4ad79188443322e64af89cc04bb2dd565f5fe5c2775a811777",
    "titan/uv/transfer-native.h": "cb758073064a42bc66d3ffe4829403d179c5ba943a5824e3a753544917c47335",
    "titan/uv/transfer.titan": "23a4475f92f4b65b99c8e1238bfbcf59a878a8badff6e476a4fffc77f02eed2f",
    "titan/uv/udp.titan": "dbdcca8e11d86e14e275462f2134dfe12b49a459ffcd5861541154c97df4bec5",
    "titan/uv/utilities.titan": "c04d0930ef4748efe2229e8f56e376f0422c332378f919faf8ac3874621f20aa",
    "titan/uv/utility_bits.h": "266f6acacbbe4789cf2d5a193290940d005a89fb472f1170bf5f4ad9ffe484fe",
    "titan/uv/uv.titan": "e1b9d3ee90fd9bb8988166179a873cfd1ebab30cacb092a80173048149cae055",
    "titan/uv/version-native.h": "f50904be5213e873f965a9c0df91fdd84e7bb81c64c754c644a4f01b243f7b13",
    "titan/uv/work-data.h": "6c5d07725136b16e44931d7063166521c3dd36b698669547cdfaae768624f131",
    "titan/websocket/connection.titan": "3b12bd5104ed1d8909f277705071a904aef6c7f0cfcde2ceaef40fe29b862087",
    "titan/websocket/frames.titan": "5f1186d677e4181c84a1ff88d7f03211ad7c594eddd89484637e5bc9843f9fb3",
    "titan/websocket/handshake.titan": "75687fd219930545303c1b6e89f6e1fe58f8c9b93990753f10202d4cc517315b",
    "titan/websocket/native.titan": "e5cb28322f7ef8ee33531482fca6e2bb6d6019cc0ab525d502045365677864d1",
    "titan/websocket/utf8.titan": "b0eda22bfbcd8cb0fb13d105ff49af15cee41316ae8acd5a1d1cd79fae51f26c",
    "titan/websocket/websocket.titan": "9e25d2affc279a4e6cb986b7e6c164d05e91e76c0ee2f0fcd3062c3e6c849b62",
    "vendor/lpeglabel/lplcap.h": "1114fe329cc34c7054938035e73e6bf25802e3b0b88e0f17ebe592587d405013",
    "vendor/lpeglabel/lplcode.h": "84dfbddbd78d4a0f6861dd8be065d5fd1c4c4aac8cd77cea3af4ad286d9be9ac",
    "vendor/lpeglabel/lplprint.h": "1b70e48cc3f8f1a57a3485f5125bda90f230b1c24e06e18adbf4e3c753af992e",
    "vendor/lpeglabel/lpltree.h": "e92d8d4676a7757a028052d0e05056575b3821ba577a63231f37902c0dd180eb",
    "vendor/lpeglabel/lpltypes.h": "d07a72b2470210de6ba82ae868bec93be6b15d15b060d8a8abc926de7d090b70",
    "vendor/lpeglabel/lplvm.h": "6eafc02d33ff9d11abf77b8eb49b086ed684d4394c7303972d46dda7f81c2fe7",
    "vendor/lpeglabel/titan_lpeglabel.h": "3384372e7ed10ca5a18bba7f16dbcf4859a740aff3a4f11ec379e79569eb4a22",
    "vendor/lpeglabel/titan_lpeglabel_namespace.h": "233f2208d0669204031c3475abe4ae3dc376f9381fa1ace36d2330e41554640f"
  },
  "provider_build_evidence": {
    "attestation": "/tmp/titan-issue252-baseline-attested/BUILD-ATTESTATION.json",
    "attestation_sha256": "39e62c71d4010cfe3caf252317b373c4b35036e5d1f66dd82af9b0816de427cf",
    "commands": "/tmp/titan-issue252-baseline-attested/BUILD-COMMANDS.json",
    "commands_sha256": "39a09f78512b5423788290f6bd8df55af8fce5a2cb526941ee529aec8ac113a3",
    "effective_make_policy": "/tmp/titan-issue252-baseline-attested/EFFECTIVE-MAKE-POLICY.txt",
    "effective_make_policy_sha256": "c092161a981e7d599991a3e1e34511369fe92b0669a1f72839471f167c2e5d29",
    "source_after": "/tmp/titan-issue252-baseline-attested/SOURCE-AFTER.json",
    "source_before": "/tmp/titan-issue252-baseline-attested/SOURCE-BEFORE.json"
  },
  "provider_files": {
    "/tmp/titan-issue252-baseline-attested/sdk/bin/lua": "4ff90fc0bccfffb89db1198b3807b2731b1f95686967a42d13f9b78f6f5561ee",
    "/tmp/titan-issue252-baseline-attested/sdk/lib/luarocks/rocks-5.5/titan/0.6.0-1/bin/titanc": "567bdf8984e6631a199b3feae238483a632af62aa9239a5864a93fb074ce03b4",
    "/tmp/titan-issue252-baseline-attested/sdk/lib/titan/0.6/libtitan.a": "36b4ef287068434844e7a6da5fc145ad5ae37859103a302e460fb4875fc3513f",
    "/tmp/titan-issue252-baseline-attested/sdk/lib/titan/0.6/titan.a": "35067395ea483ae354f2c9e918fcbed1e97447acf280e24e6723873012c132ef",
    "/tmp/titan-issue252-baseline-attested/sdk/lib/titan/0.6/titan.so": "f786d5c03a682efc0fe3905915853bd2f597cbe9e72349d169500973bf5ef087"
  },
  "source_compile_policy": {
    "build_profile": "production",
    "emit_line_directives": true,
    "extra_cflags": [
      "-fno-strict-aliasing"
    ],
    "generated_cflags": [
      "--std=c99",
      "-O3",
      "-Wall",
      "-Wno-unused-but-set-variable",
      "-Wno-unused-function",
      "-fPIC",
      "-g1",
      "-flto=auto",
      "-ffat-lto-objects",
      "-fno-strict-aliasing"
    ],
    "module_random_seed": {
      "consumer_instrumented": [
        "bench"
      ],
      "consumer_uninstrumented": [
        "bench"
      ],
      "private_provider": [
        "titan.async",
        "titan.coroutine",
        "titan.fs",
        "titan.gc",
        "titan.http",
        "titan.io",
        "titan.iteration",
        "titan.json",
        "titan.lua",
        "titan.math",
        "titan.net",
        "titan.os",
        "titan.path",
        "titan.peg",
        "titan.protobuf",
        "titan.reflect",
        "titan.sqlite3",
        "titan.ssl",
        "titan.string",
        "titan.test",
        "titan.thread",
        "titan.timer",
        "titan.transfer",
        "titan.url",
        "titan.uv",
        "titan.websocket"
      ]
    },
    "private_provider_compile_receipt": "/tmp/titan-issue252-rtt-original-v4/logs/1792291787310150438-compile-private-full-provider.json",
    "probe_cflags": [
      "--std=c99",
      "-O3",
      "-Wall",
      "-Wno-unused-but-set-variable",
      "-Wno-unused-function",
      "-fPIC",
      "-g1",
      "-flto=auto",
      "-ffat-lto-objects",
      "-fno-strict-aliasing",
      "-std=c11",
      "-Wextra",
      "-Werror",
      "-fno-builtin",
      "-frandom-seed=rtt_probe"
    ],
    "probe_policy_difference": "C11, instrumentation diagnostics, no builtins, fixed probe-only random seed"
  },
  "source_sha256": {
    "titan/async.titan": "b384f0e672566f34bbadbeb44c0c2c517e7e925f727df9b9c1a096ec402d43a7",
    "titan/async_receiver_native.h": "0fa7dd008ecb50fc84070eb52014e4223f57d66ab3f82bfeda793ebc475150db",
    "titan/async_signal_platform.h": "3a413448397988560fe12a07e288be7bab73124964c44bac749497b61b069296",
    "titan/coroutine.titan": "be5fd08a6fd6d3b0b2f6b798f4e3ad42c10d1fb5e88aced6209faa59b9e2144b",
    "titan/fs.titan": "a327d9b30d8f680bfb9faa24f514eec2812fede877ab46e3f9531c822e3b99f9",
    "titan/fs_platform.h": "00da49bdf0851c3a4e2f44ed74243ba40a7b41e3d528f41e50b953503b11d879",
    "titan/gc.titan": "03cabaf0a6e2a48be14280d898236fce5334d3cfa769abc4b7c7a4b1632bb638",
    "titan/http/client.titan": "deed2100ec9da07aa4796f90b05d2491846d04accaa9491805548bc8180855b2",
    "titan/http/headers.titan": "8827e4cd9ae5a18cf660289fee5acb0bd774daa97f7c10cc1e220e724c70557d",
    "titan/http/http.titan": "ff6cc19963ed720c9cc3db435cba78fd7b4457260dd49674d983a0c21f725ae2",
    "titan/http/native.titan": "c6dc067689edb2b9cfd7c012e2497806b7c405a500a024aecedcd1b0695f8390",
    "titan/http/pool.titan": "04e290cd0f8f50b120541339ed15b1aa573a49afd145c0d9e8b6d4cae1987646",
    "titan/http/server.titan": "0032dc51c27b386d06ee912f62e27e7fb122c45e84fc58bf1b1f1f2db1066cec",
    "titan/http/transfer.titan": "fbc27658c9752325e48e748f4fa60c148e6cd56e794254df8cfc42fc830411f4",
    "titan/http/upgrade.titan": "82660410330005aca4c3846eea3b3b46cd4196ac280684f14658d1f4b92884c8",
    "titan/io.titan": "a85aea6ee8d66da0d8fc594426b9e9da812c8701916cd37703548513f7c8b57a",
    "titan/iteration.titan": "c5d33ca7f159aef0e9c07163ae8871920f46ce73ad8a6c9565265ec5e636e3d7",
    "titan/json/decoder.titan": "d4def8fce5de08c7c87508ce0a411a1bafe4b9ac5dd6e318ab4062fd99f4a144",
    "titan/json/json.titan": "1fd824d91d9bee28e2093bebc3598fabdcec594d00aafad6d00a991f4643050a",
    "titan/json/numbers.titan": "88f8a136d374276e98d05e047ed32aaa03efd63e56f4a83c516d48d513f3b13a",
    "titan/json/parser.titan": "7f12a7ba9c72bcc3103f2f84939e23a968fd8c4619fa10e8d8495c5f89dffeb2",
    "titan/json/writer.titan": "6667abde3d9f08e1e5711a30ff1ab636288c5c286c9c6916d98e088c52732703",
    "titan/lua/lua.titan": "fe0b752e006c2d8eda5d16a1b4a93f8ff0328b41a30993ef8f53ed2f63ad362e",
    "titan/lua/native.h": "9b5cdc28cab74588ec8ac44085886300d900d7d547c467b171888e2094660d8a",
    "titan/lua/worker.titan": "a405570e4f22e7e42c0af38e29e0e15b9458b9b8ad4206d0c4a3e9d0c96ff88a",
    "titan/math.titan": "15005d85308ffd3e42a79e548f55c5e5d59cd33e8bb7d4cb2608fe1e0d593f3e",
    "titan/net.titan": "e0c586a511979ac7150b2308ef8581740b481cec13441ac3c1196ba1323c19dd",
    "titan/os.titan": "da276574dec7c8a4dee575782ab22a61184baf083d0739be5569597aa6031835",
    "titan/os_environment.h": "e6b805d75104076751c555af08c4ea80881dd93df104dec8ebefd6b12aca982b",
    "titan/os_platform.h": "2ca67def9f3c87a409a9a80c6458aa9d53d7bbc227c0b3a6c07cabafd226770c",
    "titan/path.titan": "43c194cf9b3b4b79c37f652e74b20f20ab77996bbd326ba188b1e4ee2c601086",
    "titan/path_platform.h": "c56729270bb299092c6ac7dd88ae117c97a874393520ce810ef1c8af03e6ecc8",
    "titan/peg/combinators.titan": "e630451865326ab2ccc9b4078f17c12412e6af19155539a28868df7f34751f11",
    "titan/peg/native.titan": "768cb146b1e578521fb97c2318053ff5fc80a7d5b1765d997518002f083e8fd0",
    "titan/peg/peg.titan": "f3771893b9b648af80027ab839ca27e9165a95b94b28ec1d6637b3fa40ece24a",
    "titan/peg/relabel.titan": "3b6bcccd8da929aa1d56da040bc53df9cd24413361536ac9b66d39a3ec186d0f",
    "titan/peg/relabel_parser.titan": "22df8b78c74e0e596d642f60be244f9f17ee20860a52e8d67d90c3cc14eef1d8",
    "titan/protobuf/decoder.titan": "a864fd7450aa83d286ec173a1928b2f6b07f310d484497b0d8ab6e373802be7f",
    "titan/protobuf/encoder.titan": "3c4cc2b49ca8ff3b45334af70ba72a0f5c84c7cd3639d72aafefcd2f040714b9",
    "titan/protobuf/native.h": "256dd809670f6f1a20a2951ff3783f96ce93341cff0408bd55d89af6fcb40d52",
    "titan/protobuf/protobuf.titan": "39cb281542ec090c7f9de94f5ac8eb690ed5f47dec253decc46f78841bdef24f",
    "titan/protobuf/schema.titan": "924b9d92ad0b2f82f61e82ef18cd0be5fbad1dcbbb53dccc929ea569c8294c8f",
    "titan/reflect.titan": "a611557c47f100f7b3f44badbd47dda0bf11b4d7869df7aa7c0d73214ba2fef9",
    "titan/sqlite3/bindings.titan": "17a46365e8c8cb93e329676d35a9e74d151cc9590489a8591c0fd7b6c04a103d",
    "titan/sqlite3/native.h": "ac82a1b9730c6e6692b9e08e3fd8b3d83337df66a6a2c6264a366040d9e992ef",
    "titan/sqlite3/row.titan": "58f91cec279562e60559ab66937a80d01fdd30532a2cff4622da1171b9181618",
    "titan/sqlite3/sqlite3.titan": "bae3cb85db17d0fd48ed4f0b9f3479ecda6842c3994bf25f7b8f2a67d597bc45",
    "titan/sqlite3/worker.titan": "421db60859260a0ed96ca325e0def109b8dbd661a0619870790140668fb23092",
    "titan/ssl.titan": "79b741432798a3f2b73ec85fa33851b1bd3cc3e43fd7a4315a8ea74213ca1fd0",
    "titan/string/bytes.titan": "9448b332fd42bf409b453158305890c8c12eb5eb18df1be9bc92342bcc9c8b3e",
    "titan/string/format.titan": "ff8794649730b36d0185cdecb28cbb9eb0a76ffd0b122e67864de3715b02ae34",
    "titan/string/format_native.h": "f3f97457a9296ea6e32e72e036b05e945f15eb8ef02cccdca8ea816a3ac76b75",
    "titan/string/pack.titan": "20bc7a5a3d4f8b499ae27246559040124886b9925cdf6f05b13167690d2a99c2",
    "titan/string/regex_api.titan": "281d06298980e53cdd2e133bbf5ae1ffbbd5e2dc49974979a17b1970362c6160",
    "titan/string/regex_compile.titan": "8aa476969a2854cdd921e112a5c6d6bf860a9c655261851f8f6cebe7bd0dd786",
    "titan/string/regex_parser.titan": "8402206160bceefe85d38abceb52588357afcf5991d753da4ec4a56c4b84b969",
    "titan/string/string.titan": "e1015dcb814d4c2173e8f14dbe506e3a9d5b96e814a58e818306960e0d2b72ea",
    "titan/test.titan": "1098b360eb4e1312cc3e41fb2c6bc258a68a9d9aba47da5fe7dbbc3a3843edcf",
    "titan/thread/channel.titan": "365c86bf871cb2e71821eefd5b83e13a9cea0f6b24f2801d9fab362ed7e02418",
    "titan/thread/group.titan": "4fe8c6b4d535ea88a5d9e0ab92c2a570c78576e95682ca97ec10de44f9d7bf40",
    "titan/thread/native.h": "3f256682e2e58e8cdc64df768be99874791812c5de4db7dcaf15d02009ce0a10",
    "titan/thread/spawn.titan": "1f12294172ff283d50a361b8cdafcd582bd3e70e6718c300d6f660a50c57d273",
    "titan/thread/thread.titan": "0b7f77fa0e3e89b569a9b4243f8bc2485a1a3e82b6b65e357e7107439be33083",
    "titan/timer.titan": "bcbbaf7ca0a83e6305b7c436523bbe938454254b1967a1e2c717417d44e69d1b",
    "titan/transfer.titan": "4e6c0181e4c9f69f62afca227e2b05b2530b9fa5a7188d1372b6c543ded8948c",
    "titan/url.titan": "c130c7e2736759cceed9f0c9955e457d9253c94cbe0784adb74d990b2891f9ab",
    "titan/uv/address-native.h": "a77fc869a5ddefee6dd053c0f1df552e6bb96a320a1f8bf0e2a5b3c28ac61525",
    "titan/uv/address.titan": "67d85cfbf9382484c49dd7e3b396963db5ef337508d2cbafc2dc50d9ea4f3c84",
    "titan/uv/callback.h": "de7a15347fe4586ffe9dd7a7f3dfc9931ed488a8babde23f81dfc53bd1d89bee",
    "titan/uv/callbacks.titan": "d605d2cd36704a1c1cd19eb5b988045865141738b94dd1d9c92c85b507b0832f",
    "titan/uv/capabilities.titan": "b79d72cb392a74828f1aa0a82a781b2d83ab09d7803c17a85986c899a4ad9b5f",
    "titan/uv/constants.titan": "58042ab8d85fe014a4dd3c940b0594710fdc76cf35f4e6eb64bc8eecc8bed330",
    "titan/uv/data.titan": "565de88997eba8034f5431ead7a80a2ed37aff12a8932aedf85a225d0474fb8a",
    "titan/uv/data_native.h": "68cf454e225b200572d5de46ada8b091d774a661ebe39b7160c18bf4c5d195c1",
    "titan/uv/dll.titan": "51aae662b051bb5fcd4bc61fd41e36e032c5ce95f45822f6e81fec347a214800",
    "titan/uv/dns.titan": "d79ae8118ee8d2d17e29ac050370d967f7096d4c56efdc5c7e4eef281f93d868",
    "titan/uv/fd-native.h": "310b9f22163030d72ae29bf32f06b63ac253db23ada7dce7ef5833ce3ef3dd9f",
    "titan/uv/fd.titan": "0d754b9e83e2d3506ae988d46bd160a3b9df867a751c43ba7ec6e8c8caff7953",
    "titan/uv/identifiers.titan": "a5b033d59b4593db7ed8512558468708b7cc55fe94555505ada36f32a3406d08",
    "titan/uv/network-native.h": "aa68b33b4533ccf0a9a21da5037c8a75d942b5cf0fcbfaf860501673ebb1b78d",
    "titan/uv/pipe_tty.titan": "c993616548c9e0957355ce7cfad76daef24b44353749c7af9f4648acd5c8b0c8",
    "titan/uv/platform-constants.h": "026ede031bc7ebb28ed0504d29a2a077175c152cf18d181120944bd43ac46a26",
    "titan/uv/platform_constants.titan": "c322cb9c80ffdb8406ab643ac935f8cc5ad7d7736e09711abb3e826e2d007255",
    "titan/uv/process.titan": "94145f180cc85848c118adec809c6e4efa153199053b874b5b035046f518e14d",
    "titan/uv/startup.titan": "31e0376df10ec0ef59257f59160b7e6958df301fb1e3d167544519dc35f2381f",
    "titan/uv/stream_ops.titan": "6ecb4e474f66c6507c8c7f29114e2c95cf84a0d6df62aa7b37f0ce1708037071",
    "titan/uv/stream_owners.titan": "8cc33b19287a8f4edd25e05e65270bda2f6bbefbc024da80187f6e3e5ba1de4e",
    "titan/uv/sync.titan": "95906e8bd3f522351014942298633dfba96872545ccdb94e1a401ca2bae03e8e",
    "titan/uv/sync_storage.h": "735846d522d0d8ac547b90b72c4104bd91bbf35ce77a9485ad57bd49f2eea579",
    "titan/uv/tcp.titan": "d60f9e62432719f0dd2f2387fb58ad185fef0861c7b1251923c085c36c4295e9",
    "titan/uv/thread-native.h": "3f21558b5d56f539bf293e25f21feaf20b13738d84591e6af7f26cc18762060a",
    "titan/uv/threading.titan": "31272c0fea232f4ad79188443322e64af89cc04bb2dd565f5fe5c2775a811777",
    "titan/uv/transfer-native.h": "cb758073064a42bc66d3ffe4829403d179c5ba943a5824e3a753544917c47335",
    "titan/uv/transfer.titan": "23a4475f92f4b65b99c8e1238bfbcf59a878a8badff6e476a4fffc77f02eed2f",
    "titan/uv/udp.titan": "dbdcca8e11d86e14e275462f2134dfe12b49a459ffcd5861541154c97df4bec5",
    "titan/uv/utilities.titan": "c04d0930ef4748efe2229e8f56e376f0422c332378f919faf8ac3874621f20aa",
    "titan/uv/utility_bits.h": "266f6acacbbe4789cf2d5a193290940d005a89fb472f1170bf5f4ad9ffe484fe",
    "titan/uv/uv.titan": "e1b9d3ee90fd9bb8988166179a873cfd1ebab30cacb092a80173048149cae055",
    "titan/uv/version-native.h": "f50904be5213e873f965a9c0df91fdd84e7bb81c64c754c644a4f01b243f7b13",
    "titan/uv/work-data.h": "6c5d07725136b16e44931d7063166521c3dd36b698669547cdfaae768624f131",
    "titan/websocket/connection.titan": "3b12bd5104ed1d8909f277705071a904aef6c7f0cfcde2ceaef40fe29b862087",
    "titan/websocket/frames.titan": "5f1186d677e4181c84a1ff88d7f03211ad7c594eddd89484637e5bc9843f9fb3",
    "titan/websocket/handshake.titan": "75687fd219930545303c1b6e89f6e1fe58f8c9b93990753f10202d4cc517315b",
    "titan/websocket/native.titan": "e5cb28322f7ef8ee33531482fca6e2bb6d6019cc0ab525d502045365677864d1",
    "titan/websocket/utf8.titan": "b0eda22bfbcd8cb0fb13d105ff49af15cee41316ae8acd5a1d1cd79fae51f26c",
    "titan/websocket/websocket.titan": "9e25d2affc279a4e6cb986b7e6c164d05e91e76c0ee2f0fcd3062c3e6c849b62",
    "vendor/lpeglabel/lplcap.h": "1114fe329cc34c7054938035e73e6bf25802e3b0b88e0f17ebe592587d405013",
    "vendor/lpeglabel/lplcode.h": "84dfbddbd78d4a0f6861dd8be065d5fd1c4c4aac8cd77cea3af4ad286d9be9ac",
    "vendor/lpeglabel/lplprint.h": "1b70e48cc3f8f1a57a3485f5125bda90f230b1c24e06e18adbf4e3c753af992e",
    "vendor/lpeglabel/lpltree.h": "e92d8d4676a7757a028052d0e05056575b3821ba577a63231f37902c0dd180eb",
    "vendor/lpeglabel/lpltypes.h": "d07a72b2470210de6ba82ae868bec93be6b15d15b060d8a8abc926de7d090b70",
    "vendor/lpeglabel/lplvm.h": "6eafc02d33ff9d11abf77b8eb49b086ed684d4394c7303972d46dda7f81c2fe7",
    "vendor/lpeglabel/titan_lpeglabel.h": "3384372e7ed10ca5a18bba7f16dbcf4859a740aff3a4f11ec379e79569eb4a22",
    "vendor/lpeglabel/titan_lpeglabel_namespace.h": "233f2208d0669204031c3475abe4ae3dc376f9381fa1ace36d2330e41554640f"
  },
  "tools": {
    "ar": {
      "argv": [
        "/usr/bin/ar"
      ],
      "executable_sha256": "97910d3148c2a6bbaf899821e6f6c07c602fcd1ef00f081ec7a58a348288b7c5"
    },
    "cc": {
      "argv": [
        "/usr/bin/gcc"
      ],
      "executable_sha256": "153e46b4657620f2baef1b4a70b4b4f275772faa5b0fb9e415697e87ebcb7fea"
    },
    "ranlib": {
      "argv": [
        "/usr/bin/ranlib"
      ],
      "executable_sha256": "dc7e8f99cf5956e5ba2540f61f213cc4bbfa08ba2d40a33fe2adbfe726f2948d"
    }
  }
}
```

</details>

## Measured results

Catalog: 53 cases; this report contains 53 measured cases.

Uninstrumented timing uses the original immutable SDK. Instrumented timing uses a private full-provider rebuild with source-scoped semantic probes and the original native payload. The difference below is instrumentation overhead, not a production speedup.

### Uninstrumented end-to-end timing

| Case | Protocol | Rounds / samples | us/op median [range] | RTT p50/p95/p99 us | ops/s | Cold first use us | Residual GC us/op | Retire us |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `call_control` | `same_state` | 6 / 60000 | 0.054 [0.052..0.062] | 0.030/0.030/0.031 | 18628314.5 | 8813.7 | 0.044 | 0.4 |
| `churn_cancel_parked_waiters` | `cancel_churn` | 6 / 3000 | 79.327 [74.256..87.209] | 52.678/163.320/522.226 | 12612.1 | 8896.1 | 3.895 | 57.2 |
| `churn_close_parked_receivers` | `close_churn` | 6 / 3000 | 22.080 [20.688..38.787] | 13.535/40.526/216.730 | 45334.5 | 8583.2 | 5.974 | 53.7 |
| `churn_close_parked_senders` | `close_churn` | 6 / 3000 | 38.840 [35.470..49.719] | 26.961/60.689/316.887 | 25786.3 | 8663.1 | 7.843 | 56.2 |
| `closure_roundtrip_cap0` | `same_state` | 6 / 6000 | 6.127 [5.211..8.367] | 4.012/14.136/56.049 | 163220.7 | 8300.7 | 0.819 | 2.0 |
| `closure_roundtrip_cap1` | `same_state` | 6 / 6000 | 12.171 [8.116..15.431] | 6.422/37.835/74.099 | 82197.7 | 7711.4 | 0.804 | 2.2 |
| `closure_roundtrip_cap64` | `same_state` | 6 / 6000 | 152.379 [149.485..159.209] | 84.393/621.201/873.894 | 6562.7 | 7581.5 | 1.296 | 2.7 |
| `closure_roundtrip_cap8` | `same_state` | 6 / 6000 | 23.807 [22.640..29.112] | 14.271/105.748/168.320 | 42011.5 | 8108.1 | 1.112 | 2.3 |
| `closure_roundtrip_complex_sig` | `same_state` | 6 / 6000 | 9.864 [9.230..11.251] | 6.553/24.435/70.216 | 101383.0 | 7623.7 | 0.858 | 2.1 |
| `codec_large64k_decode` | `same_state` | 6 / 1536 | 7.210 [6.872..9.760] | 2.830/18.905/75.577 | 138697.3 | 6981.0 | 2.325 | 1.7 |
| `codec_large64k_encode` | `same_state` | 6 / 1536 | 9.292 [7.589..11.380] | 4.053/21.982/83.511 | 110290.9 | 7809.5 | 2.275 | 2.0 |
| `codec_large64k_transfer_roundtrip` | `same_state` | 6 / 1536 | 11.571 [8.988..13.604] | 6.016/27.066/73.627 | 86525.1 | 9276.1 | 2.810 | 2.2 |
| `codec_scalar_roundtrip` | `same_state` | 6 / 30000 | 0.150 [0.148..0.163] | 0.120/0.171/0.226 | 6662883.3 | 8300.3 | 0.098 | 0.8 |
| `codec_small_decode` | `same_state` | 6 / 30000 | 1.000 [0.969..1.431] | 0.601/1.377/4.914 | 1000230.0 | 8308.0 | 0.175 | 2.0 |
| `codec_small_encode` | `same_state` | 6 / 30000 | 0.458 [0.434..0.710] | 0.351/1.002/1.317 | 2185906.6 | 8656.6 | 0.180 | 1.3 |
| `codec_small_transfer_roundtrip` | `same_state` | 6 / 30000 | 1.943 [1.871..3.007] | 1.232/2.184/11.537 | 514912.3 | 8601.2 | 0.178 | 2.1 |
| `codec_wide16_decode` | `same_state` | 6 / 30000 | 2.559 [2.325..4.153] | 1.593/3.236/33.938 | 390832.2 | 8551.0 | 0.186 | 2.3 |
| `codec_wide16_encode` | `same_state` | 6 / 30000 | 1.070 [1.048..2.041] | 0.927/1.618/3.075 | 934443.6 | 7521.4 | 0.209 | 1.5 |
| `codec_wide16_transfer_roundtrip` | `same_state` | 6 / 30000 | 3.937 [3.847..4.310] | 2.780/5.280/43.517 | 254047.1 | 8898.5 | 0.149 | 2.2 |
| `inspect_function` | `same_state` | 6 / 6000 | 2.033 [2.010..2.578] | 1.793/2.550/5.530 | 491922.2 | 9134.1 | 1.061 | 1.5 |
| `inspect_record` | `same_state` | 6 / 30000 | 0.165 [0.152..0.227] | 0.111/0.181/0.746 | 6069475.7 | 8578.5 | 0.115 | 1.0 |
| `join_cleanup_cancelled_task` | `cleanup_join` | 6 / 600 | 43058.681 [37222.852..47639.887] | 46137.246/49057.289/52980.556 | 23.2 | 7065.2 | 20.488 | 49.7 |
| `join_ordinary` | `ordinary_join` | 6 / 600 | 7233.531 [6291.965..8476.651] | 7275.733/8371.986/8633.736 | 139.8 | 8634.7 | 33.365 | 58.7 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | `pool_16_reply` | 6 / 6000 | 3.103 [2.459..4.538] | 36.218/89.126/141.649 | 323767.3 | 6624.3 | 1.143 | 4975.7 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | `pool_16_reply` | 6 / 6000 | 3.376 [2.535..4.297] | 38.438/83.010/118.406 | 296263.4 | 8310.9 | 1.116 | 4930.5 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 17.720 [16.435..23.928] | 15.999/23.053/40.426 | 56434.3 | 8765.5 | 0.872 | 4274.9 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 5.610 [5.402..7.018] | 19.361/34.505/55.469 | 178266.5 | 8545.5 | 0.995 | 4528.2 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | `pool_four_reply` | 6 / 6000 | 5.640 [5.425..8.284] | 19.717/30.462/53.570 | 177512.6 | 8499.8 | 1.075 | 4664.7 |
| `mpmc_record_inflight16_cap16_4p4c` | `pool_16_reply` | 6 / 6000 | 3.363 [2.899..4.323] | 35.241/118.521/192.740 | 297388.3 | 8679.8 | 1.243 | 4373.9 |
| `mpmc_record_inflight16_cap2_4p4c` | `pool_16_reply` | 6 / 6000 | 3.495 [2.547..3.746] | 29.335/140.642/219.987 | 286301.8 | 7741.3 | 0.813 | 4453.3 |
| `mpmc_record_inflight1_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 17.193 [14.053..19.662] | 13.330/27.987/40.806 | 58229.2 | 8119.7 | 1.102 | 3569.8 |
| `mpmc_record_inflight4_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 4.935 [4.015..6.459] | 16.831/30.341/44.759 | 202783.9 | 8298.0 | 0.702 | 4202.9 |
| `mpmc_record_inflight4_cap4_2p2c` | `pool_four_reply` | 6 / 6000 | 4.925 [3.883..7.177] | 16.465/26.920/49.993 | 203115.2 | 9162.9 | 0.861 | 3827.5 |
| `overhead_control` | `same_state` | 6 / 60000 | 0.066 [0.065..0.067] | 0.040/0.041/0.045 | 15176283.6 | 8124.8 | 0.043 | 0.6 |
| `queue_opaque_hook8` | `same_state_queue` | 6 / 30000 | 2.700 [2.611..2.847] | 1.864/2.915/40.550 | 370329.7 | 7513.1 | 0.209 | 58.7 |
| `queue_packed_hook8` | `same_state_queue` | 6 / 30000 | 3.797 [3.660..5.002] | 2.415/4.659/43.271 | 263372.2 | 7528.6 | 0.177 | 73.5 |
| `queue_plain_bytes8` | `same_state_queue` | 6 / 30000 | 2.195 [1.967..2.881] | 1.393/3.191/16.090 | 456372.0 | 8138.2 | 0.240 | 72.1 |
| `queue_real_receiver` | `same_state_queue` | 6 / 30000 | 4.260 [4.144..6.823] | 2.720/8.331/46.397 | 234739.4 | 8376.3 | 0.210 | 79.0 |
| `queue_real_sender` | `same_state_queue` | 6 / 30000 | 4.407 [3.982..5.583] | 2.690/8.431/49.933 | 227059.1 | 7076.2 | 0.216 | 74.9 |
| `sender_clone` | `same_state_queue` | 6 / 30000 | 0.199 [0.190..0.407] | 0.155/0.226/0.732 | 5035108.2 | 8604.5 | 0.171 | 36.6 |
| `spsc_endpoint_carried_persistent` | `persistent_reply` | 6 / 6000 | 16.991 [12.661..25.887] | 13.155/34.775/82.199 | 59901.1 | 9138.9 | 1.124 | 1093.5 |
| `spsc_endpoint_fresh_reply` | `fresh_reply` | 6 / 3000 | 18.137 [11.926..20.844] | 16.816/26.124/40.255 | 55179.1 | 9033.6 | 3.276 | 1774.7 |
| `spsc_endpoint_pool4_reply` | `pool_four_reply` | 6 / 6000 | 19.493 [18.517..26.307] | 15.604/42.164/96.295 | 51301.8 | 7981.5 | 1.743 | 1119.2 |
| `spsc_large64k_endpoint_pool4` | `pool_four_reply` | 6 / 1536 | 39.647 [22.097..44.586] | 34.655/74.976/166.781 | 25249.1 | 7825.3 | 6.449 | 1042.3 |
| `spsc_large64k_persistent` | `persistent_reply` | 6 / 1536 | 31.968 [18.186..39.230] | 24.160/58.960/171.911 | 31403.9 | 8453.0 | 4.096 | 919.9 |
| `spsc_opaque_persistent` | `persistent_reply` | 6 / 6000 | 18.486 [12.585..23.501] | 13.896/44.047/86.882 | 54095.7 | 7271.1 | 1.223 | 930.5 |
| `spsc_record_persistent` | `persistent_reply` | 6 / 6000 | 16.217 [10.502..20.095] | 13.931/29.540/75.992 | 61857.8 | 8439.8 | 1.828 | 1571.3 |
| `spsc_record_pool4_control` | `pool_four_reply` | 6 / 6000 | 14.025 [10.833..20.378] | 10.866/22.707/73.848 | 71496.4 | 8085.2 | 1.383 | 1636.7 |
| `spsc_scalar_persistent` | `persistent_reply` | 6 / 6000 | 5.933 [4.813..8.148] | 5.886/10.064/15.979 | 168569.8 | 8758.6 | 1.383 | 1299.7 |
| `wait_empty_receiver_endpoint` | `directed_empty_wait` | 6 / 3000 | 28.478 [23.569..42.883] | 19.547/55.238/181.309 | 35452.9 | 8434.8 | 3.206 | 1593.2 |
| `wait_empty_receiver_record` | `directed_empty_wait` | 6 / 3000 | 29.841 [21.469..36.538] | 18.179/58.299/238.941 | 33534.6 | 7535.1 | 3.114 | 1323.5 |
| `wait_full_sender_endpoint` | `directed_full_wait` | 6 / 3000 | 32.341 [29.345..43.025] | 24.706/69.399/182.231 | 30924.4 | 6660.3 | 6.202 | 1794.0 |
| `wait_full_sender_record` | `directed_full_wait` | 6 / 3000 | 28.801 [27.512..31.957] | 19.411/59.972/163.355 | 34720.5 | 8279.4 | 4.067 | 1615.1 |

RTT columns are medians of per-round percentiles, not pooled percentiles. Directed full-sender samples are admission/previous-packet release acknowledgements, not processing RTTs for the newly admitted request. Churn includes fresh resource/state creation.

### Exact native branch counts (representative instrumented round)

Counters/per-op traffic select the actual upper-median body-time round; all instrumented rounds remain in the summary JSON. Counts are branch events within the body window, including worker request receives and protocol-control channels. A wait can begin before the window. Fast successes are successful first readiness checks, not post-suspension retry successes. Closed outcomes are never counted as successful fast paths/rechecks. Slow attempts are failed ready checks entering registration; native suspensions, successful registration rechecks, selected waiter notification attempts and nominal CancellationReason errors are separate events.

| Case | Fast | Slow | Recheck OK | Suspends | Ordinary / cleanup join suspends | Notify | Cancel | Async init / public close requests |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `call_control` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `churn_cancel_parked_waiters` | 500 | 1000 | 0 | 1000 | 0 / 0 | 0 | 1000 | 1000 / 1000 |
| `churn_close_parked_receivers` | 0 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `churn_close_parked_senders` | 500 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `closure_roundtrip_cap0` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap1` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap64` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap8` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_complex_sig` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_decode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_encode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_scalar_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_small_decode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_small_encode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_small_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_decode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_encode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `inspect_function` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `inspect_record` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `join_cleanup_cancelled_task` | 300 | 600 | 0 | 600 | 100 / 100 | 400 | 200 | 800 / 700 |
| `join_ordinary` | 200 | 300 | 0 | 300 | 100 / 0 | 300 | 0 | 500 / 400 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 4360 | 2689 | 302 | 2387 | 0 / 0 | 2447 | 0 | 2689 / 2749 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 4353 | 2669 | 329 | 2340 | 0 / 0 | 2400 | 0 | 2669 / 2729 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 4003 | 2505 | 1 | 2504 | 0 / 0 | 2504 | 0 | 2505 / 2505 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 4165 | 2614 | 367 | 2247 | 0 / 0 | 2253 | 0 | 2614 / 2620 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 4247 | 2422 | 260 | 2162 | 0 / 0 | 2168 | 0 | 2422 / 2428 |
| `mpmc_record_inflight16_cap16_4p4c` | 4681 | 2216 | 144 | 2072 | 0 / 0 | 2132 | 0 | 2216 / 2276 |
| `mpmc_record_inflight16_cap2_4p4c` | 4363 | 2644 | 307 | 2337 | 0 / 0 | 2397 | 0 | 2644 / 2704 |
| `mpmc_record_inflight1_cap1_2p2c` | 4003 | 2504 | 0 | 2504 | 0 / 0 | 2504 | 0 | 2504 / 2504 |
| `mpmc_record_inflight4_cap1_2p2c` | 4110 | 2642 | 385 | 2257 | 0 / 0 | 2263 | 0 | 2642 / 2648 |
| `mpmc_record_inflight4_cap4_2p2c` | 4238 | 2432 | 264 | 2168 | 0 / 0 | 2174 | 0 | 2432 / 2438 |
| `overhead_control` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_opaque_hook8` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_packed_hook8` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_plain_bytes8` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_real_receiver` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_real_sender` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `sender_clone` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `spsc_endpoint_carried_persistent` | 2000 | 2000 | 1 | 1999 | 0 / 0 | 1999 | 0 | 2000 / 2000 |
| `spsc_endpoint_fresh_reply` | 1000 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `spsc_endpoint_pool4_reply` | 2000 | 2000 | 25 | 1975 | 0 / 0 | 1975 | 0 | 2000 / 2000 |
| `spsc_large64k_endpoint_pool4` | 512 | 512 | 1 | 511 | 0 / 0 | 511 | 0 | 512 / 512 |
| `spsc_large64k_persistent` | 512 | 512 | 0 | 512 | 0 / 0 | 512 | 0 | 512 / 512 |
| `spsc_opaque_persistent` | 2000 | 2000 | 28 | 1972 | 0 / 0 | 1972 | 0 | 2000 / 2000 |
| `spsc_record_persistent` | 2000 | 2000 | 6 | 1994 | 0 / 0 | 1994 | 0 | 2000 / 2000 |
| `spsc_record_pool4_control` | 2000 | 2000 | 0 | 2000 | 0 / 0 | 2000 | 0 | 2000 / 2000 |
| `spsc_scalar_persistent` | 2000 | 2000 | 97 | 1903 | 0 / 0 | 1903 | 0 | 2000 / 2000 |
| `wait_empty_receiver_endpoint` | 1000 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `wait_empty_receiver_record` | 1000 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `wait_full_sender_endpoint` | 1578 | 1422 | 120 | 1302 | 0 / 0 | 1302 | 0 | 1422 / 1422 |
| `wait_full_sender_record` | 1926 | 1074 | 53 | 1021 | 0 / 0 | 1021 | 0 | 1074 / 1074 |

### Native async handle retirement (representative instrumented round)

| Case | Whole-case async init | Public close requests | Terminal close callbacks | Async retirements at successful loop close | Successful / attempted loop closes |
|---|---:|---:|---:|---:|---:|
| `call_control` | 0 | 0 | 0 | 0 | 0 / 0 |
| `churn_cancel_parked_waiters` | 1065 | 1064 | 1064 | 1 | 1 / 1 |
| `churn_close_parked_receivers` | 1065 | 1064 | 1064 | 1 | 1 / 1 |
| `churn_close_parked_senders` | 1065 | 1064 | 1064 | 1 | 1 / 1 |
| `closure_roundtrip_cap0` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap1` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap64` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap8` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_complex_sig` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_decode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_encode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_scalar_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_small_decode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_small_encode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_small_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_decode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_encode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `inspect_function` | 0 | 0 | 0 | 0 | 0 / 0 |
| `inspect_record` | 0 | 0 | 0 | 0 | 0 / 0 |
| `join_cleanup_cancelled_task` | 865 | 756 | 756 | 109 | 109 / 109 |
| `join_ordinary` | 541 | 432 | 432 | 109 | 109 / 109 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 13759 | 13750 | 13750 | 9 | 9 / 9 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 14315 | 14306 | 14306 | 9 | 9 / 9 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 2849 | 2844 | 2844 | 5 | 5 / 5 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 3960 | 3955 | 3955 | 5 | 5 / 5 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 3714 | 3709 | 3709 | 5 | 5 / 5 |
| `mpmc_record_inflight16_cap16_4p4c` | 13333 | 13324 | 13324 | 9 | 9 / 9 |
| `mpmc_record_inflight16_cap2_4p4c` | 14294 | 14285 | 14285 | 9 | 9 / 9 |
| `mpmc_record_inflight1_cap1_2p2c` | 2832 | 2827 | 2827 | 5 | 5 / 5 |
| `mpmc_record_inflight4_cap1_2p2c` | 3960 | 3955 | 3955 | 5 | 5 / 5 |
| `mpmc_record_inflight4_cap4_2p2c` | 3721 | 3716 | 3716 | 5 | 5 / 5 |
| `overhead_control` | 0 | 0 | 0 | 0 | 0 / 0 |
| `queue_opaque_hook8` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_packed_hook8` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_plain_bytes8` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_real_receiver` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_real_sender` | 1 | 0 | 0 | 1 | 1 / 1 |
| `sender_clone` | 1 | 0 | 0 | 1 | 1 / 1 |
| `spsc_endpoint_carried_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_endpoint_fresh_reply` | 1070 | 1068 | 1068 | 2 | 2 / 2 |
| `spsc_endpoint_pool4_reply` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_large64k_endpoint_pool4` | 550 | 548 | 548 | 2 | 2 / 2 |
| `spsc_large64k_persistent` | 550 | 548 | 548 | 2 | 2 / 2 |
| `spsc_opaque_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_record_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_record_pool4_control` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_scalar_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `wait_empty_receiver_endpoint` | 1070 | 1068 | 1068 | 2 | 2 / 2 |
| `wait_empty_receiver_record` | 1070 | 1068 | 1068 | 2 | 2 / 2 |
| `wait_full_sender_endpoint` | 1524 | 1522 | 1522 | 2 | 2 / 2 |
| `wait_full_sender_record` | 1176 | 1174 | 1174 | 2 | 2 / 2 |

Whole-case counters start at the setup snapshot after cold first use; identities are tracked from process birth, including cold loops. Libuv initializes loop-internal async handles through uv_async_init but retires them directly during successful uv_loop_close. Those retirements are not fabricated public close requests or callbacks. A busy/failed loop close retires no identity; active_async_handles remains the actual unretired registry count and must be zero. Real UV allocation traffic is not suppressed.


### Allocation and observed copy traffic

| Case | Lua allocs / requested B per op | Native allocs / requested B per op | Interposed copy B/op (outside / inside Lua allocator) | Analytical reference B/op (not wire/copy bytes) |
|---|---:|---:|---:|---:|
| `call_control` | 0.00 / 0.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 0 |
| `churn_cancel_parked_waiters` | 104.19 / 26212.6 | 8.00 / 512.0 | 9963.8 (9963.8 / 0.0) | 0 |
| `churn_close_parked_receivers` | 84.72 / 18483.2 | 3.00 / 152.0 | 47.6 (47.6 / 0.0) | 0 |
| `churn_close_parked_senders` | 88.64 / 19730.0 | 6.00 / 464.0 | 2411.3 (2411.3 / 0.0) | 0 |
| `closure_roundtrip_cap0` | 100.01 / 5011.6 | 1.00 / 128.0 | 212.0 (212.0 / 0.0) | 0 |
| `closure_roundtrip_cap1` | 153.02 / 7916.8 | 2.00 / 384.0 | 373.1 (373.1 / 0.0) | 0 |
| `closure_roundtrip_cap64` | 3148.12 / 194027.1 | 4.00 / 1920.0 | 12147.5 (12147.5 / 0.0) | 0 |
| `closure_roundtrip_cap8` | 498.03 / 28580.6 | 2.00 / 384.0 | 1612.4 (1612.4 / 0.0) | 0 |
| `closure_roundtrip_complex_sig` | 168.02 / 9797.2 | 2.00 / 384.0 | 556.4 (556.4 / 0.0) | 0 |
| `codec_large64k_decode` | 16.02 / 66349.6 | 0.00 / 0.0 | 65562.0 (65562.0 / 0.0) | 65540 |
| `codec_large64k_encode` | 7.02 / 65953.6 | 2.00 / 131136.0 | 131076.0 (131076.0 / 0.0) | 65540 |
| `codec_large64k_transfer_roundtrip` | 25.02 / 66969.7 | 2.00 / 131200.0 | 131113.0 (131113.0 / 0.0) | 65540 |
| `codec_scalar_roundtrip` | 1.00 / 48.0 | 1.00 / 104.0 | 0.0 (0.0 / 0.0) | 8 |
| `codec_small_decode` | 21.00 / 1049.0 | 0.00 / 0.0 | 83.0 (83.0 / 0.0) | 11 |
| `codec_small_encode` | 6.00 / 380.0 | 1.00 / 64.0 | 7.0 (7.0 / 0.0) | 11 |
| `codec_small_transfer_roundtrip` | 30.00 / 1669.0 | 2.00 / 384.0 | 106.0 (106.0 / 0.0) | 11 |
| `codec_wide16_decode` | 44.00 / 3805.2 | 0.00 / 0.0 | 749.0 (749.0 / 0.0) | 33 |
| `codec_wide16_encode` | 6.00 / 380.0 | 1.00 / 64.0 | 0.0 (0.0 / 0.0) | 33 |
| `codec_wide16_transfer_roundtrip` | 53.00 / 4425.0 | 2.00 / 384.0 | 764.0 (764.0 / 0.0) | 33 |
| `inspect_function` | 50.01 / 2376.4 | 0.00 / 0.0 | 80.0 (80.0 / 0.0) | 0 |
| `inspect_record` | 2.00 / 172.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 0 |
| `join_cleanup_cancelled_task` | 25096.52 / 4044795.2 | 26.00 / 3560.0 | 4964494.0 (4964494.0 / 0.0) | 0 |
| `join_ordinary` | 24607.20 / 3985630.1 | 19.00 / 2640.0 | 1645086.7 (1645086.7 / 0.0) | 0 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 138.23 / 9608.8 | 5.07 / 879.1 | 325.3 (325.3 / 0.0) | 0 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 137.84 / 9568.7 | 5.07 / 879.1 | 325.3 (325.3 / 0.0) | 0 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 135.44 / 9311.3 | 5.00 / 872.4 | 325.0 (325.0 / 0.0) | 0 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 136.41 / 9448.1 | 5.01 / 873.0 | 325.0 (325.0 / 0.0) | 0 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 134.12 / 9197.1 | 5.01 / 873.0 | 325.1 (325.1 / 0.0) | 0 |
| `mpmc_record_inflight16_cap16_4p4c` | 101.76 / 7124.5 | 5.07 / 879.1 | 265.4 (265.4 / 0.0) | 0 |
| `mpmc_record_inflight16_cap2_4p4c` | 107.25 / 7709.0 | 5.07 / 879.1 | 265.3 (265.3 / 0.0) | 0 |
| `mpmc_record_inflight1_cap1_2p2c` | 105.41 / 7479.5 | 5.00 / 872.4 | 265.0 (265.0 / 0.0) | 0 |
| `mpmc_record_inflight4_cap1_2p2c` | 106.64 / 7654.2 | 5.01 / 873.0 | 265.0 (265.0 / 0.0) | 0 |
| `mpmc_record_inflight4_cap4_2p2c` | 104.26 / 7385.5 | 5.01 / 873.0 | 265.1 (265.1 / 0.0) | 0 |
| `overhead_control` | 0.00 / 0.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 0 |
| `queue_opaque_hook8` | 42.00 / 2525.0 | 2.00 / 384.0 | 139.0 (139.0 / 0.0) | 21 |
| `queue_packed_hook8` | 63.00 / 3633.0 | 2.00 / 384.0 | 196.0 (196.0 / 0.0) | 21 |
| `queue_plain_bytes8` | 34.00 / 1933.0 | 2.00 / 384.0 | 139.0 (139.0 / 0.0) | 21 |
| `queue_real_receiver` | 64.00 / 3761.1 | 2.00 / 384.0 | 198.0 (198.0 / 0.0) | 21 |
| `queue_real_sender` | 64.00 / 3761.1 | 2.00 / 384.0 | 196.0 (196.0 / 0.0) | 21 |
| `sender_clone` | 2.00 / 168.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 21 |
| `spsc_endpoint_carried_persistent` | 126.47 / 8512.2 | 4.00 / 768.0 | 325.0 (325.0 / 0.0) | 29 |
| `spsc_endpoint_fresh_reply` | 132.19 / 8886.6 | 7.00 / 920.0 | 325.0 (325.0 / 0.0) | 29 |
| `spsc_endpoint_pool4_reply` | 126.43 / 8509.1 | 4.00 / 768.0 | 325.0 (325.0 / 0.0) | 29 |
| `spsc_large64k_endpoint_pool4` | 127.50 / 74078.4 | 4.00 / 131584.0 | 131392.0 (131392.0 / 0.0) | 65565 |
| `spsc_large64k_persistent` | 97.47 / 72251.4 | 4.00 / 131584.0 | 131330.0 (131330.0 / 0.0) | 65565 |
| `spsc_opaque_persistent` | 104.37 / 7268.4 | 4.00 / 768.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_record_persistent` | 96.22 / 6661.2 | 4.00 / 768.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_record_pool4_control` | 96.47 / 6685.6 | 4.00 / 768.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_scalar_persistent` | 32.30 / 2995.4 | 2.00 / 208.0 | 0.0 (0.0 / 0.0) | 16 |
| `wait_empty_receiver_endpoint` | 125.17 / 18054.3 | 3.00 / 488.0 | 229.3 (229.3 / 0.0) | 29 |
| `wait_empty_receiver_record` | 93.15 / 12813.2 | 3.00 / 488.0 | 169.3 (169.3 / 0.0) | 29 |
| `wait_full_sender_endpoint` | 169.58 / 21054.5 | 5.00 / 872.0 | 355.3 (355.3 / 0.0) | 29 |
| `wait_full_sender_record` | 127.28 / 14829.9 | 5.00 / 872.0 | 295.3 (295.3 / 0.0) | 29 |

Lua allocator requests include state birth and terminal close. Only allocations made inside the underlying Lua allocator are excluded from native traffic; real UV allocations are not suppressed. Copy counts cover interposed memcpy **and memmove** calls, not inlined copies, scalar stores or libc-internal copying. Actual total wire bytes are unavailable; the analytical reference can use a different payload/ID and is not presented as measured transfer traffic.

### Lifecycle and post-retirement evidence (all instrumented rounds)

| Case | Rounds | Channels delta range | Controls delta range | Active worker range | Lua state delta / active async handles / pending wait probes | Observed native block / usable B net ranges | Host Lua net B range | Checksums / lifecycle |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| `call_control` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `churn_cancel_parked_waiters` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 137.0..137.0 | valid |
| `churn_close_parked_receivers` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 36.0..36.0 | valid |
| `churn_close_parked_senders` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 137.0..137.0 | valid |
| `closure_roundtrip_cap0` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `closure_roundtrip_cap1` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `closure_roundtrip_cap64` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `closure_roundtrip_cap8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `closure_roundtrip_complex_sig` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_large64k_decode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_large64k_encode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_large64k_transfer_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8809.0..8809.0 | valid |
| `codec_scalar_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_small_decode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_small_encode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_small_transfer_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8809.0..8809.0 | valid |
| `codec_wide16_decode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_wide16_encode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_wide16_transfer_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8809.0..8809.0 | valid |
| `inspect_function` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `inspect_record` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `join_cleanup_cancelled_task` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 3399.0..3399.0 | valid |
| `join_ordinary` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 36.0..36.0 | valid |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8664.0..8664.0 | valid |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8664.0..8664.0 | valid |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7800.0..7800.0 | valid |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7800.0..7800.0 | valid |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7800.0..7800.0 | valid |
| `mpmc_record_inflight16_cap16_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 10879.0..10879.0 | valid |
| `mpmc_record_inflight16_cap2_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 10879.0..10879.0 | valid |
| `mpmc_record_inflight1_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 10015.0..10015.0 | valid |
| `mpmc_record_inflight4_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 10015.0..10015.0 | valid |
| `mpmc_record_inflight4_cap4_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 10015.0..10015.0 | valid |
| `overhead_control` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `queue_opaque_hook8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 5638.0..5638.0 | valid |
| `queue_packed_hook8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 5638.0..5638.0 | valid |
| `queue_plain_bytes8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 45.0..45.0 | valid |
| `queue_real_receiver` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2422.0..2422.0 | valid |
| `queue_real_sender` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2422.0..2422.0 | valid |
| `sender_clone` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | -71.0..-71.0 | valid |
| `spsc_endpoint_carried_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2413.0..2413.0 | valid |
| `spsc_endpoint_fresh_reply` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2395.0..2395.0 | valid |
| `spsc_endpoint_pool4_reply` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2395.0..2395.0 | valid |
| `spsc_large64k_endpoint_pool4` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2395.0..2395.0 | valid |
| `spsc_large64k_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2105.0..2105.0 | valid |
| `spsc_opaque_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 5629.0..5629.0 | valid |
| `spsc_record_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | -12.0..-12.0 | valid |
| `spsc_record_pool4_control` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2251.0..2251.0 | valid |
| `spsc_scalar_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | -12.0..-12.0 | valid |
| `wait_empty_receiver_endpoint` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2473.0..2473.0 | valid |
| `wait_empty_receiver_record` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 180.0..180.0 | valid |
| `wait_full_sender_endpoint` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2446.0..2446.0 | valid |
| `wait_full_sender_record` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 39.0..39.0 | valid |

Channel/control counts are actual native birth/destruction probes. Worker quiescence waits for the native end-of-worker release, not a fixed number of loop turns or public join alone; it is native domain-ownership retirement evidence, not an OS-join proof. The pre-wake resource-ownership correctness checkpoint intentionally retains known legacy detached-thread/proxy-early-terminal behavior and is not final Thread approval. The separate final corrected wake/join candidate requires actual OS join before every proxy terminal and full platform correctness evidence. Explicit residual collections occur outside body timing. The allocator's signed net delta is an observed ledger, **not** a complete retained-native-memory oracle; lifecycle counts are reported separately. Failed calibration, missing/truncated samples, checksum errors and unretired native domains reject a campaign.

### Overlapping source-scoped stage intervals

| Case | Wake attribution | Sender entry through encode | Queue lock + branch | Registration after failed check | Notify to continuation | Post-dequeue decode + return | Reply processing |
|---|---|---:|---:|---:|---:|---:|---:|
| `call_control` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `churn_cancel_parked_waiters` | `unavailable_cancelled_or_nonunique_notification` | 1.002/34.885 (1000 total; 500..500/round) | 0.035/0.290 (5000 total; 2500..2500/round) | 0.892/34.795 (2000 total; 1000..1000/round) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `churn_close_parked_receivers` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.035/0.286 (6000 total; 3000..3000/round) | 0.977/19.627 (2000 total; 1000..1000/round) | 2.023/6.552 (2000 total; 1000..1000/round) | unavailable (0 samples) | unavailable (0 samples) |
| `churn_close_parked_senders` | `exact_waiter_notification_to_continuation` | 0.897/22.627 (2000 total; 1000..1000/round) | 0.030/0.265 (7000 total; 3500..3500/round) | 0.686/2.074 (2000 total; 1000..1000/round) | 6.928/24.877 (2000 total; 1000..1000/round) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap0` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap1` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap64` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap8` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_complex_sig` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_large64k_decode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_large64k_encode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_large64k_transfer_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_scalar_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_small_decode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_small_encode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_small_transfer_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_wide16_decode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_wide16_encode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_wide16_transfer_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `inspect_function` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `inspect_record` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `join_cleanup_cancelled_task` | `partial_exact_only` | unavailable (0 samples) | 0.395/8.255 (3200 total; 1600..1600/round) | unavailable (0 samples) | 22.873/54.938 (800 total; 400..400/round) | unavailable (0 samples) | unavailable (0 samples) |
| `join_ordinary` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.466/7.053 (1800 total; 900..900/round) | unavailable (0 samples) | 16.236/44.158 (600 total; 300..300/round) | unavailable (0 samples) | unavailable (0 samples) |
| `mpmc_endpoint_inflight16_cap16_4p4c` | `exact_waiter_notification_to_continuation` | 4.017/11.672 (4000 total; 2000..2000/round) | 0.251/6.848 (22492 total; 11212..11280/round) | 3.181/7.168 (2000 total; 1000..1000/round) | 55.234/149.905 (4925 total; 2447..2478/round) | 6.287/11.957 (2000 total; 1000..1000/round) | 0.035/0.080 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight16_cap2_4p4c` | `exact_waiter_notification_to_continuation` | 4.008/12.073 (4000 total; 2000..2000/round) | 0.355/10.389 (22562 total; 11145..11417/round) | 3.316/7.279 (2068 total; 1034..1034/round) | 60.022/213.434 (4944 total; 2400..2544/round) | 6.096/13.139 (2000 total; 1000..1000/round) | 0.035/0.075 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight1_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 2.585/7.710 (4000 total; 2000..2000/round) | 0.136/1.357 (22033 total; 11016..11017/round) | 1.238/4.844 (2000 total; 1000..1000/round) | 3.207/10.369 (5008 total; 2504..2504/round) | 2.304/7.108 (2000 total; 1000..1000/round) | 0.030/0.055 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight4_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 3.115/6.883 (4000 total; 2000..2000/round) | 0.150/3.166 (21684 total; 10803..10881/round) | 1.833/5.205 (2333 total; 1144..1189/round) | 10.244/30.117 (4466 total; 2213..2253/round) | 3.796/10.284 (2000 total; 1000..1000/round) | 0.025/0.060 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight4_cap4_2p2c` | `exact_waiter_notification_to_continuation` | 3.001/9.387 (4000 total; 2000..2000/round) | 0.105/3.251 (21083 total; 10479..10604/round) | 1.659/6.166 (2000 total; 1000..1000/round) | 10.059/38.036 (4305 total; 2137..2168/round) | 3.542/13.816 (2000 total; 1000..1000/round) | 0.030/0.065 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight16_cap16_4p4c` | `exact_waiter_notification_to_continuation` | 2.570/32.651 (4000 total; 2000..2000/round) | 0.216/8.345 (21147 total; 10424..10723/round) | 3.516/7.464 (2000 total; 1000..1000/round) | 39.924/142.326 (4364 total; 2132..2232/round) | 6.422/14.171 (2000 total; 1000..1000/round) | 0.035/0.066 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight16_cap2_4p4c` | `exact_waiter_notification_to_continuation` | 2.159/6.718 (4000 total; 2000..2000/round) | 0.321/9.052 (22412 total; 11117..11295/round) | 3.121/7.824 (2205 total; 1042..1163/round) | 46.481/145.558 (4864 total; 2397..2467/round) | 5.476/12.263 (2000 total; 1000..1000/round) | 0.025/0.061 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight1_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 1.403/6.602 (4000 total; 2000..2000/round) | 0.126/1.328 (22032 total; 11016..11016/round) | 1.643/5.410 (2000 total; 1000..1000/round) | 3.442/8.511 (5008 total; 2504..2504/round) | 2.434/8.651 (2000 total; 1000..1000/round) | 0.035/0.050 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight4_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 1.804/5.946 (4000 total; 2000..2000/round) | 0.161/3.968 (21839 total; 10919..10920/round) | 2.179/7.484 (2421 total; 1203..1218/round) | 10.314/37.079 (4510 total; 2247..2263/round) | 4.067/11.221 (2000 total; 1000..1000/round) | 0.035/0.065 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight4_cap4_2p2c` | `exact_waiter_notification_to_continuation` | 1.423/4.378 (4000 total; 2000..2000/round) | 0.091/2.876 (21133 total; 10513..10620/round) | 1.518/4.458 (2000 total; 1000..1000/round) | 8.736/30.297 (4270 total; 2096..2174/round) | 3.156/8.822 (2000 total; 1000..1000/round) | 0.030/0.040 (2000 total; 1000..1000/round) |
| `overhead_control` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `queue_opaque_hook8` | `no_suspensions` | 1.031/8.069 (10000 total; 5000..5000/round) | 0.030/0.150 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.393/10.595 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_packed_hook8` | `no_suspensions` | 1.498/66.635 (10000 total; 5000..5000/round) | 0.030/0.160 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.718/21.265 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_plain_bytes8` | `no_suspensions` | 0.711/3.181 (10000 total; 5000..5000/round) | 0.030/0.066 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.157/7.584 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_real_receiver` | `no_suspensions` | 1.538/14.357 (10000 total; 5000..5000/round) | 0.030/0.135 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.828/29.751 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_real_sender` | `no_suspensions` | 1.553/17.162 (10000 total; 5000..5000/round) | 0.030/0.165 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.838/54.817 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `sender_clone` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `spsc_endpoint_carried_persistent` | `exact_waiter_notification_to_continuation` | 2.796/29.730 (4000 total; 2000..2000/round) | 0.190/13.200 (15974 total; 7975..7999/round) | 1.323/32.986 (2000 total; 1000..1000/round) | 2.970/11.957 (3974 total; 1975..1999/round) | 2.319/35.326 (2000 total; 1000..1000/round) | 0.100/1.643 (2000 total; 1000..1000/round) |
| `spsc_endpoint_fresh_reply` | `exact_waiter_notification_to_continuation` | 2.179/7.489 (2000 total; 1000..1000/round) | 0.190/1.007 (8000 total; 4000..4000/round) | 0.972/4.278 (1000 total; 500..500/round) | 2.419/8.626 (2000 total; 1000..1000/round) | 1.873/6.732 (1000 total; 500..500/round) | 0.085/0.972 (1000 total; 500..500/round) |
| `spsc_endpoint_pool4_reply` | `exact_waiter_notification_to_continuation` | 2.841/14.542 (4000 total; 2000..2000/round) | 0.250/1.468 (15947 total; 7972..7975/round) | 1.282/24.040 (2000 total; 1000..1000/round) | 3.627/10.485 (3947 total; 1972..1975/round) | 2.675/30.707 (2000 total; 1000..1000/round) | 0.131/1.718 (2000 total; 1000..1000/round) |
| `spsc_large64k_endpoint_pool4` | `exact_waiter_notification_to_continuation` | 2.830/15.665 (1024 total; 512..512/round) | 0.161/2.109 (4095 total; 2047..2048/round) | 0.982/4.609 (512 total; 256..256/round) | 2.504/12.704 (1023 total; 511..512/round) | 1.793/7.623 (512 total; 256..256/round) | 0.085/0.211 (512 total; 256..256/round) |
| `spsc_large64k_persistent` | `exact_waiter_notification_to_continuation` | 5.190/16.115 (1024 total; 512..512/round) | 0.261/2.200 (4096 total; 2048..2048/round) | 1.337/5.380 (512 total; 256..256/round) | 3.957/14.818 (1024 total; 512..512/round) | 2.625/9.563 (512 total; 256..256/round) | 0.145/0.510 (512 total; 256..256/round) |
| `spsc_opaque_persistent` | `exact_waiter_notification_to_continuation` | 1.377/9.768 (4000 total; 2000..2000/round) | 0.170/0.862 (15944 total; 7972..7972/round) | 0.996/21.525 (2000 total; 1000..1000/round) | 2.394/9.663 (3944 total; 1972..1972/round) | 1.739/33.407 (2000 total; 1000..1000/round) | 0.085/1.262 (2000 total; 1000..1000/round) |
| `spsc_record_persistent` | `exact_waiter_notification_to_continuation` | 1.422/8.807 (4000 total; 2000..2000/round) | 0.251/1.944 (15987 total; 7993..7994/round) | 1.413/5.706 (2000 total; 1000..1000/round) | 3.527/10.485 (3987 total; 1993..1994/round) | 2.590/10.474 (2000 total; 1000..1000/round) | 0.116/1.753 (2000 total; 1000..1000/round) |
| `spsc_record_pool4_control` | `exact_waiter_notification_to_continuation` | 1.307/4.588 (4000 total; 2000..2000/round) | 0.245/1.228 (16000 total; 8000..8000/round) | 1.222/3.827 (2000 total; 1000..1000/round) | 3.186/6.623 (4000 total; 2000..2000/round) | 2.284/21.450 (2000 total; 1000..1000/round) | 0.110/1.632 (2000 total; 1000..1000/round) |
| `spsc_scalar_persistent` | `exact_waiter_notification_to_continuation` | 0.225/1.218 (4000 total; 2000..2000/round) | 0.150/2.114 (15664 total; 7761..7903/round) | 1.153/5.611 (2000 total; 1000..1000/round) | 2.570/9.948 (3664 total; 1761..1903/round) | 0.221/1.222 (2000 total; 1000..1000/round) | 0.025/0.030 (2000 total; 1000..1000/round) |
| `wait_empty_receiver_endpoint` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.275/1.247 (8000 total; 4000..4000/round) | 2.214/119.563 (1000 total; 500..500/round) | 3.376/14.557 (2000 total; 1000..1000/round) | 6.091/49.878 (1000 total; 500..500/round) | unavailable (0 samples) |
| `wait_empty_receiver_record` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.275/1.167 (8000 total; 4000..4000/round) | 2.224/59.171 (1000 total; 500..500/round) | 3.311/9.738 (2000 total; 1000..1000/round) | 2.409/13.020 (1000 total; 500..500/round) | unavailable (0 samples) |
| `wait_full_sender_endpoint` | `exact_waiter_notification_to_continuation` | 5.775/97.412 (1000 total; 500..500/round) | 0.211/2.756 (11378 total; 5654..5724/round) | 1.568/7.449 (1834 total; 912..922/round) | 3.426/16.481 (2544 total; 1242..1302/round) | 2.726/10.575 (1000 total; 500..500/round) | unavailable (0 samples) |
| `wait_full_sender_record` | `exact_waiter_notification_to_continuation` | 2.775/20.699 (1000 total; 500..500/round) | 0.196/1.888 (10296 total; 5095..5201/round) | 1.427/64.541 (1234 total; 574..660/round) | 3.932/11.607 (2063 total; 1021..1042/round) | 2.760/26.599 (1000 total; 500..500/round) | unavailable (0 samples) |

Cells are medians of per-round p50/p99 microseconds, with total sample count and per-round count range. Wake modes list all observed round modes, not only the representative counter round. Encode/decode subintervals cover selected benchmark call brackets, not every worker's codec. Queue intervals include lock acquisition and readiness/closed branches, ending before unlock. Native wake correlates the exact selected waiter with its notification and successful continuation; cancelled/failed/nonunique notifications are unavailable, never attributed to a global last signal. It is not isolated kernel wake latency. Stages overlap across OS threads: do not add medians or subtract independently measured RTTs to manufacture a component time.

### Instrumentation overhead

| Case | Original SDK us/op | Private instrumented us/op | Difference us/op | Ratio |
|---|---:|---:|---:|---:|
| `call_control` | 0.054 | 0.053 | -0.001 | 0.980 |
| `churn_cancel_parked_waiters` | 79.327 | 78.080 | -1.247 | 0.984 |
| `churn_close_parked_receivers` | 22.080 | 26.492 | +4.413 | 1.200 |
| `churn_close_parked_senders` | 38.840 | 40.976 | +2.136 | 1.055 |
| `closure_roundtrip_cap0` | 6.127 | 7.588 | +1.460 | 1.238 |
| `closure_roundtrip_cap1` | 12.171 | 11.547 | -0.624 | 0.949 |
| `closure_roundtrip_cap64` | 152.379 | 238.505 | +86.126 | 1.565 |
| `closure_roundtrip_cap8` | 23.807 | 62.697 | +38.891 | 2.634 |
| `closure_roundtrip_complex_sig` | 9.864 | 12.941 | +3.077 | 1.312 |
| `codec_large64k_decode` | 7.210 | 7.499 | +0.289 | 1.040 |
| `codec_large64k_encode` | 9.292 | 11.377 | +2.085 | 1.224 |
| `codec_large64k_transfer_roundtrip` | 11.571 | 9.691 | -1.879 | 0.838 |
| `codec_scalar_roundtrip` | 0.150 | 0.198 | +0.048 | 1.320 |
| `codec_small_decode` | 1.000 | 1.603 | +0.603 | 1.603 |
| `codec_small_encode` | 0.458 | 0.785 | +0.328 | 1.716 |
| `codec_small_transfer_roundtrip` | 1.943 | 2.539 | +0.597 | 1.307 |
| `codec_wide16_decode` | 2.559 | 3.765 | +1.206 | 1.471 |
| `codec_wide16_encode` | 1.070 | 1.157 | +0.087 | 1.081 |
| `codec_wide16_transfer_roundtrip` | 3.937 | 5.436 | +1.500 | 1.381 |
| `inspect_function` | 2.033 | 2.658 | +0.625 | 1.307 |
| `inspect_record` | 0.165 | 0.345 | +0.180 | 2.093 |
| `join_cleanup_cancelled_task` | 43058.681 | 45386.981 | +2328.300 | 1.054 |
| `join_ordinary` | 7233.531 | 7361.645 | +128.114 | 1.018 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 3.103 | 7.475 | +4.371 | 2.409 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 3.376 | 8.109 | +4.733 | 2.402 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 17.720 | 22.748 | +5.027 | 1.284 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 5.610 | 9.378 | +3.768 | 1.672 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 5.640 | 9.637 | +3.997 | 1.709 |
| `mpmc_record_inflight16_cap16_4p4c` | 3.363 | 8.900 | +5.537 | 2.647 |
| `mpmc_record_inflight16_cap2_4p4c` | 3.495 | 6.620 | +3.125 | 1.894 |
| `mpmc_record_inflight1_cap1_2p2c` | 17.193 | 20.458 | +3.266 | 1.190 |
| `mpmc_record_inflight4_cap1_2p2c` | 4.935 | 9.547 | +4.613 | 1.935 |
| `mpmc_record_inflight4_cap4_2p2c` | 4.925 | 6.859 | +1.935 | 1.393 |
| `overhead_control` | 0.066 | 0.119 | +0.053 | 1.806 |
| `queue_opaque_hook8` | 2.700 | 4.392 | +1.692 | 1.627 |
| `queue_packed_hook8` | 3.797 | 6.043 | +2.246 | 1.591 |
| `queue_plain_bytes8` | 2.195 | 2.922 | +0.727 | 1.331 |
| `queue_real_receiver` | 4.260 | 5.754 | +1.494 | 1.351 |
| `queue_real_sender` | 4.407 | 6.264 | +1.857 | 1.421 |
| `sender_clone` | 0.199 | 0.292 | +0.094 | 1.471 |
| `spsc_endpoint_carried_persistent` | 16.991 | 65.398 | +48.407 | 3.849 |
| `spsc_endpoint_fresh_reply` | 18.137 | 18.025 | -0.112 | 0.994 |
| `spsc_endpoint_pool4_reply` | 19.493 | 28.356 | +8.862 | 1.455 |
| `spsc_large64k_endpoint_pool4` | 39.647 | 33.447 | -6.200 | 0.844 |
| `spsc_large64k_persistent` | 31.968 | 46.077 | +14.108 | 1.441 |
| `spsc_opaque_persistent` | 18.486 | 19.367 | +0.880 | 1.048 |
| `spsc_record_persistent` | 16.217 | 21.618 | +5.401 | 1.333 |
| `spsc_record_pool4_control` | 14.025 | 19.290 | +5.265 | 1.375 |
| `spsc_scalar_persistent` | 5.933 | 8.552 | +2.619 | 1.441 |
| `wait_empty_receiver_endpoint` | 28.478 | 43.099 | +14.621 | 1.513 |
| `wait_empty_receiver_record` | 29.841 | 37.392 | +7.551 | 1.253 |
| `wait_full_sender_endpoint` | 32.341 | 47.971 | +15.629 | 1.483 |
| `wait_full_sender_record` | 28.801 | 38.679 | +9.878 | 1.343 |

### Matched protocol/shape endpoint component contrasts

| Case | Control | Case us/op | Control us/op | Difference us/op |
|---|---|---:|---:|---:|
| `mpmc_endpoint_inflight16_cap16_4p4c` | `mpmc_record_inflight16_cap16_4p4c` | 3.103 | 3.363 | -0.260 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | `mpmc_record_inflight16_cap2_4p4c` | 3.376 | 3.495 | -0.119 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | `mpmc_record_inflight1_cap1_2p2c` | 17.720 | 17.193 | +0.528 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | `mpmc_record_inflight4_cap1_2p2c` | 5.610 | 4.935 | +0.675 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | `mpmc_record_inflight4_cap4_2p2c` | 5.640 | 4.925 | +0.715 |
| `queue_real_receiver` | `queue_plain_bytes8` | 4.260 | 2.195 | +2.065 |
| `queue_real_sender` | `queue_plain_bytes8` | 4.407 | 2.195 | +2.212 |
| `spsc_endpoint_carried_persistent` | `spsc_record_persistent` | 16.991 | 16.217 | +0.774 |
| `spsc_endpoint_pool4_reply` | `spsc_record_pool4_control` | 19.493 | 14.025 | +5.468 |
| `wait_empty_receiver_endpoint` | `wait_empty_receiver_record` | 28.478 | 29.841 | -1.363 |
| `wait_full_sender_endpoint` | `wait_full_sender_record` | 32.341 | 28.801 | +3.540 |

### Payload-policy controls (not isolated endpoint costs)

| Case | Control | Case us/op | Control us/op | Difference us/op |
|---|---|---:|---:|---:|
| `queue_opaque_hook8` | `queue_plain_bytes8` | 2.700 | 2.195 | +0.505 |
| `queue_packed_hook8` | `queue_plain_bytes8` | 3.797 | 2.195 | +1.602 |
| `spsc_opaque_persistent` | `spsc_record_persistent` | 18.486 | 16.217 | +2.269 |

### Application-protocol contrasts (not matched endpoint components)

| Case | Control | Case us/op | Control us/op | Difference us/op |
|---|---|---:|---:|---:|
| `spsc_endpoint_fresh_reply` | `spsc_endpoint_pool4_reply` | 18.137 | 19.493 | -1.356 |
| `spsc_large64k_endpoint_pool4` | `spsc_large64k_persistent` | 39.647 | 31.968 | +7.679 |

Matched endpoint contrasts retain common field count, capacity, OS producer/consumer counts, in-flight budget and validation/protocol; payload representation, hooks, wrapper allocation and ownership differ together. They do not isolate only retain/release cost. Fresh/pool-four and large pool-four/persistent comparisons change application protocol and are kept in the separate protocol table.

