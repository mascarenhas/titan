# Cross-thread RTT and component evidence

### Measured checkpoint provenance

| Input | Recorded evidence |
|---|---|
| ABI / SDK / language-server API | `2 / 0.6 / 1 (compile guard)` |
| Claimed source revision (builder-attested, not inferred) | `resource-ownership-r3-74a02edbec731159` |
| SDK profile | `production` |
| Complete generated-C flags (including optimization / LTO / debug) | `--std=c99 -O3 -Wall -Wno-unused-but-set-variable -Wno-unused-function -fPIC -g1 -flto=auto -ffat-lto-objects -fno-strict-aliasing` |
| Generated-C source-line directives | `True` |
| Full SDK content manifest SHA-256 | `69d618aed7e0fad78000f736bb8a3e0f8173fbf24565d394d7a7bc4e6ff6859b` |
| Source hash-map SHA-256 | `e89472ca428687be3d28f813ce493da1e5ced2d4846015cea63106570265f749` |
| Source probe recipe SHA-256 | `7cd2b6f7cc79a39b255bc5b1d9cb0db7db20b44ff23ca8ad4ae73ab0a229710d` |
| Original builder receipt SHA-256 | `7be82223bc57d44c67873735e33020ce171fcc0448b701c50a1f9d7141215876` |
| Preserved native payload archive SHA-256 | `0ce37201de9cf630f147292d593eab4c3c9facab3654adc464535caffbe60a66` |
| Generated consumer SHA-256 | `6f8cc79895202213298c74e6596bbab0b188e3d19629c8e451497c940e3fa906` |
| Raw codec calling contract | `native_consuming_slot` |

<details><summary>Exact provider/source/tool/link evidence</summary>

```json
{
  "executable_sha256": {
    "instrumented": "684c96a14f5bb35a512d3bcb8f2f99a20f903798d0094b713fe0e472e1abd930",
    "uninstrumented": "2ac2d71547ed573cbb061b6f1cc1ed3343645d796670d0dbf9ee3b3a64546c32"
  },
  "link_evidence": {
    "instrumented": "/tmp/titan-issue252-rtt-ownership-v4/logs/1792292493662960769-link-dependencies-instrumented.json",
    "uninstrumented": "/tmp/titan-issue252-rtt-ownership-v4/logs/1792292493657916601-link-dependencies-uninstrumented.json"
  },
  "lua_sha256": {
    "bin/lua": "4ff90fc0bccfffb89db1198b3807b2731b1f95686967a42d13f9b78f6f5561ee",
    "lib/liblua.a": "7decdb6e81469ca27cd6f8bc9f2eef0830c77dd6c5bc15cefc8a89fe1258f721"
  },
  "native_compile_argv": {
    "consumer_instrumented": [
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=bench",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/instrumented/bench.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/instrumented/bench.o.compile.tmp.lua_F2Ogrv"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/instrumented/.titan-temporary.tmp.lua_XOBBPS.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/instrumented/.titan-temporary.tmp.lua_XOBBPS.o"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/instrumented/bench__entrypoint.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/instrumented/bench__entrypoint.o"
      ]
    ],
    "consumer_uninstrumented": [
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=bench",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/uninstrumented/bench.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/uninstrumented/bench.o.compile.tmp.lua_8qMGqw"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/uninstrumented/.titan-temporary.tmp.lua_bizc0a.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/uninstrumented/.titan-temporary.tmp.lua_bizc0a.o"
      ],
      [
        "/usr/bin/gcc",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/uninstrumented/bench__entrypoint.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/uninstrumented/bench__entrypoint.o"
      ]
    ],
    "private_provider": [
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.async",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/async.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/async.o.compile.tmp.lua_QQOXvF"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.coroutine",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/coroutine.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/coroutine.o.compile.tmp.lua_znj1Bg"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.fs",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/fs.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/fs.o.compile.tmp.lua_0P01mN"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.gc",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/gc.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/gc.o.compile.tmp.lua_TfmsrG"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.http",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/http/http.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/http/http.o.compile.tmp.lua_HuMAGo"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.io",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/io.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/io.o.compile.tmp.lua_DDH0ud"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.iteration",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/iteration.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/iteration.o.compile.tmp.lua_b8biKl"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.json",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/json/json.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/json/json.o.compile.tmp.lua_uoh2Rb"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.lua",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/lua/lua.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/lua/lua.o.compile.tmp.lua_oLYeFN"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.math",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/math.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/math.o.compile.tmp.lua_lRCGCf"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.net",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/net.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/net.o.compile.tmp.lua_tCP0Kw"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.os",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/os.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/os.o.compile.tmp.lua_UcUZ4Q"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.path",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/path.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/path.o.compile.tmp.lua_1d5NEr"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.peg",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/peg/peg.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/peg/peg.o.compile.tmp.lua_7chgs3"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.protobuf",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/protobuf/protobuf.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/protobuf/protobuf.o.compile.tmp.lua_2h77Dp"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.reflect",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/reflect.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/reflect.o.compile.tmp.lua_gYftgA"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.sqlite3",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/sqlite3/sqlite3.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/sqlite3/sqlite3.o.compile.tmp.lua_ZDLHAs"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.ssl",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/ssl.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/ssl.o.compile.tmp.lua_8R6lDm"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.string",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/string/string.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/string/string.o.compile.tmp.lua_DvkPdZ"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.test",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/test.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/test.o.compile.tmp.lua_8tTX0j"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.thread",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/thread/thread.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/thread/thread.o.compile.tmp.lua_SW1AlW"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.timer",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/timer.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/timer.o.compile.tmp.lua_mhwoQI"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.transfer",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/transfer.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/transfer.o.compile.tmp.lua_yjidSE"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.url",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/url.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/url.o.compile.tmp.lua_Ot66zB"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.uv",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/uv/uv.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/uv/uv.o.compile.tmp.lua_gPNXP7"
      ],
      [
        "/usr/bin/gcc",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work/provider-source/vendor/lpeglabel",
        "-I/tmp/titan-issue252-rtt-ownership-v4/work",
        "-DOPENSSL_API_COMPAT=30000",
        "-D_GNU_SOURCE",
        "--std=c99",
        "-O3",
        "-Wall",
        "-Wno-unused-but-set-variable",
        "-Wno-unused-function",
        "-fPIC",
        "-g1",
        "-flto=auto",
        "-ffat-lto-objects",
        "-fno-strict-aliasing",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/include",
        "-I",
        "/tmp/titan-issue252-ownership-attested/sdk/src/lua-5.5.1",
        "-frandom-seed=titan.websocket",
        "-c",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/websocket/websocket.c",
        "-o",
        "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan/websocket/websocket.o.compile.tmp.lua_OUvgCp"
      ]
    ]
  },
  "native_policy": {
    "ar": "/usr/bin/ar",
    "cc": "/usr/bin/gcc",
    "cc_version": "gcc (GCC) 16.2.1 20260819 (Red Hat 16.2.1-2)",
    "emit_line_directives": true,
    "libbacktrace_cflags": "-fPIC -g -O2",
    "lua_archive_sha256": "7decdb6e81469ca27cd6f8bc9f2eef0830c77dd6c5bc15cefc8a89fe1258f721",
    "lua_binary_sha256": "4ff90fc0bccfffb89db1198b3807b2731b1f95686967a42d13f9b78f6f5561ee",
    "lua_source_commit": "025bfc35df0885656de347fb7a7c377e90042a75",
    "native_dependency_versions": {
      "libuv": "1.53.0+spawn-close-v1",
      "llhttp": "9.4.3",
      "lpeglabel": "1.6.2-1@912b0b9e8641074408ffc2259e069b188e0c717b",
      "sqlite3": "3.53.4"
    },
    "openssl_mode": "system",
    "openssl_pkg_config": "/usr/bin/pkg-config",
    "openssl_version": "3.5.9",
    "ranlib": "/usr/bin/ranlib",
    "rock_host_cflags": "-O2 -fPIC",
    "runtime_cflags": "--std=c99 -O3 -flto=auto -ffat-lto-objects -Wall -Wno-unused-but-set-variable -Wno-unused-function -fPIC -g1",
    "sdk_header_replay": {
      "include/llhttp.h": {
        "sha256": "5bc82fa51b19aa8bee7d921038393fbfc74e8cc9bae0844c2d82c102fb8cfd68",
        "source": "llhttp-release-v9.4.3/include/llhttp.h"
      },
      "include/sqlite3.h": {
        "sha256": "919e7f2e8ed1d8f56ac17b412b8971c76aa5d1a879752cc6058f75e7d5910e1d",
        "source": "sqlite-autoconf-3530400/sqlite3.h"
      },
      "include/uv.h": {
        "sha256": "565b25538707aa7244eb197af397e566be591b26cb66b5742ed095063946a558",
        "source": "libuv-v1.53.0/include/uv.h"
      },
      "include/uv/aix.h": {
        "sha256": "bed77e4cf6c06f1224e681cbe607eff04713ca0c1e1f4a102e6a6565ee3f02aa",
        "source": "libuv-v1.53.0/include/uv/aix.h"
      },
      "include/uv/bsd.h": {
        "sha256": "963533ff4b16f72a204a8c760896a857c54d0ac50570f1793e3bef1f2ae8b35f",
        "source": "libuv-v1.53.0/include/uv/bsd.h"
      },
      "include/uv/darwin.h": {
        "sha256": "222b6dd3ce67cfbb735b14b1662f065fc23570d6969acf463b39d946b7590d8c",
        "source": "libuv-v1.53.0/include/uv/darwin.h"
      },
      "include/uv/errno.h": {
        "sha256": "4242edf790e4569ef349026ab4c6e31093334ee5fc02b16ed7a0d9fbacdffd16",
        "source": "libuv-v1.53.0/include/uv/errno.h"
      },
      "include/uv/linux.h": {
        "sha256": "adce0ed0821c8466a87a0a4c9e0df9ea7e4a4b24d099c7d7ed196f72a13f669d",
        "source": "libuv-v1.53.0/include/uv/linux.h"
      },
      "include/uv/os390.h": {
        "sha256": "98388ae32ce2c4390b82c3529539d2a476c44f590e960ed30a79f72b807ecd02",
        "source": "libuv-v1.53.0/include/uv/os390.h"
      },
      "include/uv/posix.h": {
        "sha256": "e9d7218b34e6e89b7b412891b7e2aa8b3a561c5ce9714c1f4def6c8a8593a6a6",
        "source": "libuv-v1.53.0/include/uv/posix.h"
      },
      "include/uv/sunos.h": {
        "sha256": "29d4b4ef48dc3c3ab32d75e0a85bcb80e084d42b32aae40d67fc1d882b93298a",
        "source": "libuv-v1.53.0/include/uv/sunos.h"
      },
      "include/uv/threadpool.h": {
        "sha256": "09ae41099af710289155be012df45c2fce04da6a02e813278b4558935e645938",
        "source": "libuv-v1.53.0/include/uv/threadpool.h"
      },
      "include/uv/tree.h": {
        "sha256": "34393c74082c71ddd5bd9ec4afe30ef03df7fa7bb64be5a50ae070cdfebb5c43",
        "source": "libuv-v1.53.0/include/uv/tree.h"
      },
      "include/uv/unix.h": {
        "sha256": "bfa9e31bccf6991f795074316d323eaeef5dcdf6b1b6b8b9d1093e871e6484db",
        "source": "libuv-v1.53.0/include/uv/unix.h"
      },
      "include/uv/version.h": {
        "sha256": "8e216f0998cae52664f5a9889a2ec921e43c7abf7970c4780ab4e1bb6262932c",
        "source": "libuv-v1.53.0/include/uv/version.h"
      },
      "include/uv/win.h": {
        "sha256": "414f87cfec6fe111b893c71894bb3bf4afd1ae8e9fc601aa6cf7fb54dc3a1ca7",
        "source": "libuv-v1.53.0/include/uv/win.h"
      }
    },
    "titan_build_profile": "production",
    "titan_cppflags": "-DOPENSSL_API_COMPAT=30000 -D_GNU_SOURCE",
    "titan_extra_cflags": "-fno-strict-aliasing",
    "titan_ldflags": "-lpthread -lrt -lssl -lcrypto"
  },
  "private_provider_files": {
    "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan.a": "36e95055ebb4b34387b47e431e6a0c642e5086e064317db48da92cb7c4260d81",
    "/tmp/titan-issue252-rtt-ownership-v4/work/provider/titan.so": "2f19083180278650e452503043b471c5efe81721472ca876b64d243b41edc962"
  },
  "private_source_sha256": {
    "titan/async.titan": "799d9e47a4f35102135c7acbc909e93f78fce779a19bf21d87dd9644cff83258",
    "titan/async_receiver_native.h": "11442ad0cde9f2386fc1fdec5fa8e6478a83c9af6ea53c1268f6fa9939dd6b81",
    "titan/async_signal_platform.h": "3a413448397988560fe12a07e288be7bab73124964c44bac749497b61b069296",
    "titan/coroutine.titan": "be5fd08a6fd6d3b0b2f6b798f4e3ad42c10d1fb5e88aced6209faa59b9e2144b",
    "titan/fs.titan": "a327d9b30d8f680bfb9faa24f514eec2812fede877ab46e3f9531c822e3b99f9",
    "titan/fs_platform.h": "00da49bdf0851c3a4e2f44ed74243ba40a7b41e3d528f41e50b953503b11d879",
    "titan/gc.titan": "03cabaf0a6e2a48be14280d898236fce5334d3cfa769abc4b7c7a4b1632bb638",
    "titan/http/client.titan": "deed2100ec9da07aa4796f90b05d2491846d04accaa9491805548bc8180855b2",
    "titan/http/headers.titan": "8827e4cd9ae5a18cf660289fee5acb0bd774daa97f7c10cc1e220e724c70557d",
    "titan/http/http.titan": "ff6cc19963ed720c9cc3db435cba78fd7b4457260dd49674d983a0c21f725ae2",
    "titan/http/native.titan": "c6dc067689edb2b9cfd7c012e2497806b7c405a500a024aecedcd1b0695f8390",
    "titan/http/pool.titan": "04e290cd0f8f50b120541339ed15b1aa573a49afd145c0d9e8b6d4cae1987646",
    "titan/http/server.titan": "0032dc51c27b386d06ee912f62e27e7fb122c45e84fc58bf1b1f1f2db1066cec",
    "titan/http/transfer.titan": "fbc27658c9752325e48e748f4fa60c148e6cd56e794254df8cfc42fc830411f4",
    "titan/http/upgrade.titan": "82660410330005aca4c3846eea3b3b46cd4196ac280684f14658d1f4b92884c8",
    "titan/io.titan": "a85aea6ee8d66da0d8fc594426b9e9da812c8701916cd37703548513f7c8b57a",
    "titan/iteration.titan": "c5d33ca7f159aef0e9c07163ae8871920f46ce73ad8a6c9565265ec5e636e3d7",
    "titan/json/decoder.titan": "d4def8fce5de08c7c87508ce0a411a1bafe4b9ac5dd6e318ab4062fd99f4a144",
    "titan/json/json.titan": "1fd824d91d9bee28e2093bebc3598fabdcec594d00aafad6d00a991f4643050a",
    "titan/json/numbers.titan": "88f8a136d374276e98d05e047ed32aaa03efd63e56f4a83c516d48d513f3b13a",
    "titan/json/parser.titan": "7f12a7ba9c72bcc3103f2f84939e23a968fd8c4619fa10e8d8495c5f89dffeb2",
    "titan/json/writer.titan": "6667abde3d9f08e1e5711a30ff1ab636288c5c286c9c6916d98e088c52732703",
    "titan/lua/lua.titan": "fe0b752e006c2d8eda5d16a1b4a93f8ff0328b41a30993ef8f53ed2f63ad362e",
    "titan/lua/native.h": "9b5cdc28cab74588ec8ac44085886300d900d7d547c467b171888e2094660d8a",
    "titan/lua/worker.titan": "595dff5ce86a975be1426e1cb80a845bee21d7f1c7469ffce52c1cd97d86f793",
    "titan/math.titan": "15005d85308ffd3e42a79e548f55c5e5d59cd33e8bb7d4cb2608fe1e0d593f3e",
    "titan/net.titan": "e0c586a511979ac7150b2308ef8581740b481cec13441ac3c1196ba1323c19dd",
    "titan/os.titan": "da276574dec7c8a4dee575782ab22a61184baf083d0739be5569597aa6031835",
    "titan/os_environment.h": "e6b805d75104076751c555af08c4ea80881dd93df104dec8ebefd6b12aca982b",
    "titan/os_platform.h": "2ca67def9f3c87a409a9a80c6458aa9d53d7bbc227c0b3a6c07cabafd226770c",
    "titan/path.titan": "43c194cf9b3b4b79c37f652e74b20f20ab77996bbd326ba188b1e4ee2c601086",
    "titan/path_platform.h": "c56729270bb299092c6ac7dd88ae117c97a874393520ce810ef1c8af03e6ecc8",
    "titan/peg/combinators.titan": "e630451865326ab2ccc9b4078f17c12412e6af19155539a28868df7f34751f11",
    "titan/peg/native.titan": "768cb146b1e578521fb97c2318053ff5fc80a7d5b1765d997518002f083e8fd0",
    "titan/peg/peg.titan": "f3771893b9b648af80027ab839ca27e9165a95b94b28ec1d6637b3fa40ece24a",
    "titan/peg/relabel.titan": "3b6bcccd8da929aa1d56da040bc53df9cd24413361536ac9b66d39a3ec186d0f",
    "titan/peg/relabel_parser.titan": "22df8b78c74e0e596d642f60be244f9f17ee20860a52e8d67d90c3cc14eef1d8",
    "titan/protobuf/decoder.titan": "a864fd7450aa83d286ec173a1928b2f6b07f310d484497b0d8ab6e373802be7f",
    "titan/protobuf/encoder.titan": "3c4cc2b49ca8ff3b45334af70ba72a0f5c84c7cd3639d72aafefcd2f040714b9",
    "titan/protobuf/native.h": "256dd809670f6f1a20a2951ff3783f96ce93341cff0408bd55d89af6fcb40d52",
    "titan/protobuf/protobuf.titan": "8133509295fb8b91a0bbb871f7ebf6eb393a9137228af3c9f291a3e6b8f71cfd",
    "titan/protobuf/schema.titan": "924b9d92ad0b2f82f61e82ef18cd0be5fbad1dcbbb53dccc929ea569c8294c8f",
    "titan/reflect.titan": "a611557c47f100f7b3f44badbd47dda0bf11b4d7869df7aa7c0d73214ba2fef9",
    "titan/sqlite3/bindings.titan": "17a46365e8c8cb93e329676d35a9e74d151cc9590489a8591c0fd7b6c04a103d",
    "titan/sqlite3/native.h": "ac82a1b9730c6e6692b9e08e3fd8b3d83337df66a6a2c6264a366040d9e992ef",
    "titan/sqlite3/row.titan": "58f91cec279562e60559ab66937a80d01fdd30532a2cff4622da1171b9181618",
    "titan/sqlite3/sqlite3.titan": "bae3cb85db17d0fd48ed4f0b9f3479ecda6842c3994bf25f7b8f2a67d597bc45",
    "titan/sqlite3/worker.titan": "421db60859260a0ed96ca325e0def109b8dbd661a0619870790140668fb23092",
    "titan/ssl.titan": "79b741432798a3f2b73ec85fa33851b1bd3cc3e43fd7a4315a8ea74213ca1fd0",
    "titan/string/bytes.titan": "9448b332fd42bf409b453158305890c8c12eb5eb18df1be9bc92342bcc9c8b3e",
    "titan/string/format.titan": "ff8794649730b36d0185cdecb28cbb9eb0a76ffd0b122e67864de3715b02ae34",
    "titan/string/format_native.h": "f3f97457a9296ea6e32e72e036b05e945f15eb8ef02cccdca8ea816a3ac76b75",
    "titan/string/pack.titan": "20bc7a5a3d4f8b499ae27246559040124886b9925cdf6f05b13167690d2a99c2",
    "titan/string/regex_api.titan": "281d06298980e53cdd2e133bbf5ae1ffbbd5e2dc49974979a17b1970362c6160",
    "titan/string/regex_compile.titan": "8aa476969a2854cdd921e112a5c6d6bf860a9c655261851f8f6cebe7bd0dd786",
    "titan/string/regex_parser.titan": "8402206160bceefe85d38abceb52588357afcf5991d753da4ec4a56c4b84b969",
    "titan/string/string.titan": "e1015dcb814d4c2173e8f14dbe506e3a9d5b96e814a58e818306960e0d2b72ea",
    "titan/test.titan": "1098b360eb4e1312cc3e41fb2c6bc258a68a9d9aba47da5fe7dbbc3a3843edcf",
    "titan/thread/channel.titan": "eafea619426e0df6a029ceda3335dac602f3871140bbfdf5a88a306c7dc4d52d",
    "titan/thread/group.titan": "4fe8c6b4d535ea88a5d9e0ab92c2a570c78576e95682ca97ec10de44f9d7bf40",
    "titan/thread/native.h": "011ce3dd894dd3847f71a71f4ccc4b797da72903d0b64586dd0721478903ddbe",
    "titan/thread/spawn.titan": "f49d130363f4fc20daba6c1aa385ef79ac4878f609bbc6c087ef7886fed33e8b",
    "titan/thread/thread.titan": "68494f6b78ef84a54b18e7df0112709314bf17347706d2ad086ab11d1b3820e1",
    "titan/timer.titan": "bcbbaf7ca0a83e6305b7c436523bbe938454254b1967a1e2c717417d44e69d1b",
    "titan/transfer.titan": "78a6c65d76fe9078d7112abbae5665be186afc862d1d8513efc5e97c48714017",
    "titan/transfer_native.h": "b604451567989657ef94feb374b80a55c79024e7cd5fa4cd900f0773549b3097",
    "titan/url.titan": "c130c7e2736759cceed9f0c9955e457d9253c94cbe0784adb74d990b2891f9ab",
    "titan/uv/address-native.h": "a77fc869a5ddefee6dd053c0f1df552e6bb96a320a1f8bf0e2a5b3c28ac61525",
    "titan/uv/address.titan": "67d85cfbf9382484c49dd7e3b396963db5ef337508d2cbafc2dc50d9ea4f3c84",
    "titan/uv/callback.h": "de7a15347fe4586ffe9dd7a7f3dfc9931ed488a8babde23f81dfc53bd1d89bee",
    "titan/uv/callbacks.titan": "d605d2cd36704a1c1cd19eb5b988045865141738b94dd1d9c92c85b507b0832f",
    "titan/uv/capabilities.titan": "b79d72cb392a74828f1aa0a82a781b2d83ab09d7803c17a85986c899a4ad9b5f",
    "titan/uv/constants.titan": "58042ab8d85fe014a4dd3c940b0594710fdc76cf35f4e6eb64bc8eecc8bed330",
    "titan/uv/data.titan": "565de88997eba8034f5431ead7a80a2ed37aff12a8932aedf85a225d0474fb8a",
    "titan/uv/data_native.h": "68cf454e225b200572d5de46ada8b091d774a661ebe39b7160c18bf4c5d195c1",
    "titan/uv/dll.titan": "51aae662b051bb5fcd4bc61fd41e36e032c5ce95f45822f6e81fec347a214800",
    "titan/uv/dns.titan": "d79ae8118ee8d2d17e29ac050370d967f7096d4c56efdc5c7e4eef281f93d868",
    "titan/uv/external-wake-native.h": "081510f2954d1139d86a4745ddb26950c6f6cbbd8fa8877ac9d4b28590059e0d",
    "titan/uv/external_wake.titan": "3eddca945b8d3c9b810b178bb61b9e55a94c94bc075aaab1227b0b15659a8493",
    "titan/uv/fd-native.h": "310b9f22163030d72ae29bf32f06b63ac253db23ada7dce7ef5833ce3ef3dd9f",
    "titan/uv/fd.titan": "0d754b9e83e2d3506ae988d46bd160a3b9df867a751c43ba7ec6e8c8caff7953",
    "titan/uv/identifiers.titan": "a5b033d59b4593db7ed8512558468708b7cc55fe94555505ada36f32a3406d08",
    "titan/uv/network-native.h": "aa68b33b4533ccf0a9a21da5037c8a75d942b5cf0fcbfaf860501673ebb1b78d",
    "titan/uv/pipe_tty.titan": "c993616548c9e0957355ce7cfad76daef24b44353749c7af9f4648acd5c8b0c8",
    "titan/uv/platform-constants.h": "026ede031bc7ebb28ed0504d29a2a077175c152cf18d181120944bd43ac46a26",
    "titan/uv/platform_constants.titan": "c322cb9c80ffdb8406ab643ac935f8cc5ad7d7736e09711abb3e826e2d007255",
    "titan/uv/process.titan": "94145f180cc85848c118adec809c6e4efa153199053b874b5b035046f518e14d",
    "titan/uv/startup.titan": "31e0376df10ec0ef59257f59160b7e6958df301fb1e3d167544519dc35f2381f",
    "titan/uv/stream_ops.titan": "6ecb4e474f66c6507c8c7f29114e2c95cf84a0d6df62aa7b37f0ce1708037071",
    "titan/uv/stream_owners.titan": "8cc33b19287a8f4edd25e05e65270bda2f6bbefbc024da80187f6e3e5ba1de4e",
    "titan/uv/sync.titan": "8468e05c462e075a553fc71b45ccff22e06bfe51cfe292a58f02886e5f01b5cb",
    "titan/uv/sync_storage.h": "735846d522d0d8ac547b90b72c4104bd91bbf35ce77a9485ad57bd49f2eea579",
    "titan/uv/tcp.titan": "d60f9e62432719f0dd2f2387fb58ad185fef0861c7b1251923c085c36c4295e9",
    "titan/uv/thread-native.h": "3f21558b5d56f539bf293e25f21feaf20b13738d84591e6af7f26cc18762060a",
    "titan/uv/threading.titan": "b596f1ccb9f0535ab357e07bf2ae8ede05ffc1019b73b65da998bc732f789d21",
    "titan/uv/transfer-native.h": "cb758073064a42bc66d3ffe4829403d179c5ba943a5824e3a753544917c47335",
    "titan/uv/transfer.titan": "23a4475f92f4b65b99c8e1238bfbcf59a878a8badff6e476a4fffc77f02eed2f",
    "titan/uv/udp.titan": "dbdcca8e11d86e14e275462f2134dfe12b49a459ffcd5861541154c97df4bec5",
    "titan/uv/utilities.titan": "c04d0930ef4748efe2229e8f56e376f0422c332378f919faf8ac3874621f20aa",
    "titan/uv/utility_bits.h": "266f6acacbbe4789cf2d5a193290940d005a89fb472f1170bf5f4ad9ffe484fe",
    "titan/uv/uv.titan": "e1b9d3ee90fd9bb8988166179a873cfd1ebab30cacb092a80173048149cae055",
    "titan/uv/version-native.h": "f50904be5213e873f965a9c0df91fdd84e7bb81c64c754c644a4f01b243f7b13",
    "titan/uv/work-data.h": "6c5d07725136b16e44931d7063166521c3dd36b698669547cdfaae768624f131",
    "titan/websocket/connection.titan": "3b12bd5104ed1d8909f277705071a904aef6c7f0cfcde2ceaef40fe29b862087",
    "titan/websocket/frames.titan": "5f1186d677e4181c84a1ff88d7f03211ad7c594eddd89484637e5bc9843f9fb3",
    "titan/websocket/handshake.titan": "75687fd219930545303c1b6e89f6e1fe58f8c9b93990753f10202d4cc517315b",
    "titan/websocket/native.titan": "e5cb28322f7ef8ee33531482fca6e2bb6d6019cc0ab525d502045365677864d1",
    "titan/websocket/utf8.titan": "b0eda22bfbcd8cb0fb13d105ff49af15cee41316ae8acd5a1d1cd79fae51f26c",
    "titan/websocket/websocket.titan": "9e25d2affc279a4e6cb986b7e6c164d05e91e76c0ee2f0fcd3062c3e6c849b62",
    "vendor/lpeglabel/lplcap.h": "1114fe329cc34c7054938035e73e6bf25802e3b0b88e0f17ebe592587d405013",
    "vendor/lpeglabel/lplcode.h": "84dfbddbd78d4a0f6861dd8be065d5fd1c4c4aac8cd77cea3af4ad286d9be9ac",
    "vendor/lpeglabel/lplprint.h": "1b70e48cc3f8f1a57a3485f5125bda90f230b1c24e06e18adbf4e3c753af992e",
    "vendor/lpeglabel/lpltree.h": "e92d8d4676a7757a028052d0e05056575b3821ba577a63231f37902c0dd180eb",
    "vendor/lpeglabel/lpltypes.h": "d07a72b2470210de6ba82ae868bec93be6b15d15b060d8a8abc926de7d090b70",
    "vendor/lpeglabel/lplvm.h": "6eafc02d33ff9d11abf77b8eb49b086ed684d4394c7303972d46dda7f81c2fe7",
    "vendor/lpeglabel/titan_lpeglabel.h": "3384372e7ed10ca5a18bba7f16dbcf4859a740aff3a4f11ec379e79569eb4a22",
    "vendor/lpeglabel/titan_lpeglabel_namespace.h": "233f2208d0669204031c3475abe4ae3dc376f9381fa1ace36d2330e41554640f"
  },
  "provider_build_evidence": {
    "attestation": "/tmp/titan-issue252-ownership-attested/BUILD-ATTESTATION.json",
    "attestation_sha256": "32115a02d26c4a35c603f2d48c6329f8fdf1a6617abaf28c7c7364349df12080",
    "checkpoint": "resource-ownership pre-wake; legacy detached Thread/OSjoin and prestart defects remain. Uses original unpatched language compiler; new compiler-only consumer lowering fixes are not part of this immutable checkpoint.",
    "commands": "/tmp/titan-issue252-ownership-attested/BUILD-COMMANDS.json",
    "commands_sha256": "281461dfb426a89f308ee75a0809e3e471c7bc8b6ea91177c72d9787297a6206",
    "source_after": "/tmp/titan-issue252-ownership-attested/SOURCE-AFTER.json",
    "source_before": "/tmp/titan-issue252-ownership-attested/SOURCE-BEFORE.json"
  },
  "provider_files": {
    "/tmp/titan-issue252-ownership-attested/sdk/bin/lua": "4ff90fc0bccfffb89db1198b3807b2731b1f95686967a42d13f9b78f6f5561ee",
    "/tmp/titan-issue252-ownership-attested/sdk/lib/luarocks/rocks-5.5/titan/0.6.0-1/bin/titanc": "567bdf8984e6631a199b3feae238483a632af62aa9239a5864a93fb074ce03b4",
    "/tmp/titan-issue252-ownership-attested/sdk/lib/titan/0.6/libtitan.a": "f8123ef431b4a854bc1473d1f35296a39a3159d85a25303e60c6dbb7d5f8152f",
    "/tmp/titan-issue252-ownership-attested/sdk/lib/titan/0.6/titan.a": "fc3b0716a1a86d200d2667135596e89210b6c14bf932ac59ed05fd69599d2485",
    "/tmp/titan-issue252-ownership-attested/sdk/lib/titan/0.6/titan.so": "fbef388a69a971129649f4e824fda1799dac74c682dbb13079d056575577157f"
  },
  "source_compile_policy": {
    "build_profile": "production",
    "emit_line_directives": true,
    "extra_cflags": [
      "-fno-strict-aliasing"
    ],
    "generated_cflags": [
      "--std=c99",
      "-O3",
      "-Wall",
      "-Wno-unused-but-set-variable",
      "-Wno-unused-function",
      "-fPIC",
      "-g1",
      "-flto=auto",
      "-ffat-lto-objects",
      "-fno-strict-aliasing"
    ],
    "module_random_seed": {
      "consumer_instrumented": [
        "bench"
      ],
      "consumer_uninstrumented": [
        "bench"
      ],
      "private_provider": [
        "titan.async",
        "titan.coroutine",
        "titan.fs",
        "titan.gc",
        "titan.http",
        "titan.io",
        "titan.iteration",
        "titan.json",
        "titan.lua",
        "titan.math",
        "titan.net",
        "titan.os",
        "titan.path",
        "titan.peg",
        "titan.protobuf",
        "titan.reflect",
        "titan.sqlite3",
        "titan.ssl",
        "titan.string",
        "titan.test",
        "titan.thread",
        "titan.timer",
        "titan.transfer",
        "titan.url",
        "titan.uv",
        "titan.websocket"
      ]
    },
    "private_provider_compile_receipt": "/tmp/titan-issue252-rtt-ownership-v4/logs/1792291788577047792-compile-private-full-provider.json",
    "probe_cflags": [
      "--std=c99",
      "-O3",
      "-Wall",
      "-Wno-unused-but-set-variable",
      "-Wno-unused-function",
      "-fPIC",
      "-g1",
      "-flto=auto",
      "-ffat-lto-objects",
      "-fno-strict-aliasing",
      "-std=c11",
      "-Wextra",
      "-Werror",
      "-fno-builtin",
      "-frandom-seed=rtt_probe"
    ],
    "probe_policy_difference": "C11, instrumentation diagnostics, no builtins, fixed probe-only random seed"
  },
  "source_sha256": {
    "titan/async.titan": "799d9e47a4f35102135c7acbc909e93f78fce779a19bf21d87dd9644cff83258",
    "titan/async_receiver_native.h": "11442ad0cde9f2386fc1fdec5fa8e6478a83c9af6ea53c1268f6fa9939dd6b81",
    "titan/async_signal_platform.h": "3a413448397988560fe12a07e288be7bab73124964c44bac749497b61b069296",
    "titan/coroutine.titan": "be5fd08a6fd6d3b0b2f6b798f4e3ad42c10d1fb5e88aced6209faa59b9e2144b",
    "titan/fs.titan": "a327d9b30d8f680bfb9faa24f514eec2812fede877ab46e3f9531c822e3b99f9",
    "titan/fs_platform.h": "00da49bdf0851c3a4e2f44ed74243ba40a7b41e3d528f41e50b953503b11d879",
    "titan/gc.titan": "03cabaf0a6e2a48be14280d898236fce5334d3cfa769abc4b7c7a4b1632bb638",
    "titan/http/client.titan": "deed2100ec9da07aa4796f90b05d2491846d04accaa9491805548bc8180855b2",
    "titan/http/headers.titan": "8827e4cd9ae5a18cf660289fee5acb0bd774daa97f7c10cc1e220e724c70557d",
    "titan/http/http.titan": "ff6cc19963ed720c9cc3db435cba78fd7b4457260dd49674d983a0c21f725ae2",
    "titan/http/native.titan": "c6dc067689edb2b9cfd7c012e2497806b7c405a500a024aecedcd1b0695f8390",
    "titan/http/pool.titan": "04e290cd0f8f50b120541339ed15b1aa573a49afd145c0d9e8b6d4cae1987646",
    "titan/http/server.titan": "0032dc51c27b386d06ee912f62e27e7fb122c45e84fc58bf1b1f1f2db1066cec",
    "titan/http/transfer.titan": "fbc27658c9752325e48e748f4fa60c148e6cd56e794254df8cfc42fc830411f4",
    "titan/http/upgrade.titan": "82660410330005aca4c3846eea3b3b46cd4196ac280684f14658d1f4b92884c8",
    "titan/io.titan": "a85aea6ee8d66da0d8fc594426b9e9da812c8701916cd37703548513f7c8b57a",
    "titan/iteration.titan": "c5d33ca7f159aef0e9c07163ae8871920f46ce73ad8a6c9565265ec5e636e3d7",
    "titan/json/decoder.titan": "d4def8fce5de08c7c87508ce0a411a1bafe4b9ac5dd6e318ab4062fd99f4a144",
    "titan/json/json.titan": "1fd824d91d9bee28e2093bebc3598fabdcec594d00aafad6d00a991f4643050a",
    "titan/json/numbers.titan": "88f8a136d374276e98d05e047ed32aaa03efd63e56f4a83c516d48d513f3b13a",
    "titan/json/parser.titan": "7f12a7ba9c72bcc3103f2f84939e23a968fd8c4619fa10e8d8495c5f89dffeb2",
    "titan/json/writer.titan": "6667abde3d9f08e1e5711a30ff1ab636288c5c286c9c6916d98e088c52732703",
    "titan/lua/lua.titan": "fe0b752e006c2d8eda5d16a1b4a93f8ff0328b41a30993ef8f53ed2f63ad362e",
    "titan/lua/native.h": "9b5cdc28cab74588ec8ac44085886300d900d7d547c467b171888e2094660d8a",
    "titan/lua/worker.titan": "595dff5ce86a975be1426e1cb80a845bee21d7f1c7469ffce52c1cd97d86f793",
    "titan/math.titan": "15005d85308ffd3e42a79e548f55c5e5d59cd33e8bb7d4cb2608fe1e0d593f3e",
    "titan/net.titan": "e0c586a511979ac7150b2308ef8581740b481cec13441ac3c1196ba1323c19dd",
    "titan/os.titan": "da276574dec7c8a4dee575782ab22a61184baf083d0739be5569597aa6031835",
    "titan/os_environment.h": "e6b805d75104076751c555af08c4ea80881dd93df104dec8ebefd6b12aca982b",
    "titan/os_platform.h": "2ca67def9f3c87a409a9a80c6458aa9d53d7bbc227c0b3a6c07cabafd226770c",
    "titan/path.titan": "43c194cf9b3b4b79c37f652e74b20f20ab77996bbd326ba188b1e4ee2c601086",
    "titan/path_platform.h": "c56729270bb299092c6ac7dd88ae117c97a874393520ce810ef1c8af03e6ecc8",
    "titan/peg/combinators.titan": "e630451865326ab2ccc9b4078f17c12412e6af19155539a28868df7f34751f11",
    "titan/peg/native.titan": "768cb146b1e578521fb97c2318053ff5fc80a7d5b1765d997518002f083e8fd0",
    "titan/peg/peg.titan": "f3771893b9b648af80027ab839ca27e9165a95b94b28ec1d6637b3fa40ece24a",
    "titan/peg/relabel.titan": "3b6bcccd8da929aa1d56da040bc53df9cd24413361536ac9b66d39a3ec186d0f",
    "titan/peg/relabel_parser.titan": "22df8b78c74e0e596d642f60be244f9f17ee20860a52e8d67d90c3cc14eef1d8",
    "titan/protobuf/decoder.titan": "a864fd7450aa83d286ec173a1928b2f6b07f310d484497b0d8ab6e373802be7f",
    "titan/protobuf/encoder.titan": "3c4cc2b49ca8ff3b45334af70ba72a0f5c84c7cd3639d72aafefcd2f040714b9",
    "titan/protobuf/native.h": "256dd809670f6f1a20a2951ff3783f96ce93341cff0408bd55d89af6fcb40d52",
    "titan/protobuf/protobuf.titan": "8133509295fb8b91a0bbb871f7ebf6eb393a9137228af3c9f291a3e6b8f71cfd",
    "titan/protobuf/schema.titan": "924b9d92ad0b2f82f61e82ef18cd0be5fbad1dcbbb53dccc929ea569c8294c8f",
    "titan/reflect.titan": "a611557c47f100f7b3f44badbd47dda0bf11b4d7869df7aa7c0d73214ba2fef9",
    "titan/sqlite3/bindings.titan": "17a46365e8c8cb93e329676d35a9e74d151cc9590489a8591c0fd7b6c04a103d",
    "titan/sqlite3/native.h": "ac82a1b9730c6e6692b9e08e3fd8b3d83337df66a6a2c6264a366040d9e992ef",
    "titan/sqlite3/row.titan": "58f91cec279562e60559ab66937a80d01fdd30532a2cff4622da1171b9181618",
    "titan/sqlite3/sqlite3.titan": "bae3cb85db17d0fd48ed4f0b9f3479ecda6842c3994bf25f7b8f2a67d597bc45",
    "titan/sqlite3/worker.titan": "421db60859260a0ed96ca325e0def109b8dbd661a0619870790140668fb23092",
    "titan/ssl.titan": "79b741432798a3f2b73ec85fa33851b1bd3cc3e43fd7a4315a8ea74213ca1fd0",
    "titan/string/bytes.titan": "9448b332fd42bf409b453158305890c8c12eb5eb18df1be9bc92342bcc9c8b3e",
    "titan/string/format.titan": "ff8794649730b36d0185cdecb28cbb9eb0a76ffd0b122e67864de3715b02ae34",
    "titan/string/format_native.h": "f3f97457a9296ea6e32e72e036b05e945f15eb8ef02cccdca8ea816a3ac76b75",
    "titan/string/pack.titan": "20bc7a5a3d4f8b499ae27246559040124886b9925cdf6f05b13167690d2a99c2",
    "titan/string/regex_api.titan": "281d06298980e53cdd2e133bbf5ae1ffbbd5e2dc49974979a17b1970362c6160",
    "titan/string/regex_compile.titan": "8aa476969a2854cdd921e112a5c6d6bf860a9c655261851f8f6cebe7bd0dd786",
    "titan/string/regex_parser.titan": "8402206160bceefe85d38abceb52588357afcf5991d753da4ec4a56c4b84b969",
    "titan/string/string.titan": "e1015dcb814d4c2173e8f14dbe506e3a9d5b96e814a58e818306960e0d2b72ea",
    "titan/test.titan": "1098b360eb4e1312cc3e41fb2c6bc258a68a9d9aba47da5fe7dbbc3a3843edcf",
    "titan/thread/channel.titan": "d861f4d14ebb5443ef43b7ab5efd1ced0f4565dfeec5ce6c8aba59c4981d76ee",
    "titan/thread/group.titan": "4fe8c6b4d535ea88a5d9e0ab92c2a570c78576e95682ca97ec10de44f9d7bf40",
    "titan/thread/native.h": "011ce3dd894dd3847f71a71f4ccc4b797da72903d0b64586dd0721478903ddbe",
    "titan/thread/spawn.titan": "bcbea92aee98c70ddc90247e281c8c17aa51fe9f1afe9ec8c9f40016eca26d75",
    "titan/thread/thread.titan": "fd28d76bf25965aa81812d3da185bd9b70e1b46c4be10885711c5d6764012eec",
    "titan/timer.titan": "bcbbaf7ca0a83e6305b7c436523bbe938454254b1967a1e2c717417d44e69d1b",
    "titan/transfer.titan": "78a6c65d76fe9078d7112abbae5665be186afc862d1d8513efc5e97c48714017",
    "titan/transfer_native.h": "b604451567989657ef94feb374b80a55c79024e7cd5fa4cd900f0773549b3097",
    "titan/url.titan": "c130c7e2736759cceed9f0c9955e457d9253c94cbe0784adb74d990b2891f9ab",
    "titan/uv/address-native.h": "a77fc869a5ddefee6dd053c0f1df552e6bb96a320a1f8bf0e2a5b3c28ac61525",
    "titan/uv/address.titan": "67d85cfbf9382484c49dd7e3b396963db5ef337508d2cbafc2dc50d9ea4f3c84",
    "titan/uv/callback.h": "de7a15347fe4586ffe9dd7a7f3dfc9931ed488a8babde23f81dfc53bd1d89bee",
    "titan/uv/callbacks.titan": "d605d2cd36704a1c1cd19eb5b988045865141738b94dd1d9c92c85b507b0832f",
    "titan/uv/capabilities.titan": "b79d72cb392a74828f1aa0a82a781b2d83ab09d7803c17a85986c899a4ad9b5f",
    "titan/uv/constants.titan": "58042ab8d85fe014a4dd3c940b0594710fdc76cf35f4e6eb64bc8eecc8bed330",
    "titan/uv/data.titan": "565de88997eba8034f5431ead7a80a2ed37aff12a8932aedf85a225d0474fb8a",
    "titan/uv/data_native.h": "68cf454e225b200572d5de46ada8b091d774a661ebe39b7160c18bf4c5d195c1",
    "titan/uv/dll.titan": "51aae662b051bb5fcd4bc61fd41e36e032c5ce95f45822f6e81fec347a214800",
    "titan/uv/dns.titan": "d79ae8118ee8d2d17e29ac050370d967f7096d4c56efdc5c7e4eef281f93d868",
    "titan/uv/external-wake-native.h": "081510f2954d1139d86a4745ddb26950c6f6cbbd8fa8877ac9d4b28590059e0d",
    "titan/uv/external_wake.titan": "3eddca945b8d3c9b810b178bb61b9e55a94c94bc075aaab1227b0b15659a8493",
    "titan/uv/fd-native.h": "310b9f22163030d72ae29bf32f06b63ac253db23ada7dce7ef5833ce3ef3dd9f",
    "titan/uv/fd.titan": "0d754b9e83e2d3506ae988d46bd160a3b9df867a751c43ba7ec6e8c8caff7953",
    "titan/uv/identifiers.titan": "a5b033d59b4593db7ed8512558468708b7cc55fe94555505ada36f32a3406d08",
    "titan/uv/network-native.h": "aa68b33b4533ccf0a9a21da5037c8a75d942b5cf0fcbfaf860501673ebb1b78d",
    "titan/uv/pipe_tty.titan": "c993616548c9e0957355ce7cfad76daef24b44353749c7af9f4648acd5c8b0c8",
    "titan/uv/platform-constants.h": "026ede031bc7ebb28ed0504d29a2a077175c152cf18d181120944bd43ac46a26",
    "titan/uv/platform_constants.titan": "c322cb9c80ffdb8406ab643ac935f8cc5ad7d7736e09711abb3e826e2d007255",
    "titan/uv/process.titan": "94145f180cc85848c118adec809c6e4efa153199053b874b5b035046f518e14d",
    "titan/uv/startup.titan": "31e0376df10ec0ef59257f59160b7e6958df301fb1e3d167544519dc35f2381f",
    "titan/uv/stream_ops.titan": "6ecb4e474f66c6507c8c7f29114e2c95cf84a0d6df62aa7b37f0ce1708037071",
    "titan/uv/stream_owners.titan": "8cc33b19287a8f4edd25e05e65270bda2f6bbefbc024da80187f6e3e5ba1de4e",
    "titan/uv/sync.titan": "8468e05c462e075a553fc71b45ccff22e06bfe51cfe292a58f02886e5f01b5cb",
    "titan/uv/sync_storage.h": "735846d522d0d8ac547b90b72c4104bd91bbf35ce77a9485ad57bd49f2eea579",
    "titan/uv/tcp.titan": "d60f9e62432719f0dd2f2387fb58ad185fef0861c7b1251923c085c36c4295e9",
    "titan/uv/thread-native.h": "3f21558b5d56f539bf293e25f21feaf20b13738d84591e6af7f26cc18762060a",
    "titan/uv/threading.titan": "b596f1ccb9f0535ab357e07bf2ae8ede05ffc1019b73b65da998bc732f789d21",
    "titan/uv/transfer-native.h": "cb758073064a42bc66d3ffe4829403d179c5ba943a5824e3a753544917c47335",
    "titan/uv/transfer.titan": "23a4475f92f4b65b99c8e1238bfbcf59a878a8badff6e476a4fffc77f02eed2f",
    "titan/uv/udp.titan": "dbdcca8e11d86e14e275462f2134dfe12b49a459ffcd5861541154c97df4bec5",
    "titan/uv/utilities.titan": "c04d0930ef4748efe2229e8f56e376f0422c332378f919faf8ac3874621f20aa",
    "titan/uv/utility_bits.h": "266f6acacbbe4789cf2d5a193290940d005a89fb472f1170bf5f4ad9ffe484fe",
    "titan/uv/uv.titan": "e1b9d3ee90fd9bb8988166179a873cfd1ebab30cacb092a80173048149cae055",
    "titan/uv/version-native.h": "f50904be5213e873f965a9c0df91fdd84e7bb81c64c754c644a4f01b243f7b13",
    "titan/uv/work-data.h": "6c5d07725136b16e44931d7063166521c3dd36b698669547cdfaae768624f131",
    "titan/websocket/connection.titan": "3b12bd5104ed1d8909f277705071a904aef6c7f0cfcde2ceaef40fe29b862087",
    "titan/websocket/frames.titan": "5f1186d677e4181c84a1ff88d7f03211ad7c594eddd89484637e5bc9843f9fb3",
    "titan/websocket/handshake.titan": "75687fd219930545303c1b6e89f6e1fe58f8c9b93990753f10202d4cc517315b",
    "titan/websocket/native.titan": "e5cb28322f7ef8ee33531482fca6e2bb6d6019cc0ab525d502045365677864d1",
    "titan/websocket/utf8.titan": "b0eda22bfbcd8cb0fb13d105ff49af15cee41316ae8acd5a1d1cd79fae51f26c",
    "titan/websocket/websocket.titan": "9e25d2affc279a4e6cb986b7e6c164d05e91e76c0ee2f0fcd3062c3e6c849b62",
    "vendor/lpeglabel/lplcap.h": "1114fe329cc34c7054938035e73e6bf25802e3b0b88e0f17ebe592587d405013",
    "vendor/lpeglabel/lplcode.h": "84dfbddbd78d4a0f6861dd8be065d5fd1c4c4aac8cd77cea3af4ad286d9be9ac",
    "vendor/lpeglabel/lplprint.h": "1b70e48cc3f8f1a57a3485f5125bda90f230b1c24e06e18adbf4e3c753af992e",
    "vendor/lpeglabel/lpltree.h": "e92d8d4676a7757a028052d0e05056575b3821ba577a63231f37902c0dd180eb",
    "vendor/lpeglabel/lpltypes.h": "d07a72b2470210de6ba82ae868bec93be6b15d15b060d8a8abc926de7d090b70",
    "vendor/lpeglabel/lplvm.h": "6eafc02d33ff9d11abf77b8eb49b086ed684d4394c7303972d46dda7f81c2fe7",
    "vendor/lpeglabel/titan_lpeglabel.h": "3384372e7ed10ca5a18bba7f16dbcf4859a740aff3a4f11ec379e79569eb4a22",
    "vendor/lpeglabel/titan_lpeglabel_namespace.h": "233f2208d0669204031c3475abe4ae3dc376f9381fa1ace36d2330e41554640f"
  },
  "tools": {
    "ar": {
      "argv": [
        "/usr/bin/ar"
      ],
      "executable_sha256": "97910d3148c2a6bbaf899821e6f6c07c602fcd1ef00f081ec7a58a348288b7c5"
    },
    "cc": {
      "argv": [
        "/usr/bin/gcc"
      ],
      "executable_sha256": "153e46b4657620f2baef1b4a70b4b4f275772faa5b0fb9e415697e87ebcb7fea"
    },
    "ranlib": {
      "argv": [
        "/usr/bin/ranlib"
      ],
      "executable_sha256": "dc7e8f99cf5956e5ba2540f61f213cc4bbfa08ba2d40a33fe2adbfe726f2948d"
    }
  }
}
```

</details>

## Measured results

Catalog: 53 cases; this report contains 53 measured cases.

Uninstrumented timing uses the original immutable SDK. Instrumented timing uses a private full-provider rebuild with source-scoped semantic probes and the original native payload. The difference below is instrumentation overhead, not a production speedup.

### Uninstrumented end-to-end timing

| Case | Protocol | Rounds / samples | us/op median [range] | RTT p50/p95/p99 us | ops/s | Cold first use us | Residual GC us/op | Retire us |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| `call_control` | `same_state` | 6 / 60000 | 0.055 [0.053..0.114] | 0.030/0.030/0.031 | 18283164.8 | 11492.1 | 0.045 | 0.5 |
| `churn_cancel_parked_waiters` | `cancel_churn` | 6 / 3000 | 81.481 [73.682..134.379] | 53.365/163.846/668.385 | 12319.8 | 7733.5 | 3.952 | 55.7 |
| `churn_close_parked_receivers` | `close_churn` | 6 / 3000 | 27.545 [23.608..30.006] | 15.755/46.602/268.241 | 36429.5 | 9128.2 | 8.453 | 64.6 |
| `churn_close_parked_senders` | `close_churn` | 6 / 3000 | 39.678 [38.476..40.434] | 27.171/70.376/353.185 | 25203.5 | 7125.3 | 8.856 | 56.3 |
| `closure_roundtrip_cap0` | `same_state` | 6 / 6000 | 3.009 [2.833..5.731] | 2.845/4.173/8.285 | 332589.2 | 8696.5 | 1.377 | 1.4 |
| `closure_roundtrip_cap1` | `same_state` | 6 / 6000 | 6.002 [5.412..6.677] | 4.373/11.702/48.130 | 167046.9 | 8244.5 | 1.158 | 1.7 |
| `closure_roundtrip_cap64` | `same_state` | 6 / 6000 | 142.429 [139.411..153.783] | 82.339/613.421/856.471 | 7021.9 | 8101.6 | 0.705 | 2.4 |
| `closure_roundtrip_cap8` | `same_state` | 6 / 6000 | 23.394 [21.205..32.278] | 12.779/103.823/170.654 | 42779.8 | 7662.9 | 0.623 | 2.3 |
| `closure_roundtrip_complex_sig` | `same_state` | 6 / 6000 | 6.060 [5.799..6.765] | 4.599/10.855/48.606 | 165014.8 | 8428.2 | 1.205 | 1.9 |
| `codec_large64k_decode` | `same_state` | 6 / 1536 | 8.199 [7.447..14.776] | 3.867/19.822/83.727 | 122134.7 | 8705.1 | 2.596 | 2.2 |
| `codec_large64k_encode` | `same_state` | 6 / 1536 | 8.650 [7.402..15.210] | 4.739/21.029/75.506 | 115896.4 | 9223.9 | 2.470 | 1.9 |
| `codec_large64k_transfer_roundtrip` | `same_state` | 6 / 1536 | 9.615 [8.839..19.144] | 6.427/20.684/81.562 | 104042.3 | 8257.2 | 2.507 | 1.4 |
| `codec_scalar_roundtrip` | `same_state` | 6 / 30000 | 0.482 [0.468..0.730] | 0.355/1.027/1.402 | 2073378.9 | 8079.2 | 0.296 | 1.1 |
| `codec_small_decode` | `same_state` | 6 / 30000 | 1.107 [1.031..1.376] | 0.621/1.593/6.096 | 904151.0 | 7582.0 | 0.179 | 2.3 |
| `codec_small_encode` | `same_state` | 6 / 30000 | 0.478 [0.464..0.490] | 0.371/0.967/1.347 | 2094196.4 | 7104.8 | 0.176 | 1.2 |
| `codec_small_transfer_roundtrip` | `same_state` | 6 / 30000 | 3.025 [2.375..4.212] | 1.863/3.867/20.348 | 333667.2 | 8105.5 | 0.326 | 2.3 |
| `codec_wide16_decode` | `same_state` | 6 / 30000 | 2.599 [2.404..2.809] | 1.623/3.146/37.831 | 384753.9 | 8907.8 | 0.169 | 2.5 |
| `codec_wide16_encode` | `same_state` | 6 / 30000 | 1.258 [1.043..1.601] | 0.942/1.898/3.131 | 805881.4 | 9018.9 | 0.233 | 1.5 |
| `codec_wide16_transfer_roundtrip` | `same_state` | 6 / 30000 | 4.884 [4.443..8.863] | 3.272/8.871/47.534 | 205005.1 | 7176.5 | 0.186 | 2.1 |
| `inspect_function` | `same_state` | 6 / 6000 | 2.017 [1.942..3.027] | 1.814/2.575/3.647 | 495813.4 | 8506.5 | 0.963 | 1.2 |
| `inspect_record` | `same_state` | 6 / 30000 | 0.169 [0.144..0.370] | 0.111/0.191/0.651 | 5942639.4 | 6920.1 | 0.119 | 1.1 |
| `join_cleanup_cancelled_task` | `cleanup_join` | 6 / 600 | 42885.501 [38349.693..48089.056] | 42971.360/49800.974/58697.204 | 23.3 | 8944.0 | 43.061 | 51.2 |
| `join_ordinary` | `ordinary_join` | 6 / 600 | 7095.610 [6597.523..8786.798] | 6846.645/8600.068/8831.761 | 140.9 | 9619.5 | 37.106 | 71.1 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | `pool_16_reply` | 6 / 6000 | 3.478 [2.935..4.093] | 44.143/79.674/126.566 | 287799.9 | 9329.3 | 1.701 | 6460.8 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | `pool_16_reply` | 6 / 6000 | 3.623 [2.912..4.658] | 38.427/84.197/131.591 | 277524.4 | 8847.1 | 1.841 | 5709.4 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 24.133 [20.574..25.335] | 20.744/30.883/52.082 | 41442.4 | 8550.2 | 1.520 | 5568.6 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 6.428 [5.563..8.646] | 20.939/37.029/58.148 | 156505.9 | 8451.5 | 1.035 | 5198.7 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | `pool_four_reply` | 6 / 6000 | 5.807 [5.710..8.575] | 19.943/29.876/49.442 | 172211.2 | 8485.7 | 1.103 | 5013.2 |
| `mpmc_record_inflight16_cap16_4p4c` | `pool_16_reply` | 6 / 6000 | 3.452 [2.464..5.148] | 41.838/88.125/167.032 | 289856.8 | 8756.2 | 1.742 | 5499.6 |
| `mpmc_record_inflight16_cap2_4p4c` | `pool_16_reply` | 6 / 6000 | 3.619 [2.913..3.932] | 40.490/100.754/185.046 | 276825.9 | 10068.7 | 1.856 | 5274.0 |
| `mpmc_record_inflight1_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 20.019 [16.890..27.169] | 15.955/34.114/55.108 | 49999.6 | 9455.1 | 1.703 | 4494.1 |
| `mpmc_record_inflight4_cap1_2p2c` | `pool_four_reply` | 6 / 6000 | 7.042 [5.317..9.164] | 22.272/45.931/61.510 | 142196.8 | 9135.9 | 1.133 | 5127.2 |
| `mpmc_record_inflight4_cap4_2p2c` | `pool_four_reply` | 6 / 6000 | 6.624 [5.252..7.968] | 21.020/36.027/51.677 | 151120.5 | 8088.3 | 1.184 | 4977.6 |
| `overhead_control` | `same_state` | 6 / 60000 | 0.070 [0.066..0.100] | 0.040/0.045/0.056 | 14359343.5 | 8149.8 | 0.043 | 0.5 |
| `queue_opaque_hook8` | `same_state_queue` | 6 / 30000 | 3.733 [3.459..4.941] | 2.405/6.773/42.194 | 268177.9 | 9506.1 | 0.340 | 82.3 |
| `queue_packed_hook8` | `same_state_queue` | 6 / 30000 | 5.337 [4.629..7.363] | 3.136/10.820/57.011 | 187960.0 | 8895.5 | 0.206 | 77.6 |
| `queue_plain_bytes8` | `same_state_queue` | 6 / 30000 | 3.382 [2.782..4.184] | 1.964/4.714/26.785 | 296275.0 | 6641.8 | 0.387 | 77.6 |
| `queue_real_receiver` | `same_state_queue` | 6 / 30000 | 4.301 [3.639..5.999] | 2.625/9.011/43.877 | 233021.6 | 11264.8 | 0.392 | 81.9 |
| `queue_real_sender` | `same_state_queue` | 6 / 30000 | 4.931 [3.835..7.721] | 3.346/5.726/53.169 | 211253.6 | 10716.4 | 0.501 | 83.7 |
| `sender_clone` | `same_state_queue` | 6 / 30000 | 0.198 [0.183..0.207] | 0.160/0.231/0.385 | 5058898.9 | 9022.1 | 0.160 | 34.6 |
| `spsc_endpoint_carried_persistent` | `persistent_reply` | 6 / 6000 | 19.488 [15.026..25.892] | 13.270/44.168/119.944 | 52012.2 | 8914.0 | 1.331 | 1024.5 |
| `spsc_endpoint_fresh_reply` | `fresh_reply` | 6 / 3000 | 19.548 [12.546..22.438] | 17.403/32.266/48.680 | 51195.5 | 8196.1 | 3.160 | 1941.3 |
| `spsc_endpoint_pool4_reply` | `pool_four_reply` | 6 / 6000 | 23.183 [15.872..27.067] | 18.174/45.190/125.450 | 43484.2 | 10492.8 | 1.640 | 1766.5 |
| `spsc_large64k_endpoint_pool4` | `pool_four_reply` | 6 / 1536 | 48.003 [34.716..54.362] | 40.681/88.886/209.547 | 20851.8 | 9021.4 | 5.134 | 1323.4 |
| `spsc_large64k_persistent` | `persistent_reply` | 6 / 1536 | 42.219 [28.206..46.773] | 33.227/69.910/173.314 | 23735.7 | 9066.7 | 5.697 | 1186.0 |
| `spsc_opaque_persistent` | `persistent_reply` | 6 / 6000 | 20.761 [15.771..27.556] | 15.855/46.837/102.907 | 48189.2 | 9326.8 | 1.465 | 1272.2 |
| `spsc_record_persistent` | `persistent_reply` | 6 / 6000 | 20.051 [12.841..25.483] | 14.632/46.402/101.094 | 50236.8 | 7989.4 | 1.461 | 1138.8 |
| `spsc_record_pool4_control` | `pool_four_reply` | 6 / 6000 | 17.429 [14.012..26.171] | 12.323/37.661/94.046 | 57393.9 | 9237.7 | 0.860 | 980.2 |
| `spsc_scalar_persistent` | `persistent_reply` | 6 / 6000 | 8.316 [6.449..12.135] | 7.920/11.681/20.478 | 122383.6 | 7964.4 | 2.504 | 1421.6 |
| `wait_empty_receiver_endpoint` | `directed_empty_wait` | 6 / 3000 | 35.714 [24.540..42.418] | 24.335/66.299/342.770 | 28038.3 | 7125.7 | 5.487 | 1522.4 |
| `wait_empty_receiver_record` | `directed_empty_wait` | 6 / 3000 | 35.400 [21.905..41.611] | 24.856/65.137/345.680 | 28684.2 | 10762.1 | 5.980 | 1616.0 |
| `wait_full_sender_endpoint` | `directed_full_wait` | 6 / 3000 | 34.314 [25.315..46.642] | 25.598/68.283/250.438 | 29321.7 | 9284.1 | 6.666 | 2101.3 |
| `wait_full_sender_record` | `directed_full_wait` | 6 / 3000 | 37.303 [24.924..45.888] | 25.934/83.361/341.463 | 27023.9 | 9758.8 | 5.784 | 1984.7 |

RTT columns are medians of per-round percentiles, not pooled percentiles. Directed full-sender samples are admission/previous-packet release acknowledgements, not processing RTTs for the newly admitted request. Churn includes fresh resource/state creation.

### Exact native branch counts (representative instrumented round)

Counters/per-op traffic select the actual upper-median body-time round; all instrumented rounds remain in the summary JSON. Counts are branch events within the body window, including worker request receives and protocol-control channels. A wait can begin before the window. Fast successes are successful first readiness checks, not post-suspension retry successes. Closed outcomes are never counted as successful fast paths/rechecks. Slow attempts are failed ready checks entering registration; native suspensions, successful registration rechecks, selected waiter notification attempts and nominal CancellationReason errors are separate events.

| Case | Fast | Slow | Recheck OK | Suspends | Ordinary / cleanup join suspends | Notify | Cancel | Async init / public close requests |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `call_control` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `churn_cancel_parked_waiters` | 500 | 1000 | 0 | 1000 | 0 / 0 | 0 | 1000 | 1000 / 1000 |
| `churn_close_parked_receivers` | 0 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `churn_close_parked_senders` | 500 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `closure_roundtrip_cap0` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap1` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap64` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap8` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_complex_sig` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_decode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_encode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_scalar_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_small_decode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_small_encode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_small_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_decode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_encode` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `inspect_function` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `inspect_record` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `join_cleanup_cancelled_task` | 300 | 600 | 0 | 600 | 100 / 100 | 400 | 200 | 800 / 700 |
| `join_ordinary` | 200 | 300 | 0 | 300 | 100 / 0 | 300 | 0 | 500 / 400 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 4367 | 2725 | 276 | 2449 | 0 / 0 | 2509 | 0 | 2725 / 2785 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 4344 | 2740 | 329 | 2411 | 0 / 0 | 2471 | 0 | 2740 / 2800 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 4003 | 2504 | 0 | 2504 | 0 / 0 | 2504 | 0 | 2504 / 2504 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 4125 | 2593 | 305 | 2288 | 0 / 0 | 2294 | 0 | 2593 / 2599 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 4270 | 2420 | 275 | 2145 | 0 / 0 | 2151 | 0 | 2420 / 2426 |
| `mpmc_record_inflight16_cap16_4p4c` | 4589 | 2269 | 227 | 2042 | 0 / 0 | 2102 | 0 | 2269 / 2329 |
| `mpmc_record_inflight16_cap2_4p4c` | 4442 | 2553 | 281 | 2272 | 0 / 0 | 2332 | 0 | 2553 / 2613 |
| `mpmc_record_inflight1_cap1_2p2c` | 4003 | 2503 | 1 | 2502 | 0 / 0 | 2502 | 0 | 2503 / 2503 |
| `mpmc_record_inflight4_cap1_2p2c` | 4108 | 2639 | 359 | 2280 | 0 / 0 | 2286 | 0 | 2639 / 2645 |
| `mpmc_record_inflight4_cap4_2p2c` | 4215 | 2420 | 220 | 2200 | 0 / 0 | 2206 | 0 | 2420 / 2426 |
| `overhead_control` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_opaque_hook8` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_packed_hook8` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_plain_bytes8` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_real_receiver` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `queue_real_sender` | 10000 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `sender_clone` | 0 | 0 | 0 | 0 | 0 / 0 | 0 | 0 | 0 / 0 |
| `spsc_endpoint_carried_persistent` | 2000 | 2000 | 26 | 1974 | 0 / 0 | 1974 | 0 | 2000 / 2000 |
| `spsc_endpoint_fresh_reply` | 1000 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `spsc_endpoint_pool4_reply` | 2001 | 1999 | 28 | 1971 | 0 / 0 | 1971 | 0 | 1999 / 1999 |
| `spsc_large64k_endpoint_pool4` | 512 | 512 | 0 | 512 | 0 / 0 | 512 | 0 | 512 / 512 |
| `spsc_large64k_persistent` | 512 | 512 | 0 | 512 | 0 / 0 | 512 | 0 | 512 / 512 |
| `spsc_opaque_persistent` | 2000 | 2000 | 15 | 1985 | 0 / 0 | 1985 | 0 | 2000 / 2000 |
| `spsc_record_persistent` | 2000 | 2000 | 44 | 1956 | 0 / 0 | 1956 | 0 | 2000 / 2000 |
| `spsc_record_pool4_control` | 2000 | 2000 | 26 | 1974 | 0 / 0 | 1974 | 0 | 2000 / 2000 |
| `spsc_scalar_persistent` | 2003 | 1997 | 442 | 1555 | 0 / 0 | 1555 | 0 | 1997 / 1997 |
| `wait_empty_receiver_endpoint` | 1000 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `wait_empty_receiver_record` | 1000 | 1000 | 0 | 1000 | 0 / 0 | 1000 | 0 | 1000 / 1000 |
| `wait_full_sender_endpoint` | 1561 | 1439 | 133 | 1306 | 0 / 0 | 1306 | 0 | 1439 / 1439 |
| `wait_full_sender_record` | 1523 | 1477 | 137 | 1340 | 0 / 0 | 1340 | 0 | 1477 / 1477 |

### Native async handle retirement (representative instrumented round)

| Case | Whole-case async init | Public close requests | Terminal close callbacks | Async retirements at successful loop close | Successful / attempted loop closes |
|---|---:|---:|---:|---:|---:|
| `call_control` | 0 | 0 | 0 | 0 | 0 / 0 |
| `churn_cancel_parked_waiters` | 1065 | 1064 | 1064 | 1 | 1 / 1 |
| `churn_close_parked_receivers` | 1065 | 1064 | 1064 | 1 | 1 / 1 |
| `churn_close_parked_senders` | 1065 | 1064 | 1064 | 1 | 1 / 1 |
| `closure_roundtrip_cap0` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap1` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap64` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_cap8` | 0 | 0 | 0 | 0 | 0 / 0 |
| `closure_roundtrip_complex_sig` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_decode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_encode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_large64k_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_scalar_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_small_decode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_small_encode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_small_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_decode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_encode` | 0 | 0 | 0 | 0 | 0 / 0 |
| `codec_wide16_transfer_roundtrip` | 0 | 0 | 0 | 0 | 0 / 0 |
| `inspect_function` | 0 | 0 | 0 | 0 | 0 / 0 |
| `inspect_record` | 0 | 0 | 0 | 0 | 0 / 0 |
| `join_cleanup_cancelled_task` | 865 | 756 | 756 | 109 | 109 / 109 |
| `join_ordinary` | 541 | 432 | 432 | 109 | 109 / 109 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 14208 | 14199 | 14199 | 9 | 9 / 9 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 14003 | 13994 | 13994 | 9 | 9 / 9 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 2846 | 2841 | 2841 | 5 | 5 / 5 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 3927 | 3922 | 3922 | 5 | 5 / 5 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 3760 | 3755 | 3755 | 5 | 5 / 5 |
| `mpmc_record_inflight16_cap16_4p4c` | 13105 | 13096 | 13096 | 9 | 9 / 9 |
| `mpmc_record_inflight16_cap2_4p4c` | 13959 | 13950 | 13950 | 9 | 9 / 9 |
| `mpmc_record_inflight1_cap1_2p2c` | 2846 | 2841 | 2841 | 5 | 5 / 5 |
| `mpmc_record_inflight4_cap1_2p2c` | 4020 | 4015 | 4015 | 5 | 5 / 5 |
| `mpmc_record_inflight4_cap4_2p2c` | 3562 | 3557 | 3557 | 5 | 5 / 5 |
| `overhead_control` | 0 | 0 | 0 | 0 | 0 / 0 |
| `queue_opaque_hook8` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_packed_hook8` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_plain_bytes8` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_real_receiver` | 1 | 0 | 0 | 1 | 1 / 1 |
| `queue_real_sender` | 1 | 0 | 0 | 1 | 1 / 1 |
| `sender_clone` | 1 | 0 | 0 | 1 | 1 / 1 |
| `spsc_endpoint_carried_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_endpoint_fresh_reply` | 1070 | 1068 | 1068 | 2 | 2 / 2 |
| `spsc_endpoint_pool4_reply` | 2133 | 2131 | 2131 | 2 | 2 / 2 |
| `spsc_large64k_endpoint_pool4` | 550 | 548 | 548 | 2 | 2 / 2 |
| `spsc_large64k_persistent` | 550 | 548 | 548 | 2 | 2 / 2 |
| `spsc_opaque_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_record_persistent` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_record_pool4_control` | 2134 | 2132 | 2132 | 2 | 2 / 2 |
| `spsc_scalar_persistent` | 2131 | 2129 | 2129 | 2 | 2 / 2 |
| `wait_empty_receiver_endpoint` | 1070 | 1068 | 1068 | 2 | 2 / 2 |
| `wait_empty_receiver_record` | 1070 | 1068 | 1068 | 2 | 2 / 2 |
| `wait_full_sender_endpoint` | 1541 | 1539 | 1539 | 2 | 2 / 2 |
| `wait_full_sender_record` | 1579 | 1577 | 1577 | 2 | 2 / 2 |

Whole-case counters start at the setup snapshot after cold first use; identities are tracked from process birth, including cold loops. Libuv initializes loop-internal async handles through uv_async_init but retires them directly during successful uv_loop_close. Those retirements are not fabricated public close requests or callbacks. A busy/failed loop close retires no identity; active_async_handles remains the actual unretired registry count and must be zero. Real UV allocation traffic is not suppressed.


### Allocation and observed copy traffic

| Case | Lua allocs / requested B per op | Native allocs / requested B per op | Interposed copy B/op (outside / inside Lua allocator) | Analytical reference B/op (not wire/copy bytes) |
|---|---:|---:|---:|---:|
| `call_control` | 0.00 / 0.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 0 |
| `churn_cancel_parked_waiters` | 99.57 / 26461.9 | 8.00 / 560.0 | 9932.0 (9932.0 / 0.0) | 0 |
| `churn_close_parked_receivers` | 80.95 / 24983.5 | 3.00 / 152.0 | 47.6 (47.6 / 0.0) | 0 |
| `churn_close_parked_senders` | 85.71 / 20215.8 | 6.00 / 536.0 | 2416.6 (2416.6 / 0.0) | 0 |
| `closure_roundtrip_cap0` | 54.01 / 3147.4 | 2.00 / 384.0 | 132.0 (132.0 / 0.0) | 0 |
| `closure_roundtrip_cap1` | 106.01 / 6004.6 | 2.00 / 384.0 | 293.0 (293.0 / 0.0) | 0 |
| `closure_roundtrip_cap64` | 3038.06 / 189086.9 | 4.00 / 1920.0 | 12065.0 (12065.0 / 0.0) | 0 |
| `closure_roundtrip_cap8` | 444.02 / 26331.9 | 2.00 / 384.0 | 1532.0 (1532.0 / 0.0) | 0 |
| `closure_roundtrip_complex_sig` | 106.02 / 6004.7 | 2.00 / 384.0 | 293.0 (293.0 / 0.0) | 0 |
| `codec_large64k_decode` | 16.02 / 66349.6 | 0.00 / 0.0 | 65562.0 (65562.0 / 0.0) | 65540 |
| `codec_large64k_encode` | 7.02 / 65953.6 | 2.00 / 131136.0 | 131076.0 (131076.0 / 0.0) | 65540 |
| `codec_large64k_transfer_roundtrip` | 27.04 / 67311.0 | 3.00 / 131456.0 | 131113.0 (131113.0 / 0.0) | 65540 |
| `codec_scalar_roundtrip` | 4.00 / 512.0 | 1.00 / 128.0 | 0.0 (0.0 / 0.0) | 8 |
| `codec_small_decode` | 21.00 / 1049.0 | 0.00 / 0.0 | 83.0 (83.0 / 0.0) | 11 |
| `codec_small_encode` | 6.00 / 380.0 | 1.00 / 64.0 | 7.0 (7.0 / 0.0) | 11 |
| `codec_small_transfer_roundtrip` | 32.00 / 2009.1 | 2.00 / 384.0 | 106.0 (106.0 / 0.0) | 11 |
| `codec_wide16_decode` | 44.00 / 3805.2 | 0.00 / 0.0 | 749.0 (749.0 / 0.0) | 33 |
| `codec_wide16_encode` | 6.00 / 380.0 | 1.00 / 64.0 | 0.0 (0.0 / 0.0) | 33 |
| `codec_wide16_transfer_roundtrip` | 55.00 / 4765.1 | 2.00 / 384.0 | 764.0 (764.0 / 0.0) | 33 |
| `inspect_function` | 50.01 / 2376.4 | 0.00 / 0.0 | 80.0 (80.0 / 0.0) | 0 |
| `inspect_record` | 2.00 / 172.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 0 |
| `join_cleanup_cancelled_task` | 25100.41 / 4056366.0 | 27.00 / 3752.0 | 5204322.5 (5204322.5 / 0.0) | 0 |
| `join_ordinary` | 24669.63 / 4000914.7 | 20.00 / 2832.0 | 1647847.7 (1647847.7 / 0.0) | 0 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 124.86 / 9708.6 | 6.07 / 1000.7 | 265.3 (265.3 / 0.0) | 0 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 125.05 / 9731.4 | 6.07 / 1000.7 | 265.5 (265.5 / 0.0) | 0 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 121.40 / 9316.3 | 6.00 / 992.5 | 265.0 (265.0 / 0.0) | 0 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 122.21 / 9447.9 | 6.01 / 993.3 | 265.1 (265.1 / 0.0) | 0 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 120.18 / 9229.9 | 6.01 / 993.3 | 265.1 (265.1 / 0.0) | 0 |
| `mpmc_record_inflight16_cap16_4p4c` | 109.38 / 8360.5 | 5.07 / 904.7 | 265.2 (265.2 / 0.0) | 0 |
| `mpmc_record_inflight16_cap2_4p4c` | 113.31 / 8757.4 | 5.07 / 904.7 | 265.4 (265.4 / 0.0) | 0 |
| `mpmc_record_inflight1_cap1_2p2c` | 112.40 / 8622.8 | 5.00 / 896.5 | 265.0 (265.0 / 0.0) | 0 |
| `mpmc_record_inflight4_cap1_2p2c` | 113.71 / 8801.0 | 5.01 / 897.3 | 265.1 (265.1 / 0.0) | 0 |
| `mpmc_record_inflight4_cap4_2p2c` | 111.16 / 8522.3 | 5.01 / 897.3 | 265.0 (265.0 / 0.0) | 0 |
| `overhead_control` | 0.00 / 0.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 0 |
| `queue_opaque_hook8` | 44.00 / 2865.1 | 2.00 / 384.0 | 139.0 (139.0 / 0.0) | 21 |
| `queue_packed_hook8` | 65.00 / 3973.2 | 2.00 / 384.0 | 196.0 (196.0 / 0.0) | 21 |
| `queue_plain_bytes8` | 36.00 / 2273.1 | 2.00 / 384.0 | 139.0 (139.0 / 0.0) | 21 |
| `queue_real_receiver` | 45.00 / 2969.2 | 3.00 / 480.0 | 138.0 (138.0 / 0.0) | 21 |
| `queue_real_sender` | 45.00 / 2969.1 | 3.00 / 480.0 | 136.0 (136.0 / 0.0) | 21 |
| `sender_clone` | 2.00 / 168.0 | 0.00 / 0.0 | 0.0 (0.0 / 0.0) | 21 |
| `spsc_endpoint_carried_persistent` | 109.20 / 8034.7 | 5.00 / 864.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_endpoint_fresh_reply` | 113.22 / 8372.0 | 8.00 / 1016.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_endpoint_pool4_reply` | 109.43 / 8057.3 | 5.00 / 864.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_large64k_endpoint_pool4` | 110.47 / 73624.8 | 6.00 / 131936.0 | 131332.0 (131332.0 / 0.0) | 65565 |
| `spsc_large64k_persistent` | 101.54 / 72937.9 | 5.00 / 131840.0 | 131330.0 (131330.0 / 0.0) | 65565 |
| `spsc_opaque_persistent` | 108.40 / 7950.7 | 4.00 / 768.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_record_persistent` | 100.40 / 7360.0 | 4.00 / 768.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_record_pool4_control` | 100.45 / 7364.0 | 4.00 / 768.0 | 265.0 (265.0 / 0.0) | 29 |
| `spsc_scalar_persistent` | 37.77 / 3885.9 | 2.00 / 256.0 | 0.0 (0.0 / 0.0) | 16 |
| `wait_empty_receiver_endpoint` | 108.18 / 17703.7 | 4.00 / 608.0 | 169.3 (169.3 / 0.0) | 29 |
| `wait_empty_receiver_record` | 98.16 / 16941.1 | 3.00 / 512.0 | 169.3 (169.3 / 0.0) | 29 |
| `wait_full_sender_endpoint` | 153.09 / 21049.1 | 6.00 / 992.0 | 295.3 (295.3 / 0.0) | 29 |
| `wait_full_sender_record` | 143.20 / 17055.4 | 5.00 / 896.0 | 295.3 (295.3 / 0.0) | 29 |

Lua allocator requests include state birth and terminal close. Only allocations made inside the underlying Lua allocator are excluded from native traffic; real UV allocations are not suppressed. Copy counts cover interposed memcpy **and memmove** calls, not inlined copies, scalar stores or libc-internal copying. Actual total wire bytes are unavailable; the analytical reference can use a different payload/ID and is not presented as measured transfer traffic.

### Lifecycle and post-retirement evidence (all instrumented rounds)

| Case | Rounds | Channels delta range | Controls delta range | Active worker range | Lua state delta / active async handles / pending wait probes | Observed native block / usable B net ranges | Host Lua net B range | Checksums / lifecycle |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| `call_control` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `churn_cancel_parked_waiters` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 73.0..73.0 | valid |
| `churn_close_parked_receivers` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 36.0..36.0 | valid |
| `churn_close_parked_senders` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 73.0..137.0 | valid |
| `closure_roundtrip_cap0` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `closure_roundtrip_cap1` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `closure_roundtrip_cap64` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `closure_roundtrip_cap8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `closure_roundtrip_complex_sig` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `codec_large64k_decode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_large64k_encode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `codec_large64k_transfer_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8745.0..8809.0 | valid |
| `codec_scalar_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `codec_small_decode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_small_encode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_small_transfer_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8809.0..8809.0 | valid |
| `codec_wide16_decode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `codec_wide16_encode` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `codec_wide16_transfer_roundtrip` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8745.0..8809.0 | valid |
| `inspect_function` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8545.0 | valid |
| `inspect_record` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8545.0..8609.0 | valid |
| `join_cleanup_cancelled_task` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 3265.0..3265.0 | valid |
| `join_ordinary` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 36.0..36.0 | valid |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7484.0..7548.0 | valid |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7548.0..7548.0 | valid |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7484.0..7548.0 | valid |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7548.0..7548.0 | valid |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 7548.0..7548.0 | valid |
| `mpmc_record_inflight16_cap16_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 9699.0..9763.0 | valid |
| `mpmc_record_inflight16_cap2_4p4c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 9763.0..9763.0 | valid |
| `mpmc_record_inflight1_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 9699.0..9763.0 | valid |
| `mpmc_record_inflight4_cap1_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 9763.0..9763.0 | valid |
| `mpmc_record_inflight4_cap4_2p2c` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 9699.0..9763.0 | valid |
| `overhead_control` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 8609.0..8609.0 | valid |
| `queue_opaque_hook8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 5638.0..5638.0 | valid |
| `queue_packed_hook8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 5638.0..5638.0 | valid |
| `queue_plain_bytes8` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 45.0..45.0 | valid |
| `queue_real_receiver` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2422.0..2422.0 | valid |
| `queue_real_sender` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2422.0..2422.0 | valid |
| `sender_clone` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | -135.0..-135.0 | valid |
| `spsc_endpoint_carried_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2331.0..2331.0 | valid |
| `spsc_endpoint_fresh_reply` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2331.0..2395.0 | valid |
| `spsc_endpoint_pool4_reply` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2331.0..2395.0 | valid |
| `spsc_large64k_endpoint_pool4` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2331.0..2395.0 | valid |
| `spsc_large64k_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2023.0..2087.0 | valid |
| `spsc_opaque_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 5611.0..5611.0 | valid |
| `spsc_record_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | -30.0..-30.0 | valid |
| `spsc_record_pool4_control` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2133.0..2133.0 | valid |
| `spsc_scalar_persistent` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | -30.0..-30.0 | valid |
| `wait_empty_receiver_endpoint` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2455.0..2455.0 | valid |
| `wait_empty_receiver_record` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 162.0..162.0 | valid |
| `wait_full_sender_endpoint` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 2428.0..2428.0 | valid |
| `wait_full_sender_record` | 2 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 | 0.0..0.0 / 0.0..0.0 / 0.0..0.0 | 0.0..0.0 / 0.0..0.0 | 3.0..3.0 | valid |

Channel/control counts are actual native birth/destruction probes. Worker quiescence waits for the native end-of-worker release, not a fixed number of loop turns or public join alone; it is native domain-ownership retirement evidence, not an OS-join proof. The pre-wake resource-ownership correctness checkpoint intentionally retains known legacy detached-thread/proxy-early-terminal behavior and is not final Thread approval. The separate final corrected wake/join candidate requires actual OS join before every proxy terminal and full platform correctness evidence. Explicit residual collections occur outside body timing. The allocator's signed net delta is an observed ledger, **not** a complete retained-native-memory oracle; lifecycle counts are reported separately. Failed calibration, missing/truncated samples, checksum errors and unretired native domains reject a campaign.

### Overlapping source-scoped stage intervals

| Case | Wake attribution | Sender entry through encode | Queue lock + branch | Registration after failed check | Notify to continuation | Post-dequeue decode + return | Reply processing |
|---|---|---:|---:|---:|---:|---:|---:|
| `call_control` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `churn_cancel_parked_waiters` | `unavailable_cancelled_or_nonunique_notification` | 0.636/96.740 (1000 total; 500..500/round) | 0.050/0.331 (5000 total; 2500..2500/round) | 1.292/97.177 (2000 total; 1000..1000/round) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `churn_close_parked_receivers` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.040/0.326 (6000 total; 3000..3000/round) | 1.232/8.326 (2000 total; 1000..1000/round) | 2.094/7.845 (2000 total; 1000..1000/round) | unavailable (0 samples) | unavailable (0 samples) |
| `churn_close_parked_senders` | `exact_waiter_notification_to_continuation` | 1.082/11.867 (2000 total; 1000..1000/round) | 0.030/0.261 (7000 total; 3500..3500/round) | 0.692/3.491 (2000 total; 1000..1000/round) | 7.063/30.417 (2000 total; 1000..1000/round) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap0` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap1` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap64` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_cap8` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `closure_roundtrip_complex_sig` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_large64k_decode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_large64k_encode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_large64k_transfer_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_scalar_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_small_decode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_small_encode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_small_transfer_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_wide16_decode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_wide16_encode` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `codec_wide16_transfer_roundtrip` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `inspect_function` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `inspect_record` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `join_cleanup_cancelled_task` | `partial_exact_only` | unavailable (0 samples) | 0.286/7.469 (3200 total; 1600..1600/round) | unavailable (0 samples) | 16.471/48.852 (800 total; 400..400/round) | unavailable (0 samples) | unavailable (0 samples) |
| `join_ordinary` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.346/8.035 (1800 total; 900..900/round) | unavailable (0 samples) | 16.645/47.323 (600 total; 300..300/round) | unavailable (0 samples) | unavailable (0 samples) |
| `mpmc_endpoint_inflight16_cap16_4p4c` | `exact_waiter_notification_to_continuation` | 3.191/10.465 (4000 total; 2000..2000/round) | 0.351/9.818 (22675 total; 11310..11365/round) | 3.236/7.980 (2000 total; 1000..1000/round) | 56.155/164.173 (5016 total; 2507..2509/round) | 6.562/14.146 (2000 total; 1000..1000/round) | 0.035/0.090 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight16_cap2_4p4c` | `exact_waiter_notification_to_continuation` | 3.126/10.259 (4000 total; 2000..2000/round) | 0.331/9.908 (22479 total; 11192..11287/round) | 3.146/7.053 (2075 total; 1035..1040/round) | 52.809/182.201 (4895 total; 2424..2471/round) | 6.256/13.755 (2000 total; 1000..1000/round) | 0.030/0.101 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight1_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 2.054/6.307 (4000 total; 2000..2000/round) | 0.155/1.453 (22030 total; 11014..11016/round) | 1.508/5.014 (2000 total; 1000..1000/round) | 3.787/8.482 (5007 total; 2503..2504/round) | 2.865/7.889 (2000 total; 1000..1000/round) | 0.035/0.055 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight4_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 2.510/9.272 (4000 total; 2000..2000/round) | 0.166/3.466 (21718 total; 10817..10901/round) | 2.014/7.168 (2364 total; 1166..1198/round) | 11.352/39.239 (4532 total; 2238..2294/round) | 4.598/15.078 (2000 total; 1000..1000/round) | 0.035/0.060 (2000 total; 1000..1000/round) |
| `mpmc_endpoint_inflight4_cap4_2p2c` | `exact_waiter_notification_to_continuation` | 2.500/8.916 (4000 total; 2000..2000/round) | 0.161/3.978 (20967 total; 10382..10585/round) | 1.969/6.302 (2000 total; 1000..1000/round) | 10.134/45.239 (4211 total; 2060..2151/round) | 4.708/17.623 (2000 total; 1000..1000/round) | 0.035/0.080 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight16_cap16_4p4c` | `exact_waiter_notification_to_continuation` | 2.840/9.893 (4000 total; 2000..2000/round) | 0.210/5.836 (21749 total; 10447..11302/round) | 3.075/6.502 (2000 total; 1000..1000/round) | 47.844/145.668 (4585 total; 2102..2483/round) | 6.607/13.686 (2000 total; 1000..1000/round) | 0.035/0.090 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight16_cap2_4p4c` | `exact_waiter_notification_to_continuation` | 2.725/10.069 (4000 total; 2000..2000/round) | 0.266/7.980 (22011 total; 10961..11050/round) | 3.377/8.105 (2156 total; 1072..1084/round) | 52.508/169.481 (4681 total; 2332..2349/round) | 6.688/15.128 (2000 total; 1000..1000/round) | 0.030/0.081 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight1_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 1.538/7.314 (4000 total; 2000..2000/round) | 0.146/1.793 (22027 total; 11013..11014/round) | 1.508/5.646 (2000 total; 1000..1000/round) | 3.712/11.155 (5005 total; 2502..2503/round) | 2.995/10.249 (2000 total; 1000..1000/round) | 0.030/0.060 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight4_cap1_2p2c` | `exact_waiter_notification_to_continuation` | 1.719/6.487 (4000 total; 2000..2000/round) | 0.111/3.326 (21770 total; 10831..10939/round) | 1.793/5.561 (2366 total; 1182..1184/round) | 9.523/31.043 (4499 total; 2213..2286/round) | 4.158/15.344 (2000 total; 1000..1000/round) | 0.035/0.071 (2000 total; 1000..1000/round) |
| `mpmc_record_inflight4_cap4_2p2c` | `exact_waiter_notification_to_continuation` | 1.903/7.494 (4000 total; 2000..2000/round) | 0.155/4.117 (21217 total; 10577..10640/round) | 1.878/6.432 (2000 total; 1000..1000/round) | 11.556/35.165 (4365 total; 2159..2206/round) | 4.929/13.785 (2000 total; 1000..1000/round) | 0.030/0.060 (2000 total; 1000..1000/round) |
| `overhead_control` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `queue_opaque_hook8` | `no_suspensions` | 1.163/11.662 (10000 total; 5000..5000/round) | 0.030/0.135 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.678/19.030 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_packed_hook8` | `no_suspensions` | 1.643/28.378 (10000 total; 5000..5000/round) | 0.030/0.170 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.984/68.012 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_plain_bytes8` | `no_suspensions` | 0.776/3.486 (10000 total; 5000..5000/round) | 0.030/0.135 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.398/22.392 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_real_receiver` | `no_suspensions` | 1.212/9.122 (10000 total; 5000..5000/round) | 0.030/0.145 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.778/16.615 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `queue_real_sender` | `no_suspensions` | 1.207/9.182 (10000 total; 5000..5000/round) | 0.030/0.155 (20000 total; 10000..10000/round) | unavailable (0 samples) | unavailable (0 samples) | 1.773/15.043 (10000 total; 5000..5000/round) | unavailable (0 samples) |
| `sender_clone` | `no_suspensions` | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) | unavailable (0 samples) |
| `spsc_endpoint_carried_persistent` | `exact_waiter_notification_to_continuation` | 1.282/10.154 (4000 total; 2000..2000/round) | 0.150/1.022 (15947 total; 7973..7974/round) | 0.817/16.250 (2000 total; 1000..1000/round) | 2.069/8.772 (3947 total; 1973..1974/round) | 1.873/20.819 (2000 total; 1000..1000/round) | 0.065/1.002 (2000 total; 1000..1000/round) |
| `spsc_endpoint_fresh_reply` | `exact_waiter_notification_to_continuation` | 1.518/6.933 (2000 total; 1000..1000/round) | 0.195/0.771 (8000 total; 4000..4000/round) | 0.901/3.757 (1000 total; 500..500/round) | 2.354/6.487 (2000 total; 1000..1000/round) | 1.994/7.184 (1000 total; 500..500/round) | 0.076/1.032 (1000 total; 500..500/round) |
| `spsc_endpoint_pool4_reply` | `exact_waiter_notification_to_continuation` | 2.575/19.236 (4000 total; 2000..2000/round) | 0.281/1.538 (15942 total; 7970..7972/round) | 1.548/34.264 (1999 total; 999..1000/round) | 3.802/15.945 (3943 total; 1971..1972/round) | 3.462/35.752 (2000 total; 1000..1000/round) | 0.131/1.873 (2000 total; 1000..1000/round) |
| `spsc_large64k_endpoint_pool4` | `exact_waiter_notification_to_continuation` | 3.662/13.861 (1024 total; 512..512/round) | 0.256/1.583 (4096 total; 2048..2048/round) | 1.397/4.073 (512 total; 256..256/round) | 3.461/14.512 (1024 total; 512..512/round) | 3.026/7.484 (512 total; 256..256/round) | 0.120/0.361 (512 total; 256..256/round) |
| `spsc_large64k_persistent` | `exact_waiter_notification_to_continuation` | 3.893/13.755 (1024 total; 512..512/round) | 0.235/2.144 (4096 total; 2048..2048/round) | 1.027/3.772 (512 total; 256..256/round) | 3.898/10.550 (1024 total; 512..512/round) | 2.644/8.200 (512 total; 256..256/round) | 0.141/0.491 (512 total; 256..256/round) |
| `spsc_opaque_persistent` | `exact_waiter_notification_to_continuation` | 2.244/35.481 (4000 total; 2000..2000/round) | 0.275/1.518 (15966 total; 7981..7985/round) | 1.558/29.726 (2000 total; 1000..1000/round) | 3.937/12.704 (3966 total; 1981..1985/round) | 3.271/38.257 (2000 total; 1000..1000/round) | 0.155/2.069 (2000 total; 1000..1000/round) |
| `spsc_record_persistent` | `exact_waiter_notification_to_continuation` | 1.347/12.478 (4000 total; 2000..2000/round) | 0.165/1.047 (15909 total; 7953..7956/round) | 1.157/39.233 (2000 total; 1000..1000/round) | 2.926/9.608 (3909 total; 1953..1956/round) | 2.490/15.053 (2000 total; 1000..1000/round) | 0.100/1.393 (2000 total; 1000..1000/round) |
| `spsc_record_pool4_control` | `exact_waiter_notification_to_continuation` | 1.182/8.356 (4000 total; 2000..2000/round) | 0.225/1.343 (15936 total; 7962..7974/round) | 1.067/40.756 (2000 total; 1000..1000/round) | 3.261/9.262 (3936 total; 1962..1974/round) | 2.565/15.564 (2000 total; 1000..1000/round) | 0.140/1.482 (2000 total; 1000..1000/round) |
| `spsc_scalar_persistent` | `exact_waiter_notification_to_continuation` | 0.341/4.723 (4000 total; 2000..2000/round) | 0.166/1.869 (15534 total; 7552..7982/round) | 0.827/4.208 (2000 total; 1000..1000/round) | 3.035/8.552 (3537 total; 1555..1982/round) | 0.461/2.770 (2000 total; 1000..1000/round) | 0.025/0.041 (2000 total; 1000..1000/round) |
| `wait_empty_receiver_endpoint` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.245/1.703 (8000 total; 4000..4000/round) | 2.600/16.971 (1000 total; 500..500/round) | 3.056/9.778 (2000 total; 1000..1000/round) | 4.724/202.413 (1000 total; 500..500/round) | unavailable (0 samples) |
| `wait_empty_receiver_record` | `exact_waiter_notification_to_continuation` | unavailable (0 samples) | 0.200/1.673 (8000 total; 4000..4000/round) | 2.470/76.829 (1000 total; 500..500/round) | 2.890/11.040 (2000 total; 1000..1000/round) | 3.758/44.569 (1000 total; 500..500/round) | unavailable (0 samples) |
| `wait_full_sender_endpoint` | `exact_waiter_notification_to_continuation` | 3.776/119.613 (1000 total; 500..500/round) | 0.155/1.453 (11505 total; 5745..5760/round) | 1.192/4.268 (1912 total; 939..973/round) | 2.850/8.496 (2593 total; 1287..1306/round) | 2.815/10.524 (1000 total; 500..500/round) | unavailable (0 samples) |
| `wait_full_sender_record` | `exact_waiter_notification_to_continuation` | 2.144/17.954 (1000 total; 500..500/round) | 0.220/2.109 (11309 total; 5492..5817/round) | 1.357/65.893 (1797 total; 820..977/round) | 3.767/9.859 (2512 total; 1172..1340/round) | 2.805/14.923 (1000 total; 500..500/round) | unavailable (0 samples) |

Cells are medians of per-round p50/p99 microseconds, with total sample count and per-round count range. Wake modes list all observed round modes, not only the representative counter round. Encode/decode subintervals cover selected benchmark call brackets, not every worker's codec. Queue intervals include lock acquisition and readiness/closed branches, ending before unlock. Native wake correlates the exact selected waiter with its notification and successful continuation; cancelled/failed/nonunique notifications are unavailable, never attributed to a global last signal. It is not isolated kernel wake latency. Stages overlap across OS threads: do not add medians or subtract independently measured RTTs to manufacture a component time.

### Instrumentation overhead

| Case | Original SDK us/op | Private instrumented us/op | Difference us/op | Ratio |
|---|---:|---:|---:|---:|
| `call_control` | 0.055 | 0.083 | +0.028 | 1.514 |
| `churn_cancel_parked_waiters` | 81.481 | 87.403 | +5.922 | 1.073 |
| `churn_close_parked_receivers` | 27.545 | 30.206 | +2.661 | 1.097 |
| `churn_close_parked_senders` | 39.678 | 41.219 | +1.541 | 1.039 |
| `closure_roundtrip_cap0` | 3.009 | 3.683 | +0.674 | 1.224 |
| `closure_roundtrip_cap1` | 6.002 | 7.749 | +1.747 | 1.291 |
| `closure_roundtrip_cap64` | 142.429 | 219.049 | +76.620 | 1.538 |
| `closure_roundtrip_cap8` | 23.394 | 32.399 | +9.005 | 1.385 |
| `closure_roundtrip_complex_sig` | 6.060 | 8.619 | +2.559 | 1.422 |
| `codec_large64k_decode` | 8.199 | 8.391 | +0.192 | 1.023 |
| `codec_large64k_encode` | 8.650 | 8.384 | -0.266 | 0.969 |
| `codec_large64k_transfer_roundtrip` | 9.615 | 10.731 | +1.115 | 1.116 |
| `codec_scalar_roundtrip` | 0.482 | 0.674 | +0.192 | 1.398 |
| `codec_small_decode` | 1.107 | 1.504 | +0.397 | 1.358 |
| `codec_small_encode` | 0.478 | 0.566 | +0.089 | 1.186 |
| `codec_small_transfer_roundtrip` | 3.025 | 3.032 | +0.007 | 1.002 |
| `codec_wide16_decode` | 2.599 | 3.468 | +0.869 | 1.334 |
| `codec_wide16_encode` | 1.258 | 1.314 | +0.055 | 1.044 |
| `codec_wide16_transfer_roundtrip` | 4.884 | 6.053 | +1.169 | 1.239 |
| `inspect_function` | 2.017 | 2.631 | +0.614 | 1.304 |
| `inspect_record` | 0.169 | 0.217 | +0.049 | 1.288 |
| `join_cleanup_cancelled_task` | 42885.501 | 40754.184 | -2131.317 | 0.950 |
| `join_ordinary` | 7095.610 | 8831.258 | +1735.648 | 1.245 |
| `mpmc_endpoint_inflight16_cap16_4p4c` | 3.478 | 8.019 | +4.541 | 2.306 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | 3.623 | 7.714 | +4.091 | 2.129 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | 24.133 | 25.092 | +0.960 | 1.040 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | 6.428 | 11.008 | +4.580 | 1.712 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | 5.807 | 10.661 | +4.855 | 1.836 |
| `mpmc_record_inflight16_cap16_4p4c` | 3.452 | 7.210 | +3.758 | 2.088 |
| `mpmc_record_inflight16_cap2_4p4c` | 3.619 | 7.602 | +3.983 | 2.101 |
| `mpmc_record_inflight1_cap1_2p2c` | 20.019 | 24.309 | +4.290 | 1.214 |
| `mpmc_record_inflight4_cap1_2p2c` | 7.042 | 9.155 | +2.112 | 1.300 |
| `mpmc_record_inflight4_cap4_2p2c` | 6.624 | 9.807 | +3.183 | 1.481 |
| `overhead_control` | 0.070 | 0.092 | +0.023 | 1.328 |
| `queue_opaque_hook8` | 3.733 | 4.830 | +1.097 | 1.294 |
| `queue_packed_hook8` | 5.337 | 6.605 | +1.269 | 1.238 |
| `queue_plain_bytes8` | 3.382 | 3.882 | +0.500 | 1.148 |
| `queue_real_receiver` | 4.301 | 4.946 | +0.644 | 1.150 |
| `queue_real_sender` | 4.931 | 5.132 | +0.202 | 1.041 |
| `sender_clone` | 0.198 | 0.336 | +0.138 | 1.698 |
| `spsc_endpoint_carried_persistent` | 19.488 | 17.705 | -1.783 | 0.909 |
| `spsc_endpoint_fresh_reply` | 19.548 | 16.014 | -3.534 | 0.819 |
| `spsc_endpoint_pool4_reply` | 23.183 | 33.254 | +10.071 | 1.434 |
| `spsc_large64k_endpoint_pool4` | 48.003 | 45.343 | -2.659 | 0.945 |
| `spsc_large64k_persistent` | 42.219 | 44.812 | +2.593 | 1.061 |
| `spsc_opaque_persistent` | 20.761 | 32.145 | +11.384 | 1.548 |
| `spsc_record_persistent` | 20.051 | 23.127 | +3.076 | 1.153 |
| `spsc_record_pool4_control` | 17.429 | 23.974 | +6.545 | 1.376 |
| `spsc_scalar_persistent` | 8.316 | 11.540 | +3.224 | 1.388 |
| `wait_empty_receiver_endpoint` | 35.714 | 39.053 | +3.339 | 1.093 |
| `wait_empty_receiver_record` | 35.400 | 34.834 | -0.566 | 0.984 |
| `wait_full_sender_endpoint` | 34.314 | 37.551 | +3.237 | 1.094 |
| `wait_full_sender_record` | 37.303 | 40.599 | +3.296 | 1.088 |

### Matched protocol/shape endpoint component contrasts

| Case | Control | Case us/op | Control us/op | Difference us/op |
|---|---|---:|---:|---:|
| `mpmc_endpoint_inflight16_cap16_4p4c` | `mpmc_record_inflight16_cap16_4p4c` | 3.478 | 3.452 | +0.025 |
| `mpmc_endpoint_inflight16_cap2_4p4c` | `mpmc_record_inflight16_cap2_4p4c` | 3.623 | 3.619 | +0.004 |
| `mpmc_endpoint_inflight1_cap1_2p2c` | `mpmc_record_inflight1_cap1_2p2c` | 24.133 | 20.019 | +4.114 |
| `mpmc_endpoint_inflight4_cap1_2p2c` | `mpmc_record_inflight4_cap1_2p2c` | 6.428 | 7.042 | -0.614 |
| `mpmc_endpoint_inflight4_cap4_2p2c` | `mpmc_record_inflight4_cap4_2p2c` | 5.807 | 6.624 | -0.817 |
| `queue_real_receiver` | `queue_plain_bytes8` | 4.301 | 3.382 | +0.919 |
| `queue_real_sender` | `queue_plain_bytes8` | 4.931 | 3.382 | +1.549 |
| `spsc_endpoint_carried_persistent` | `spsc_record_persistent` | 19.488 | 20.051 | -0.562 |
| `spsc_endpoint_pool4_reply` | `spsc_record_pool4_control` | 23.183 | 17.429 | +5.754 |
| `wait_empty_receiver_endpoint` | `wait_empty_receiver_record` | 35.714 | 35.400 | +0.314 |
| `wait_full_sender_endpoint` | `wait_full_sender_record` | 34.314 | 37.303 | -2.989 |

### Payload-policy controls (not isolated endpoint costs)

| Case | Control | Case us/op | Control us/op | Difference us/op |
|---|---|---:|---:|---:|
| `queue_opaque_hook8` | `queue_plain_bytes8` | 3.733 | 3.382 | +0.351 |
| `queue_packed_hook8` | `queue_plain_bytes8` | 5.337 | 3.382 | +1.955 |
| `spsc_opaque_persistent` | `spsc_record_persistent` | 20.761 | 20.051 | +0.710 |

### Application-protocol contrasts (not matched endpoint components)

| Case | Control | Case us/op | Control us/op | Difference us/op |
|---|---|---:|---:|---:|
| `spsc_endpoint_fresh_reply` | `spsc_endpoint_pool4_reply` | 19.548 | 23.183 | -3.634 |
| `spsc_large64k_endpoint_pool4` | `spsc_large64k_persistent` | 48.003 | 42.219 | +5.783 |

Matched endpoint contrasts retain common field count, capacity, OS producer/consumer counts, in-flight budget and validation/protocol; payload representation, hooks, wrapper allocation and ownership differ together. They do not isolate only retain/release cost. Fresh/pool-four and large pool-four/persistent comparisons change application protocol and are kept in the separate protocol table.

