import datetime, hashlib, json, os, pathlib, subprocess, time
root=pathlib.Path('/tmp/titan-issue252-ownership-attested')
source=root/'source'
sdk=root/'sdk'
logs=root/'logs'
logs.mkdir(exist_ok=True)
env=os.environ.copy()
for key in ('ROCKS_TREE','TITAN_ROCKS_ROOT','TITAN_EXTRA_CPPFLAGS','TITAN_EXTRA_CFLAGS','TITAN_EXTRA_LDFLAGS','TITAN_NO_LINE_DIRECTIVES','LUA_PATH','LUA_CPATH','LUA_PATH_5_5','LUA_CPATH_5_5'):
    env.pop(key,None)
env.update(PREFIX=str(sdk),PATH=f'{sdk}/bin:/var/home/linuxbrew/.linuxbrew/bin:/usr/local/bin:/usr/bin:/bin',TITAN_BUILD_PROFILE='production',OPENSSL_MODE='system',OPENSSL_PKG_CONFIG='/usr/bin/pkg-config',TITAN_ABI_VERSION='2',TITAN_JOBS='4',MAKEFLAGS='-j4',CC='/usr/bin/gcc',AR='/usr/bin/ar',RANLIB='/usr/bin/ranlib')
argv=[str(sdk/'bin/luarocks'),'--force-lock','make','--force','--deps-mode=none','titan-0.6.0-1.rockspec']
log=logs/'build-ownership-provider.log'
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
clock=time.monotonic()
print(f'BUILD resource-ownership checkpoint: {argv}',flush=True)
with log.open('wb') as stream:
    result=subprocess.run(argv,cwd=source,env=env,stdout=stream,stderr=subprocess.STDOUT)
record=dict(argv=argv,cwd=str(source),env={key:env[key] for key in ('PREFIX','PATH','TITAN_BUILD_PROFILE','OPENSSL_MODE','OPENSSL_PKG_CONFIG','TITAN_ABI_VERSION','TITAN_JOBS','MAKEFLAGS','CC','AR','RANLIB')},started=started,elapsed_seconds=time.monotonic()-clock,returncode=result.returncode,log=str(log),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(root/'BUILD-COMMANDS.json').write_text(json.dumps([record],indent=2,sort_keys=True)+'\n')
print(f'END status={result.returncode}, seconds={record["elapsed_seconds"]:.3f}, log={log}',flush=True)
if result.returncode:
    raise SystemExit(result.returncode)
before=json.loads((root/'SOURCE-BEFORE.json').read_text())
after={rel:hashlib.sha256((source/rel).read_bytes()).hexdigest() for rel in before}
(root/'SOURCE-AFTER.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
changed=[rel for rel in before if before[rel]!=after[rel]]
if changed:
    raise RuntimeError(f'Build modified authored inputs: {changed}')
(root/'BUILD-ATTESTATION.json').write_text(json.dumps(dict(source_archives=json.loads((root/'SOURCE-ARCHIVES.json').read_text()),source_before=str(root/'SOURCE-BEFORE.json'),source_after=str(root/'SOURCE-AFTER.json'),authored_inputs_unchanged=True,authored_file_count=len(before),build_commands=str(root/'BUILD-COMMANDS.json'),completed=datetime.datetime.now(datetime.timezone.utc).isoformat(),sdk=str(sdk),checkpoint='Resource ownership; legacy Thread wake/join defects are not yet corrected'),indent=2,sort_keys=True)+'\n')
print(f'ATTESTED ownership provider built from {len(before)} unchanged authored inputs: {sdk}',flush=True)
