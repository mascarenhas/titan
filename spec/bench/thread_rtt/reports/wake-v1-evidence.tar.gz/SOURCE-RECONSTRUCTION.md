# Reconstructing the measured CPP2 sources and final v3 overlay

This is a replay recipe, not a claim that the publication author rebuilt or retested anything. Actual run/build receipts remain authoritative. Use fresh absolute extraction and rebuild directories; never write over an attested source or SDK. Native upstream sources/toolchain/system OpenSSL must match the recorded policy and may require network fetches. This is not an offline native-source bundle or a promise of byte-identical debug/path-dependent outputs on another toolchain/path.

## Archive navigation

- `campaign/`: exact parent-produced raw/summary JSON, original TSVs, logs, private authored probe sources, prefix/source manifests, audits and tables.
- `harness/`: the exact immutable nine-file final harness plus its freeze handoff.
- `build/`: actual SDK preparation scripts, argv/environments/logs, source inventories, policy and attestation records. Those historical scripts retain their original absolute paths and prepared-native/Lua copy strategy; do not run them unchanged against an old prefix.
- `source-inputs/common/`: original66d source archive, Lua025b archive, skills9d archive, resource-r3 overlay, common two-file CPP2 compiler overlay, four approved dependency rocks and MIT license records.
- `source-inputs/titan-issue252-final-measured-cpp2-v1-overlay.tar.gz`: all 90 actual authored additions/replacements over the prewake CPP2 source, including the immutable historical reports needed by the full 1157-file source inventory. `final-measured-v1-overlay.json` records its basis, hashes and one deletion.
- `source-inputs/titan-issue252-final-corrective-abi2-v3-delta.tar.gz`: the parent-produced final delivered overlay; apply it only to a separate copy of the exact measured candidate source.
- `EVIDENCE-FILES.json`: payload-member byte hashes and sizes. `RECORDED-PATHS.json`: recorded original file paths/URIs mapped to extraction-relative members. Raw JSON paths/bytes have not been rewritten. SDK/provider/executable/generated-object outputs are intentionally excluded.

## Exact measured source reconstruction

Set `EVIDENCE` to the extracted archive and `REPLAY` to a fresh absolute output root. These commands describe a new reproduction; they were not executed by the report author.

```sh
set -eu
COMMON="$EVIDENCE/source-inputs/common"
A="$COMMON/titan-issue252-baseline-attested"
for L in final-resource wake; do
  S="$REPLAY/$L/source"
  mkdir -p "$S"
  tar -xf "$A/source-parent.tar" -C "$S"
  tar -xf "$A/source-lua-5.5.1_.tar" -C "$S"
  tar -xf "$A/source-.agents_skills_.tar" -C "$S"
  tar -xzf "$COMMON/titan-issue252-abi2-prewake-production-r3.tar.gz" -C "$S"
  tar -xzf "$COMMON/titan-issue252-final-common-compiler-overlay.tar.gz" -C "$S"
done
tar -xzf "$EVIDENCE/source-inputs/titan-issue252-final-measured-cpp2-v1-overlay.tar.gz" \
  -C "$REPLAY/wake/source"
# The overlay manifest's exact deletion, in the fresh reconstruction only:
rm "$REPLAY/wake/source/spec/stdlib/titan/thread/tests.titan"
```

The baseline's authored inventory is in `build/prewake-cpp2/SOURCE-BEFORE.json`; the candidate's is in `build/wake-final-cpp2-v1/SOURCE-BEFORE.json` and `source-inputs/titan-issue252-final-corrective-abi2-v1-SOURCE.json`. The common compiler overlay contains exactly `coder/module.lua` and `coder/statements.lua`; it belongs to both measured lanes. All ABI/version numbers remain unchanged.

## Fresh SDK preparation without borrowing an old SDK

Use Linux x86_64 and the captured GCC16.2.1/ar/ranlib/system OpenSSL3.5.9/native dependency policy. The source Make/rockspec recipes build Lua/native dependencies and the official full 26-root provider. Install the four archived dependency packages directly, rather than the historical builder's old-prefix packaging step. Two packages contain approved original third-party `.so` inputs; their licenses are preserved. These are not Titan SDK/provider binaries.

```sh
for L in final-resource wake; do
  S="$REPLAY/$L/source"
  PFX="$REPLAY/$L/sdk"
  (
    set -eu
    cd "$S"
    unset ROCKS_TREE TITAN_ROCKS_ROOT TITAN_EXTRA_CPPFLAGS TITAN_EXTRA_CFLAGS
    unset TITAN_EXTRA_LDFLAGS TITAN_NO_LINE_DIRECTIVES TITAN_PATH TITAN_PATH_0_6
    unset LUA_PATH LUA_CPATH LUA_PATH_5_5 LUA_CPATH_5_5 LUA_INIT LUA_INIT_5_5
    unset LD_LIBRARY_PATH CFLAGS CPPFLAGS LDFLAGS
    export PREFIX="$PFX" PATH="$PFX/bin:/usr/local/bin:/usr/bin:/bin"
    export TITAN_BUILD_PROFILE=production OPENSSL_MODE=system
    export OPENSSL_PKG_CONFIG=/usr/bin/pkg-config TITAN_ABI_VERSION=2
    export TITAN_JOBS=4 MAKEFLAGS=-j4 CC=/usr/bin/gcc AR=/usr/bin/ar
    export RANLIB=/usr/bin/ranlib TITAN_PROBE_CACHE_DISABLE=1
    /usr/bin/make luarocks
    for ROCK in "$A/dependency-rocks/"*.rock; do
      "$PFX/bin/luarocks" --tree="$PFX" install "$ROCK" --deps-mode=none
    done
    "$PFX/bin/luarocks" make --force --deps-mode=none titan-0.6.0-1.rockspec
  )
done
```

Retain actual verbose native/provider/compiler argv and new source/SDK before/after manifests. Preserve the complete production flags and default line directives, not an optimization-only override. Replay the UV/llhttp/SQLite public SDK header export policy from each archived receipt's `native_policy.sdk_header_replay` map: each SDK-relative key names the original source-relative header and byte hash. Install those headers from the newly prepared native source into the fresh SDK and retain its before/after inventory evidence. Use the recorded source/native/header/compiler build evidence and frozen README receipt schema to issue **new** receipts for the new roots; old path-sensitive SDK hashes are not new-build attestations.

Then invoke `harness/measure.py build` separately with each new matching source/SDK/receipt and fresh output, using the exact ordered C flags/link policy from the archived `BUILD.json`/freeze. Run both full-catalog smoke modes, retain smoke files, stop competing builds/tests, record new host/quiescence evidence and run the matched comparison. `CATALOG.json` comes from the executed summary metadata, not an additional claimed plan run. `MEASUREMENT-COMMANDS.json` preserves the frozen command contract and actual campaign options. Parent-produced `TABLES.md` is preserved byte-for-byte; no publication-side renderer run is claimed.

## Final delivered v3, kept distinct from measurement

After preserving the measured candidate tree, copy it to a separate fresh final-v3 source root and extract `titan-issue252-final-corrective-abi2-v3-delta.tar.gz` there. The parent v3 full manifest is included in both JSON and `titan-issue252-final-corrective-abi2-v3.source.sha256` form. Its 51 changed/new authored files, with no v1 deletions, are exactly the delta archive's 51 files by the supplied manifests. Do not overwrite or relabel the measured CPP2 SDK.

The parent equivalence receipt records identical normalized generated C for 121,249 `bench.c` lines and all 26 stdlib modules except one cosmetic `int volatile`/`volatile int` local declaration in `os.c`. This supports relevance to the final compiler/runtime fixes; it is not an independently rerun v3 performance campaign, binary identity claim, or sanitizer/platform result. Final v3 includes compiler borrowed-pointer spill fixes and the conditional minicoro ASan guard; retain that distinction in any subsequent reproduction.
