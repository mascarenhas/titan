# Issue #252 Final Benchmark Harness & Probe Semantics Review (`GeminiBenchmarkReview`)

## 1. Loaded Skills
- `titan-programmer` (`skill://titan-programmer`)
- `titan-tester` (`skill://titan-tester`)
- `titan-async` (`skill://titan-async`)
- `titan-thread` (`skill://titan-thread`)
- `titan-ffi` (`skill://titan-ffi`)
- `titan-reflect` (`skill://titan-reflect`)

## 2. Reviewed Source Inventory (Read-Only Static Audit)
- **Freeze manifest**: `local://issue252-final-benchmark-harness-freeze.json` (`#782E`, replacing `#3DCD`)
- **Harness & reporting sources (`spec/bench/thread_rtt/`)**:
  - `measure.py` (`#36DA`, lines `1-1477`, SHA-256 `6d84aad9be7a036fad2e7530b27213395dbee84bfef6146a23d6eda23a54f335`)
  - `compare.py` (`#BC62`, lines `1-313`, SHA-256 `ebdcdc10b42962835f2b417a50e12bddaea6f57f965a480d7fed63b5c7a01958`)
  - `summarize.py` (`#BC17`, lines `1-337`, SHA-256 `218ddb05355b446578bb62d71046808a378d4f34ae55d2dd158496bc05d4a011`)
  - `compile_guard.lua` (`#17D7`, lines `1-87`, SHA-256 `d8baf0c0dcaa3641e907e0ee6a533f3bf9a240c4323f4ef5ebb63aacbb25278b`)
  - `bench.titan` (`#0055`, lines `1-2235`, SHA-256 `5a9e13bbed374169451611b064461c6312e69724328fa8f968140beacbe2a00b`)
  - `rtt_probe.c` (`#DC96`, lines `1-1670`, SHA-256 `76f000d72ac276f86737cebb181e6ac54c5d97829049128408f79a45d1db023e`)
  - `rtt_probe.h` (`#0F7D`, lines `1-80`, SHA-256 `a1836505b16121e47a4c65f2f218050772a158e58f53ad740608c9250b32e7fe`)
  - `README.md` (`#2A57`, lines `1-694`, SHA-256 `3965abbd73e0f5569f9ef2e1132a5a55233dc4218797ad74db17d17daee51ac4`)
  - `REPORT_TEMPLATE.md` (`#A1B2`, lines `1-386`, SHA-256 `06644223d46a4e443469f190b8923e871bdf050e7fe34b74b2c7d08907904bb2`)
- **Historical baseline publication (`spec/bench/thread_rtt/reports/`)**:
  - `resource-v4-report.md` (`#D07F`, lines `1-217`)
  - `resource-v4-publication.json` (`#B71B`, lines `1-15`)
  - `resource-v4-tables.md` (`#6021`, lines `1-123`)
- **Audited production probe owners (read-only verification of anchors & semantics)**:
  - Candidate tree: `titan/async.titan` (`#A82F`, lines `1-153, 429-543, 729-833, 1444-1903, 1979-2093`), `titan/thread/thread.titan` (`#A708`, lines `1-425`), `titan/thread/channel.titan` (`#FBB9`, lines `1-466`), `titan/thread/spawn.titan` (`#FA5C`, lines `1-1024`)
  - Pre-wake Cpp2 baseline tree: `/tmp/titan-issue252-prewake-cpp2/PROVIDER-RECEIPT.json` (`#770B`, lines `1-126`), `/tmp/titan-issue252-prewake-cpp2/source/titan/thread/thread.titan` (`#4D78`, lines `1-458`), `/tmp/titan-issue252-prewake-cpp2/source/titan/thread/channel.titan` (`#C11F`, lines `1-403`), `/tmp/titan-issue252-prewake-cpp2/source/titan/thread/spawn.titan` (`#9CB6`, lines `1-1009`)

---

## 3. Audit Findings & Closed Verification Questions

### 3.1 Primary vs Instrumented Isolation, Full 26-Root Rebuild, Native Archive Reuse, and Cpp2 Provenance
- **Status**: **CLOSED / VERIFIED IN SOURCE (No defects)**
- **Evidence**:
  - **Primary (`uninstrumented`) isolation (`measure.py:878-906`, `compile_guard.lua:64-86`)**:
    - Compiles `rtt_probe_uninst.o` with `-DRTT_PROBE_WRAPPERS=0` and links `uninstrumented/bench` against the untouched installed SDK prefix (`TITAN_PATH_0_6 = prefix/lib/titan/0.6`) without `-Wl,--wrap=...`.
    - `compile_guard.lua:68-77` enforces `count == 1` (`filename == "./bench.titan"`), preventing any accidental source fallback into `titan/` standard-library sources.
  - **Private 26-root instrumented provider & original Native payload reuse (`measure.py:908-942`)**:
    - Verifies the leading 26 archive members of `prefix/lib/titan/0.6/titan.a` match `[name + ".o" for name in STDLIB_MODULES]` (`measure.py:180-185, 914-916`), strips only those 26 Titan module objects via `ar dN 1` into `original-native.a`, re-indexes with `ranlib`, and compiles all 26 `titan.<module>` roots (`--source-first --tree snapshot`) against `original-native.a` and `rtt_probe_inst.o` (`-DRTT_PROBE_WRAPPERS=1` + 13 `--wrap` symbols).
    - `readelf -d` (`measure.py:961-968`) rejects any dynamic `NEEDED.*(?:titan|liblua)` dependency in both executables.
    - Prefix immutability (`PREFIX-BEFORE.json` == `PREFIX-AFTER.json`, `measure.py:813-814, 980-985`) and `verify_sdk_header_replay` (`measure.py:524-550, 845-846, 971`) fail closed on any prefix or header drift.
  - **ABI 2 & Cpp2 provenance (`compile_guard.lua:11-60`, `compare.py:57-72`, `/tmp/titan-issue252-prewake-cpp2/PROVIDER-RECEIPT.json:8-23`)**:
    - `compile_guard.lua` enforces `TITAN_ABI_VERSION == "2"`, `TITAN_VERSION == "0.6.0"`, `TITAN_LIBRARY_VERSION == "0.6"`, `LANGUAGE_SERVER_API_VERSION == 1`, exact `BUILD_PROFILE`, `EMIT_LINE_DIRECTIVES`, and complete `toolchain_descriptor` / `generated_compile_prefix` flags.
    - `/tmp/titan-issue252-prewake-cpp2/PROVIDER-RECEIPT.json` binds the exact two common compiler Lua patches (`coder/module.lua` `c324ee5d...`, `coder/statements.lua` `d7d735e7...`) and identical Lua/native archives.

### 3.2 All-State Warmup, GC, and Ready Barriers
- **Status**: **CLOSED / VERIFIED IN SOURCE (No defects)**
- **Evidence**:
  - **Codec & same-state queue (`bench.titan:477-494, 604-615`)**: Execute `warmup` untimed iterations, record `rtt_probe_mark_warmup_done`, run two full `gc.collect()` passes, and keep automatic Lua GC enabled throughout `start_body`..`stop_body`.
  - **SPSC (`bench.titan:650-1270`)**: Worker signals `rdy:send(1)` after bootstrap; the warmup loop sends negative IDs `-1..-warmup` through the worker, where `id < 0` runs `gc.collect(); gc.collect()` inside the worker state and sends the warmup reply before the host runs `gc.collect()` and enters `start_body`.
  - **MPMC (`bench.titan:1282-1470`)**:
    - Every consumer OS thread (`c = 1..consumers`, `bench.titan:1383-1388, 1412-1417`) warms its request/endpoint and reply codecs locally via `warm_channel(...)` and runs `gc.collect(); gc.collect()` *before* sending `ready:send(1)`. This guarantees every consumer state is warmed and collected even if shared-queue warmup traffic is unevenly distributed across consumers.
    - Every producer lane Task (`producers * in_flight` lanes across `producers` OS threads, `bench.titan:1317-1322`) executes `config.warmup` negative-ID exchanges across the shared channels, runs `gc.collect(); gc.collect()`, sends `config.ready:send(1)`, and blocks on `config.start:receive()`.
    - The coordinator waits for all `producers * in_flight + consumers` ready tokens (`bench.titan:1462`), marks `warmup_done`, runs `gc.collect(); gc.collect()`, calls `rtt_probe_start_body`, and only then releases `start_tx:send(1)` (`bench.titan:1466-1467`).

### 3.3 Final Shared-Wake After-Yield Registrar Probes, Prepared vs Actual Non-Inline Cleanup Parking, Notifications, and True OS Join
- **Status**: **CLOSED / VERIFIED IN SOURCE (Cleanup-registrar-ready recheck edge fixed in `#782E`)**
- **Evidence**:
  - **Ordinary shared-wake post-yield registration (`measure.py:324-326, 450-462`, `rtt_probe.c:767-804, 855-864, 1309-1325`)**:
    - `Sender:send`, `Receiver:dequeue_or_wait`, and `Thread:wait_until_finished` wrap `async.wait_external` in `rtt_wait_external(waiter, ...)`, which calls `rtt_probe_external_prepare(waiter)` before yielding.
    - `rtt_probe_external_prepare(waiter)` binds `waiter` in `g_waiters` with `entry->post_yield = 1` and `entry->op_slot = tls_current_op_slot`.
    - `__wrap_mco_yield` clears `tls_current_op_slot = -1` across the yield and never leaves a post-yield waiter in `tls_pending_waiter` (`rtt_probe.c:773, 1310-1324`).
    - When `start_external_wait` runs after the yield and invokes `channel_try_enqueue_native` / `channel_try_dequeue_native` / `thread_control_register_join_waiter`, `rtt_probe_attempt_end` looks up `entry = find_waiter(waiter)`:
      - Because `rtt_probe_external_prepare` bound `waiter` before the yield, `entry` is found both when registration parks (`result == 1`) and when the post-yield registration recheck succeeds inline (`result == 0`).
      - `id = entry->op_slot` restores the originating `g_active_ops` slot across the yield so `wait_registration_samples` and `dequeue_done_ns` (for `receiver_decode_samples`) are attributed to the exact operation slot.
      - Only `post_yield && result == 1` sets `entry->suspended = 1` and increments `actual_suspensions` (and `ordinary_join_suspensions` when `kind == RTT_OP_JOIN`); `waiter != NULL && result == 0` increments `registration_recheck_successes` without setting `entry->suspended`.
  - **Prearmed native retirement vs actual post-yield cleanup suspension (`measure.py:387-431`, `rtt_probe.c:866-951`, `titan/async.titan:1799-1849`)**:
    - Prearming in `run_with_cleanup` calls `thread_control_register_retirement_native`, where `rtt_probe_retirement_bind(context, target)` binds `ctrl` in `g_waiters` (`cleanup = 1, post_yield = 1, suspended = 0, target = target`) without incrementing any wait or suspension counter.
    - When the proxy enters cleanup and calls `final_wait:wait_cleanup()` -> `ExternalWait:await(WAIT_CLEANUP)` (`titan/async.titan:1828`), `retirement_poll_native(self.native)` runs and `rtt_probe_retirement_check(self.native.context, status)` records `fast_successes` if `status == 0` or `slow_path_attempts` if `status != 0` (`rtt_probe.c:894-900`).
    - If `status == 0` (child already finished and OS-joined inline), `rtt_probe_waiter_complete(self.native.context, 1)` runs with `entry->suspended == 0`, recording the prearmed signal as `unattributed_wakes` (`rtt_probe.c:942-944`) rather than a fake wake sample or cleanup suspension.
    - If `status > 0` (`ctrl.finished == 0`), `ExternalWait:await` yields `start_native_retirement_wait`. In `#782E`, `measure.py:406-413` instruments `start_native_retirement_wait` to branch on `owner.native.ready ~= 0`:
      - If `owner.native.ready ~= 0`, `rtt_probe_retirement_registered(context, 0)` increments `registration_recheck_successes` and leaves `entry->suspended = 0`.
      - If `owner.native.ready == 0`, `rtt_probe_retirement_registered(context, 1)` sets `entry->suspended = 1` and increments `actual_suspensions` and `g_join_suspensions[1]` (`cleanup_join_suspensions`).
    - When the child finishes and calls `thread_control_complete_native(ctrl)`, `rtt_probe_retirement_notify(ctrl, proxy_target)` verifies `entry->target == proxy_target` and timestamps the notification on `ctrl` (distinct from any `titan_thread_waiter` in `titan_thread_join_queue(ctrl)`).
    - On the host loop, `ExternalBridge:drain()` (`titan/async.titan:1665`) polls `retirement_poll_native(owner.native)` -> `thread_control_retire_native(ctrl)` -> `uv.native_thread_join(token)` before waking the proxy Task, which then calls `rtt_probe_waiter_complete(self.native.context, 1)` on return from `ExternalWait:await`, recording an exact attributed wake sample (`returned - notified`) and clearing the `g_waiters` slot.
    - `ExternalWait:retire()` and `thread_control_unregister_retirement_native()` both call `rtt_probe_waiter_complete(..., 0)` as idempotent cleanup guards so no `g_waiters` slot can leak.
  - **Compatibility with `ThreadIntegration` cancellation-transport fix (`titan/thread/spawn.titan:151-167, 229-263, 382-415`)**:
    - All 16 `transform(...)` owners and string anchors in `measure.py:240-463` were cross-checked line-by-line against `titan/thread/{thread,channel,spawn}.titan` (`#A708`, `#FBB9`, `#FA5C`), `titan/async.titan` (`#A82F`), and `/tmp/titan-issue252-prewake-cpp2/source/titan/thread/{thread,channel,spawn}.titan` (`#4D78`, `#C11F`, `#9CB6`). Every anchor matches uniquely in both trees; the direct-payload + native-reason-kind cancellation changes in `spawn.titan` do not touch any probe anchor.

### 3.4 Bounded Pre-Permit MPMC Fairness Traces & After-Join Consumer Share
- **Status**: **CLOSED / VERIFIED IN SOURCE (No defects)**
- **Evidence**:
  - **Preallocation & scope (`bench.titan:1349-1353`, `rtt_probe.c:591-607`)**: `rtt_probe_mpmc_setup(count, producers, in_flight, consumers)` preallocates `g_probe.op_traces` (`count + 1` entries via `raw_calloc`) in both uninstrumented and instrumented modes before channel/worker creation, warmup, or body timing.
  - **Pre-permit vs post-permit timestamps (`bench.titan:1291-1314`)**:
    - `rtt_probe_trace_permit_start(id, config.index, lane_index, rtt_probe_now_ns())` is recorded immediately before `config.permits[slot]:receive()`.
    - `t0 = rtt_probe_now_ns()` is recorded immediately after `config.permits[slot]:receive()`, preserving the original post-permit RTT measurement (`t5 - t0`) in `rtt_samples` while recording `t0_send_start = t0` and `t5_reply_recv = t5` in `op_traces[id]`.
  - **After-join positive consumer counts (`bench.titan:1389-1404, 1418-1434, 1476-1484`)**:
    - Consumers increment `processed` only for measured requests (`job.id > 0`), excluding negative warmup IDs and channel EOF.
    - After `stop_body` and `join_worker(workers[c])`, `rtt_probe_mpmc_consumer_done(c, worker_count)` records each consumer's count and verifies `sum(consumer_operations) == count`.
  - **Fail-closed trace validation & edge cases (`rtt_probe.c:1362-1400`, `measure.py:591-659, 1127-1131`)**:
    - `write_mpmc_trace` and `read_mpmc_fairness` both enforce: non-empty `request_trace_path` (`$sample_file.requests.tsv`), `mpmc_trace_failures == 0`, exact `1..count` request IDs, exact deterministic `(producer, lane)` partition, causal timestamp ordering `0 <= permit_start_ns <= send_start_ns <= reply_received_ns <= body_wall_ns`, non-overlapping sequential requests within each `(producer, lane)` (`permit >= history[-1].reply`), exact per-lane expected counts, and `sum(consumer_operations) == count`.
    - Unassigned lanes in 50-op smoke runs (`in_flight = 16, producers = 4` -> 64 lanes, lanes 51..64 have `expected = 0`) and single-completion intercompletion gaps produce `None` (`unavailable`), never `0`.

### 3.5 Historical Report Boundaries & Reproducibility
- **Status**: **CLOSED / VERIFIED IN SOURCE (No defects)**
- **Evidence**:
  - `spec/bench/thread_rtt/reports/resource-v4-{report.md,tables.md,publication.json}` remain untouched at their committed `74c26e3f` state, explicitly disclosing legacy per-wait `uv_async_t` handles, detached worker threads, proxy-early-terminal limits, post-permit-only historical MPMC RTT, and no final wake/join speedup claim.
  - `README.md`, `REPORT_TEMPLATE.md`, and `summarize.py` explicitly document the common final-harness wake continuation boundary (return of `wait_on_native_waiter` / `async.wait_external` including helper cleanup) vs historical `frozen-v4` raw coroutine-return sampling, and prohibit pooling across harness phases or claiming a pure wake-only intervention when comparing the combined final candidate (shared wakes + joinable OS-thread retirement + generic async native retirement + complex cancellation reason transport).


### 3.6 Actionable Wording Finding: Ordinary vs Cleanup-Join Native-Wake Continuation Endpoint
- **Severity**: Low (Documentation / Report-Wording Precision; does **not** alter C probe logic or invalidate `#782E` builds/campaigns)
- **Exact Locations & Symbols**:
  - Probe injection sites:
    - Ordinary waits: `spec/bench/thread_rtt/measure.py:318-334` (`complete_wait` on `Sender:send`, `Receiver:dequeue_or_wait`, `Thread:wait_until_finished` / `Thread:join`) and `measure.py:451-460` (`rtt_wait_external`)
    - Legacy cleanup-join wait: `spec/bench/thread_rtt/measure.py:373-381` (`join_probe` on `Thread:wait_until_finished_cleanup`, `/tmp/titan-issue252-prewake-cpp2/source/titan/thread/spawn.titan:742-787`)
    - Shared native-retirement cleanup wait: `spec/bench/thread_rtt/measure.py:414-424` (`native_await` on `ExternalWait:await`, `titan/async.titan:1818-1849`, called from `Thread:task` cleanup `titan/thread/spawn.titan:898-901`)
  - Affected prose/renderer lines:
    - `spec/bench/thread_rtt/summarize.py:39-42, 61-63` (`provenance`, `lane_tables`)
    - `spec/bench/thread_rtt/README.md:258-261` (`Overlapping stage intervals`)
    - `spec/bench/thread_rtt/REPORT_TEMPLATE.md:320-323` (`Section 7`)
- **Source Proof**:
  - **Ordinary waits** (`Sender:send`, `Receiver:dequeue_or_wait`, ordinary `Thread:join` / `Thread:wait_until_finished`):
    - In the legacy lane (`measure.py:327-333`), `ffi.rtt_probe_waiter_complete(waiter as foreign *void, 1)` is placed in the caller *after* `wait_on_native_waiter(...)` returns (`prewake-cpp2/source/titan/thread/thread.titan:447-454`), so `wait_on_native_waiter`'s `defer finish_wait()` (`uv.close(handle_view)`, skipping `unregister_fn()` because `resumed_normally = true`) has already executed.
    - In the shared lane (`measure.py:324-326, 451-460`), `rtt_wait_external` calls `ffi.rtt_probe_waiter_complete(waiter, 1)` *after* `async.wait_external(register_fn, unregister_fn)` returns (`titan/async.titan:1852-1866, 1876-1882`), so `ExternalWait:await`'s `defer` (`self:retire()` / `uv.native_external_wake_unregister(target)` and `clear_suspension(task)`, skipping `self:detach_domain()` because `completed = true`) and `wait_external`'s `defer owner:close()` have already executed.
    - Thus, for ordinary waits in both lanes, the `native_wake` endpoint is indeed the return of the wait helper **including** its normal-return `defer` cleanup.
  - **Cleanup-join waits** (`join_cleanup_cancelled_task`):
    - In the legacy lane (`measure.py:374-380`, `prewake-cpp2/source/titan/thread/spawn.titan:763-787`), `ffi.rtt_probe_waiter_complete(waiter as foreign *void, 1)` is appended at the end of `Thread:wait_until_finished_cleanup`'s function body immediately after `async.await_cleanup(...)` returns. Because Titan executes block-level `defer` statements upon exiting the function block *after* the final body statement, `rtt_probe_waiter_complete(..., 1)` runs **before** `Thread:wait_until_finished_cleanup`'s `defer finish_handle()` (`thread_control_unregister_join_waiter` and `uv.close(handle_view)`).
    - In the shared lane (`measure.py:418-423`, `titan/async.titan:1822-1848`), `ffi.rtt_probe_waiter_complete(self.native.context, 1)` is inserted immediately before `return` inside `ExternalWait:await`. Because Titan runs `defer` when `return` exits `ExternalWait:await`, `rtt_probe_waiter_complete(..., 1)` runs at the end of `ExternalWait:await`'s body **before** `ExternalWait:await`'s own `defer` (`self.done = nil; clear_suspension(task)`) and **before** `Thread:task` cleanup's outer `defer final_wait:close()` (`ExternalWait:retire()`).
- **Consumer Consequence**:
  - Describing all `native_wake` samples uniformly as ending at `"native-await return including helper cleanup"` is exact for all ordinary channel/join waits, but slightly overstates what is inside the timestamp bracket for `join_cleanup_cancelled_task`, where both lanes sample at the end of the cleanup-wait body *before* its own `defer` cleanup.
- **Smallest Correction**:
  - Keep `#782E` frozen during parent build/campaign execution (do not invalidate `helper_sha256` in `BUILD.json`), and state the exact split in the authored final report (and in `summarize.py` / `README.md` / `REPORT_TEMPLATE.md` only if another harness freeze is ever opened):
    > *"Ordinary native-wake intervals end after `wait_on_native_waiter` / `async.wait_external` returns (including the helper's normal-return `defer` cleanup), whereas cleanup-join wake intervals (`Thread:wait_until_finished_cleanup` / `ExternalWait:await` on native retirement) end at the wait body's successful completion before its own `defer` cleanup."*

### 3.7 Closed Question: Pre-Notify Timestamping vs Post-Call `rtt_probe_waiter_signal_result` Ordering
- **Status**: **CLOSED / VERIFIED IN SOURCE (Current pre-notify + post-call `signal_result` design is sound; a pending-until-return gate would break fast wakes)**
- **Question Audited**: `rtt_probe_waiter_notify` records `notified_ns` and increments `entry->notifications` (`0 -> 1`) *before* `uv.native_external_wake_notify(target)` / `uv.async_send_native(waiter.async_handle)`, while `rtt_probe_waiter_signal_result` sets `entry->notifications = UINT32_MAX` on `result != 0` *after* the call returns. Could the waiting OS thread run `rtt_probe_waiter_complete(..., 1)` before `rtt_probe_waiter_signal_result` and attribute a failed/unproven notification?
- **Source Proof**:
  1. **Why `notified_ns` and `notifications++` MUST precede the native notify call**:
     - As soon as `native_external_wake_notify` unlocks `core` mutex (`titan/uv/external_wake.titan:147`) or `uv_async_send` signals the loop's eventfd, the destination OS thread (Thread B) can drain the identity, resume the waiting Task, and execute `rtt_probe_waiter_complete(waiter, 1)` *before* the waking OS thread (Thread A) returns from `native_external_wake_notify` and runs `rtt_probe_waiter_signal_result`.
     - If `entry->notifications` remained `0` (or "pending") until *after* `native_external_wake_notify` returned on Thread A, any fast cross-thread wake where Thread B reached `rtt_probe_waiter_complete(waiter, 1)` first would falsely classify a genuine wake as unattributed (`signals != 1`).
  2. **Why a failed notify (`rtt_signal != 0`) cannot race with `rtt_probe_waiter_complete(..., 1)` on Thread B**:
     - **Shared bridge (`native_external_wake_notify`, `titan/uv/external_wake.titan:111-149`)**:
       - Every error return (`target == nil`, `core.handle == nil`, `phase == TITAN_UV_WAKE_RETIRED`, `phase == TITAN_UV_WAKE_PREPARED`, lines `112-127`) returns `UV_EINVAL` *without* linking `target` into `core.head..core.tail` and *without* calling `uv_async_send`. Because `target` is never queued in `core.head..core.tail`, `external_wake_drain_native` (`external_wake.titan:304-314`) on Thread B can never drain `target.identity`, `ExternalBridge:drain()` (`titan/async.titan:1658-1686`) never calls `owner:notify()`, and the waiting Task never resumes normally (`normal == 1`).
       - Moreover, `start_external_wait` activates `target` (`PREPARED -> ARMED`, `titan/async.titan:1780`) *before* `owner.register_fn(owner.target)` publishes `waiter` under `ch.mutex` / `ctrl.mutex`, and `waiter_wake_one` (`titan/thread/thread.titan:103-122`) pops `waiter` under that same mutex while `waiter.active == 1`, so `target` is guaranteed non-nil and `ARMED` (or `DELIVERED`, which returns `0`). On `ARMED`, `native_external_wake_notify` links `target` into `core.tail` (`phase = PENDING`) and calls `uv_async_send(core.handle)` under `core` mutex (which unconditionally returns `0` in bundled libuv 1.53.0 on Linux).
     - **Legacy per-wait handle (`uv.async_send_native`, `prewake-cpp2/source/titan/thread/thread.titan:116-118, 433-436`)**:
       - `wait_on_native_waiter` initializes a dedicated `uv.async_t` before `register_fn`. Only `waiter_wake_one` signals that handle; if `uv_async_send` ever failed, the `uv.async_t` callback (`task:resume(token)`) would never fire on Thread B, so `wait_on_native_waiter` could never return normally to `rtt_probe_waiter_complete(waiter, 1)`.
     - **Native retirement (`thread_control_complete_native`, `titan/thread/spawn.titan:101-109, 355`)**:
       - Even after `proxy_target` is notified, `ExternalBridge:drain()` (`titan/async.titan:1665`) on Thread B calls `retirement_poll_native` -> `thread_control_retire_native` -> `uv.native_thread_join(token)` *before* `owner:notify()` can resume the proxy Task from `ExternalWait:await(WAIT_CLEANUP)`.
       - `uv.native_thread_join(token)` blocks in the OS kernel until Thread A (`thread_worker_main`, `spawn.titan:669-671`) finishes `thread_control_complete_native` (including `rtt_probe_waiter_signal_result`), finishes `thread_control_release_native`, and exits the OS thread. Thus `rtt_probe_waiter_signal_result` strictly happens-before `rtt_probe_waiter_complete(self.native.context, 1)` via `uv_thread_join`.
---

## 4. Residual Runtime & Campaign Gates (Parent-Owned)
Source review is complete with **zero blocking harness/probe defects**. Because static source review is not runtime proof, final acceptance remains gated on the parent-owned execution steps:
1. **Candidate SDK/source freeze & common compiler verification**: Build the final candidate SDK/provider and `PROVIDER-RECEIPT.json` once `ThreadIntegration` and `Main` finalize production/test gates, confirming identical `titan-compiler/coder/{module,statements}.lua` hashes (`c324ee5d...` and `d7d735e7...`), Lua/native archives, and `PROVIDER_TITAN_CFLAGS` across `/tmp/titan-issue252-prewake-cpp2` (`final-resource`) and `wake`.
2. **Immutable harness copy & dual-lane build/smoke (`measure.py build` + `smoke`)**: Copy the 9 frozen files matching `local://issue252-final-benchmark-harness-freeze.json#782E` to `$FINAL_HARNESS`, build both `final-resource` and `wake`, run full 53-case smokes in both modes, and archive `SMOKE-RAW.json` / `SMOKE-SUMMARY.json` before full campaigns.
3. **Quiet paired campaign & audit (`compare.py`, `summarize.py`, `measure.py audit`)**: Run the quiet 53-case paired campaign (`--batches 2 --repeats 3 --instrumented-repeats 2 --seed 252`) with a dated quiescence note while all local/VM builds and tests are stopped, verify zero lifecycle/calibration/truncation/fairness-trace failures, and complete the final report and evidence archive.
4. **Independent correctness/platform gates**: Full Linux 30-root stdlib aggregate (including all 70 `thread.tests` cases), sanitizers, Windows NTFS, and local macOS gates remain separate from benchmark worker-tail quiescence.
