# Thread cutover: final pre-start admission freeze and Main-owned causal proof

## Ownership, skills, and evidence

ThreadIntegration read `titan-programmer`, `titan-thread`, `titan-async`, `titan-ffi`, and `titan-tester` before Titan source work, and additionally loaded `titan-reflect` for the erased-generic cancellation diagnosis. No builds, tests, linters, formatters, smokes, benchmark execution, commits, branch changes, or SDK/verification-copy changes were performed by this child. ABI 2 and all existing versions are unchanged.

Main explicitly opened the baseline gate after its recorded 1696-row original/resource/paired campaign. Historical baseline source/SDK/harness inputs remain untouched. The old-provider prestart proof is preserved under `/tmp/titan-issue252-retirement-before-abi2/{BEFORE-OBSERVED,SOURCE-RECEIPT}.json`. Main has now observed both the 81-case pre-admission-cutover pass and the new Map-admission failing-before/passing-after pair below; this child ran no checks.

## Current source inventory (the initial freeze is superseded)

Changed production:

- `titan/thread/thread.titan#AB39`: `waiter_wake_one`, `waiter_enqueue`, `waiter_unlink`; removed `wait_on_native_waiter` entirely; ordinary `iteration` import supports the private Group owner map.
- `titan/thread/channel.titan#FBB9`: native send/receive registrar arguments and cancellation detach; `Sender:send` at 209/223 and `Receiver:dequeue_or_wait` at 309/324 use ordinary public `async.wait_external`.
- `titan/thread/spawn.titan#6B6A`: native join/retirement and direct cancellation payload transport, plus private pre-start existing-Map admission and ctrl-owned rollback before a worker can start.
- `titan/thread/native.h#574C`: retained wake targets/joinable tokens, removed redundant os_joining, and separate request/result cancellation-kind metadata paired with their packets under the control mutex.
- `titan/thread/group.titan#EA09`: false/true/nil admission map, one memoized public `Thread:task`, native-gated idempotent accounting and explicit observation retry; passes its exact Map into private spawn and no longer inserts after OS-thread creation.

Changed behavioral regression/fixture sources:
- `spec/stdlib/titan/thread/tests/tests.titan#BE1C`: existing Group assertions unchanged; Context log regions bracket the standard public proxy's expected child-failure diagnostics. `test_receiver_close_flushes_buffer_and_wakes_senders` also brackets its expected channel-closed async Task diagnostics (BEGIN 351 / END 410), closing the remaining P3-2 report without suppression or weaker assertions.

- `spec/stdlib/titan/thread/tests/ownership_test.titan#5963`: real helper-frame ownership/GC boundaries, cycle close cases and state-local opaque-hook accounting; expected channel-closed Task diagnostics bracketed at BEGIN 1331 / END 1383. Removed only the vacuous host `ownership_decode_calls == 0` check for child lua_close; the actual child loader-alert and native exactly-once release oracles remain.
- `spec/stdlib/titan/thread/tests/wake_test.titan#7918`: wake/proxy/shutdown matrix, 23 native scenarios and all seven fixture linker wrappers, plus rich cancellation roundtrips/self-cancel precedence.
- `spec/fixtures/stdlib/native/thread_retirement_fault.c#EF1D`: real worker/OS-tail gates, public listener allocation probes, and live-exemplar metatable-scoped real Map hash-allocation rejection plus a pre-OS native-create rejection.
- `spec/fixtures/stdlib/native/thread_retirement_fault_api.h#9884`: gate/probe/fault APIs and appended Map-admission/native-create counters; existing enum values unchanged.
- `spec/fixtures/stdlib/titan/thread_retirement_fault_app.titan#155D`: prior 22 cases retained; new admission case proves no selected worker starts on Map OOM, committed membership rolls back on native-create failure, entry-packet Receiver retains release exactly once, and the Group slot/FIFO queue remain usable.

Integrator-owned dependency:

- Main added `iteration` to Unix `Makefile`'s existing `STDLIB_IMPORTS_thread` entry (`Makefile#1670`, line 423). Windows has no per-root import map and its existing source recipe compiles all 26 stdlib roots, including iteration, together; no Windows manifest edit is required. Stage the Unix manifest with this source freeze before any rebuild/snapshot.
- No production API export, public header dependency, generic async/UV/protobuf behavior, ABI or version change is introduced. The existing fixture object rule still suffices. Current consumers require seven Linux linker wrappers.
- Other required Main-owned source inputs are `titan/async.titan#4CFB` and `titan/transfer.titan#9454`: comment-only clarifications, including existing first explicit Task cancellation precedence while a success/error root outcome is pending native retirement. Main reports all four fresh-process native gate modes passed with real_join=1/terminal=1/early=0; this is not a child-executed check or a new Task behavior change.

Every consumer of the current `thread_retirement_fault.o` must pass:

```text
-Wl,--wrap=uv_thread_create,--wrap=uv_thread_join,--wrap=luaD_growstack,--wrap=luaS_newudata,--wrap=luaF_newCclosure,--wrap=luaH_set,--wrap=malloc
```

`luaF_newCclosure` and latest `luaH_set` are the added wrapper dependencies over the initial five-wrapper fixture. The permanent wake-test child compile supplies all seven. Every parent-owned normal/ASan/source-free smoke linking this current object needs them even when selecting an older scenario, because it references `__real_luaF_newCclosure` and `__real_luaH_set`. No additional permanent consumer or Makefile rule change was needed.

### Final recorded source identities

Main's complete 14-input staging receipt is `/tmp/titan-issue252-thread-map-after-validation-stage.json`. These are its recorded SHA-256 values, not recomputed child verification:

| Input | SHA-256 |
| --- | --- |
| `titan/thread/thread.titan` | `9f281a29c1408adf93ce29b716d79b581c10e994205946d8afb5cfc2da5d3a2b` |
| `titan/thread/channel.titan` | `1ac5b7e1a5fd7dc5349eb8c4742bc1564d25100214dd7abf71118929f4ff8655` |
| `titan/thread/spawn.titan` | `d06270201455d53cb292d85ebff8ca11de20f4a489e23f58303a2f5776d0e72a` |
| `titan/thread/native.h` | `c8a6ec95a0f46cbcd7a0214d17a6dfef3960bc5c4991bfd67f5823bfb37e4ae5` |
| `titan/thread/group.titan` | `d0b1c126a3e11e08def25d1673ff8ef22d2a59227f21f44110e7d6af6eb050f0` |
| `spec/stdlib/titan/thread/tests/tests.titan` | `3cac265ec8b7a8f0afe583ff727783ab296bafdf9833700171186d8bd99e4b7e` |
| `spec/stdlib/titan/thread/tests/ownership_test.titan` | `7bdefe5d57198dedf114f999af05945b9fca1487315d5d112cb540edcd62dc96` |
| `spec/stdlib/titan/thread/tests/wake_test.titan` | `6ea5545c9bdf21b964abecef84b28997850950268acf1c46a38434f0ec30bc91` |
| `spec/fixtures/stdlib/native/thread_retirement_fault.c` | `71f52e66ab1ef355a9874f067579c1745e44e8412b32ef62e4db755231e2e121` |
| `spec/fixtures/stdlib/native/thread_retirement_fault_api.h` | `ab00503c07e9cdd4ae2645b13304c7741cf83de64a9b9e5908f4d784aface662` |
| `spec/fixtures/stdlib/titan/thread_retirement_fault_app.titan` | `af86b619f0f740e849cf5a0a854afd594dbda6ed8019018bf8c9374b2f67fa88` |
| Main-owned `Makefile` | `705aa9758a9bce182d5172161417f9ef59994dfe7da95db9f8984234ab8864b2` |
| Main-owned `titan/async.titan` | `5c2343c2f2209379e4e548527533abff04840c5c3f373982a5eb12e7e2e2dcdc` |
| Main-owned `titan/transfer.titan` | `9560902120aa23dc8a38697b9453b012405652e404db2fb35e849e67778147de` |


## Shared send/receive wake ownership

`Sender:send` and `Receiver:dequeue_or_wait` preserve immediate queue attempts, then call public compiled `async.wait_external(register, unregister)`. Async performs unreferenced reserve and traced registration preparation, yields, then activates without allocation immediately before invoking the domain registrar. The registrar atomically rechecks queue readiness and links under the native channel mutex. Fast inline readiness neither links nor retains a producer target.

A linked native waiter retains `wake_target` before publication. `waiter_wake_one` unlinks FIFO, sets active=0/signaled=1, detaches its target, notifies that exact target, and releases the producer reference. `waiter_unlink` clears/releases an active target. Channel cancellation unregister retains O(1) unlink and signaled-then-cancelled baton passing, then clears signaled so repeated detach cannot pass the baton twice. Normal notification completion does not invoke unregister.

A wake reserves neither a slot nor message. Retrying Tasks can lose readiness and re-register; FIFO selection is not strict FIFO completion. Notifications carry immutable identities managed by async/UV, not remote GC objects. Domain mutex -> UV wake-core mutex remains the nested lock order.

`try_send` and `try_receive` remain nonblocking and never prepare a wait. `receive`, `receive_result`, and `incoming` share the migrated dequeue helper; all direct consuming decode stack snapshots are unchanged. The shared bridge is referenced only while active accepted waits/native barriers remain; idle reservations do not keep a Runtime alive. A sole send/receive/join wait must keep it alive through its native producer.

## Joinable token and ordinary join

`spawn_raw` now calls public `uv.create_native_thread`, commits the returned unique process-heap token to `ctrl.os_thread`, and exposes the prepared finalized Thread without a fallible post-acceptance detach call. The native worker reference and constructor's control ownership keep storage alive even if the worker finishes before token publication.

`Thread:status` is unchanged: nonblocking logical native-finished observation, potentially cached before foreign worker return/OS exit/TLS tail. It never joins.

`Thread:join` requires a Task/checkpoint, awaits logical finish through `Thread:wait_until_finished` and shared ordinary external wait, then calls the native join helper before reconstructing/returning any status. Cached, immediate-finish, suspended, repeated, normal-before-proxy and proxy-before-normal paths share `os_joined` idempotence. Direct ordinary join failure raises `OperationError` with operation `thread.join`, preserving the native token. The helper releases `ctrl.mutex` before blocking OS join; success alone clears/frees the token and sets os_joined=1. Finished readiness never regresses to pending. Host-state observers are serialized by the owning cooperative Runtime, so no duplicate joining flag is needed.

An abandoned control with no monitor may best-effort detach its unique still-owned token at native final destruction; the worker's reference pins native storage to its completion. This is abandonment policy, never proxy-join evidence or a detach fallback for failed active retirement.

## Proxy prearm, cleanup, cancellation, and negative retry

`Thread:task` memoizes one proxy. It prepares `async.prepare_native_retirement(self, ctrl, register, unregister, retire)` before constructing `async.run_with_cleanup(body, cleanup, final_wait)` with that exact capability as argument three. Generic async exclusively validates/binds/activates/registers the barrier before Task exposure. Failure before binding leaves reservation ownership with this constructor guard; protected bind/arm failure closes/unlinks its capability while the original Thread continues owning its live resource. No false proxy is returned.

The native proxy target is stored in control, not a GC/coroutine frame. Register returns 0 only after finished, 1 for a retained linked target, negative with no new admission. Worker completion commits finished under the control mutex, detaches target, then notifies/releases it. The traced owner stays live through native callback return and readiness commit; the worker reference separately protects context across source-state close.

Proxy body awaits **logical finish only** and projects the child's success/error/cancellation. It deliberately does not call normal `Thread:join`: an ordinary body join failure followed by cleanup could retry within the same driver invocation. Only the prearmed native barrier owns proxy OS-join attempts.

Cleanup installs the final capability close defer and exact `wait_cleanup` defer before ordinary cancellation forwarding. Pending host cancellation before first proxy entry still enters the cleanup wrapper. If logical finish was not reached, ordinary `Thread:cancel(reason)` attempts the exact first host reason. Accepted child cancellation is sticky; losing host reasons are not encoded. Child failures retain original error/trace; the generic wrapper traces pending original host error/first reason before fallible cleanup/status publication.

Native reasonless cancellation is allowed only when generic async invokes retirement at that bound cleanup boundary after ordinary forwarding, or while a terminal candidate cannot finish ordinary cleanup, and only if `ctrl.cancel_requested == 0` and `ctrl.status_kind == TITAN_THREAD_STATE_RUNNING` (matching ordinary cancellation's live-root admission rule). It never runs merely because prearm linked a waiter or while an ordinary body is unfinished. It never overwrites an admitted child reason or the host Task's original reason/error. Actual finished + successful OS join remains necessary on all terminal paths, including root/cleanup checked-entry failures and missed waits.

Negative retirement is a driver `OperationError` with the unchanged native code and operation `async.native_retirement.retire`. The same nonterminal Task, token/context, target registration/durable receipt, Completion/epoch and Runtime remain owned. An explicit later `async.loop()` invocation clears only the retry latch and retries that native retirement; no re-register, epoch reset, automatic retry spin or detach/false terminal occurs. This is generic async's already-authored contract, now wired to actual Thread tokens.

## Correction after Main's actual first full Thread run

Main observed provider build bg14 PASS125.43s and complete 30-root aggregate build bg16 PASS147.71s. Its bg18 Thread run selected 70 cases: 63 passed, seven failed in12.18s. The complete actual log is `local://issue252-thread-runtime-after-failures.txt` (also observed at `artifact://174`); it was not rerun to confirm. All OS-join/prestart/cache/slow/retry/wide-entry cases except three forwarding-attribution rows passed, as did both native-cycle cases and the public wake/shutdown matrix.

The three forwarding rows had real_joins=1, terminals=1, early_terminals=0 but hook=0/growth=0/allocator_hits=0/packet_copy_failures=0. Source diagnosis proved that encoding the whole generic `CancellationReason<|value|>` rejects its erased `complex(B)` descriptor (`is_value`) before entering the nested payload hook: protobuf's field encoder has no dynamic-value field case. This was a real Thread transport defect, not generic async ordering.

Current corrected transport encodes the actual simple text or complex payload with ordinary owned `transfer.encode_message`, so a complex endpoint/custom-hook payload receives the same active packet scope as every other Thread payload. Separate native `cancel_reason_kind` and `result_reason_kind` fields atomically accompany their respective packets; one phase cannot retag the other during child self-cancel/host-request races. Decoder calls remain direct at actual guarded raw slots with same-function result/error stack snapshots. An ordinary encode failure still renders the original reason under DEFAULT metadata; a second failure propagates without admission so approved native reasonless cancellation can retire the child. Empty simple text and complex nil/false stay distinct from default cancellation. No public API/export or protobuf/async expansion was added.

The child root's public `async.checkpoint()` now determines its first sticky cancellation reason even after a different host cancellation packet arrives during self-cancel cleanup; the former observed-host-reason preference is removed. New public regressions cover simple empty text, complex nil, false, endpoint attachment transport through request and result, and a later host packet whose custom decoder sends an acknowledgement before the parent's held child-cleanup gate is released.

The four other failed assertions had test causes: closed-send/raced-cancel source expressions and recursive GC roots had to leave real helper frames, and opaque-hook decoder counts belonged to the child state rather than the parent. Repairs retain meaningful release, state-local hook-count, reason and checksum assertions. The later child-close parent-only decoder-count assertion was explicitly removed as vacuous; its loader-alert and actual release checks remain.

### Main-owned observed correction evidence

- Preserved corrective pre-admission-cutover provider bg23 passed in 209.63s. Main's bg26 run passed all 81 selected Thread cases in 12.19s (`artifact://264`), covering the preserved 22-scenario fixture and earlier reason/ownership/Group corrections.
- Main preserved the pre-transaction 14-file source snapshot at `/tmp/titan-issue252-group-map-admission-before/{source,SOURCE.json}`.
- Causal BEFORE was run once against that saved SDK using the current fixture: native compile 0, Titan compile 0, run 1 at the exact invariant `Group admission OOM started an OS child before publishing its owner`; `map_admission_failures=1`, `allocator_hits=2`, `bytes=24`, `created=1`, `child_started=1`, `real_joins=0`. Receipt: `/tmp/titan-issue252-group-map-admission-before/causal-smoke-v1/BEFORE-OBSERVED.json`.
- Main's rebuilt/installed transaction provider bg27 passed in 31.78s. The same current fixture compiled native/Titan 0/0 and ran 0 with `THREAD_RETIREMENT_OK`; `map_admission_failures=1`, `allocator_hits=2`, `bytes=24`, `created=0`, `child_started=0`, `create_failures=1`. Thus both held-clone/2GC/release/2GC packet-retain oracles and subsequent held-child/FIFO assertions completed. Receipt: `/tmp/titan-issue252-group-map-admission-before/causal-after-v1/AFTER-OBSERVED.json`.
- Full post-transaction aggregate bg29 and independent sanitizer-provider refresh bg28 were still active in Main's latest report. No result for them or for the complete post-transaction suite is claimed here.


## Group ownership and two distinct negative-retirement boundaries

Main's actual failing-before Group smoke is already saved at `/tmp/titan-issue252-group-join-retry-smoke/BEFORE-OBSERVED.json`: compilation 0, run 3, one native join failure/no OS join, failed old observer at line 171, Group wait owner cancelled by idle-loop handling, completed=0, and the wrong idle driver error rather than a native `OperationError`. It was not rerun to confirm.

The final accepted Group design replaces its private active Array with `{Thread<|nil|>: boolean}`: false is admitted but observer/listener setup did not return successfully; true is observed; nil is retired. It uses exactly one memoized public `Thread:task` per member, removing the old extra observer Task. Existing FIFO admission/completion queues and their grants are unchanged. Only a terminal monitor (therefore successful native OS join) may consume membership and release a slot. The terminal helper deletes membership and installs deferred slot release before any fallible status/error projection or sibling abort; async isolates callback errors, so those errors cannot strand Group accounting.

Native child `Error` remains the collected outcome. When the child itself did not fail but the host monitor failed during ordinary entry/cleanup, that monitor's error and traceback are collected instead; no duplicate child/proxy record is added. Using the standard public proxy also makes its normal uncaught-Task failure diagnostic visible on stderr. That policy is intentional, not suppressed; the two existing public Group failure tests bracket it with Context logs and retain their assertions.

For a linked live child, a later negative OS join escapes `async.loop()` as the unchanged native driver `OperationError`; the same Task/control/token/Runtime and occupied Group slot survive. An explicit later `async.loop()` retries it. For a child already finished before proxy construction, the unchanged registrar returns ready=0 and synchronous native retirement can instead fail before any Task is exposed: `Group:spawn` propagates that original constructor error while the same Thread and its occupied slot stay false/admitted in the Group. An explicit later `Group:wait` makes one observation pass and retries setup once; it does not spin or replace any successfully memoized proxy.

`Task:add_terminal_listener` may install its callback and then fail allocating the returned remover. The false member and memoized Task remain owned. A later explicit wait first checks that same Task's terminal status and finishes inline (late public listeners are no-ops); otherwise it can install another callback. Membership `== nil` guards retire once without reinsertion. The causal real-allocator cases are included in Main's observed 81-case pre-transaction pass; all source semantics remain unchanged by the latest pre-start transaction.

The discarded alternative inline-completion Group registrar and per-member wrapper designs were not implemented. Normal native callback ready/accepted policy and its documentation stay unchanged.

## Pre-start Group admission transaction

Private `spawn_raw<R>` now takes the existing optional `{Thread<R>: boolean}` admission Map: standalone public spawn passes nil and Group passes its exact active map. It creates/finalizes the same Thread handle and prepares its owned entry packet and detached child state first. The handle's native field then points at the valid prepared control, and false membership is inserted before refcount=2 or `uv.create_native_thread`. No Map/wrapper/Task/callback abstraction is added.

The existing ctrl-owned defer removes any admission entry before clearing `handle.native`, closing the prepared child state, resetting the no-worker reference count and releasing control/entry-packet resources. Nil assignment for an absent or present key is the non-allocating raw-delete path. If native create fails after insertion, that same guard rolls membership back. A successful create commits the unique token and nulls the guarded ctrl; membership stays owned for the existing observer machinery. Group no longer has a post-start fallible insertion.

The 23rd scenario probes an ordinary public Thread-keyed Map and borrows the live exemplar's shared metatable (kept rooted to the final assertion). Its scoped `luaH_set` wrapper rejects the real first hash allocation and Lua's real emergency retry, with no guessed size/layout or private Group/Task inspection. The exemplar is separately joined before the selected failed admission. Subsequent successful slot/FIFO witnesses are ordinary unselected Group workers: the new case correctly requires selected `created=0`/`child_started=0`/`real_joins=0`, not a fake join for a worker that never started.

The same scenario then rejects a native create after membership commits, verifies its original `thread.spawn` OperationError, and uses real helper-frame Receiver/held-clone/release callbacks with 2GC/open then release/2GC/closed to prove each packet retain releases exactly once. There is no `peer_count` or new production introspection API. Public Group waits after both failures and three held/queued children prove empty ownership, reusable bounded admission and FIFO.

Standalone causal BEFORE/AFTER invocation (Main-owned workspace containing current app/API and current fixture object; choose saved BEFORE SDK or rebuilt AFTER SDK explicitly):

```sh
TITAN_EXTRA_LDFLAGS='-Wl,--wrap=uv_thread_create,--wrap=uv_thread_join,--wrap=luaD_growstack,--wrap=luaS_newudata,--wrap=luaF_newCclosure,--wrap=luaH_set,--wrap=malloc' \
  \"$SDK/bin/titanc\" --static thread_retirement_fault_app --no-uv-bootstrap -X \"$FAULT_OBJ\"
timeout --signal=KILL 45s ./thread_retirement_fault_app group-map-admission-oom
```

Both observed receipts already exist; do not rerun the failing-before case to confirm it.



## Child prestart outcome correction

The ordinary child root `async.run` can be cancelled before its first body entry. Its outcome-recording catch then never runs. After driving the child Runtime, bootstrap now consults public `root_task:status` only if control still has no recorded outcome, recording the exact accepted cancellation reason or original checked-entry failure. The worker's native fallback no longer turns that path into a generic failed Thread merely because its body was skipped.

## Regressions and attribution

The original sixteen plus two child-prestart and four Group retirement/listener cases remain. The final 23-case matrix also includes the pre-start admission transaction case:

- `child-prestart-cancel`: native entry gate holds the actual worker before child bootstrap; a distinct child cancellation is admitted first, then host proxy cancellation is requested. Public proxy stays nonterminal before release; child root body counter remains zero; admitted child/host reasons remain distinct and exact; real OS join precedes one terminal.
- `child-prestart-native-fallback`: same gate, but ordinary forwarding and its rendered fallback are causally rejected at the previously observed real packet allocator callsite. The native reasonless path cancels the not-yet-entered child while preserving exact host reason. No private Task capacity/state manipulation.
- `group-linked-join-retry`: another Group member stays blocked, both original slots remain occupied and a third admission is queued. Native cleanup is causally released, a single real-token join rejection escapes the driver, Group/controller/admission stay nonterminal without spinning, and an explicit later loop retries that same token before granting the slot.
- `group-finished-constructor-join-retry`: a test-owned native semaphore makes the actual worker callback return before `uv_thread_create` returns, while the independent witness still holds its OS exit tail. The ready=0 constructor failure is caught by the caller; another child and queued spawn prove the failed child stays admitted. Only an explicit later `Group:wait` retries setup and performs the same-token real join.
- `group-listener-return-oom`: an ordinary public `Task<nil, value>:add_terminal_listener` probe observes the actual remover CClosure allocation callsite. The selected real allocator's first try and emergency-collection retry are rejected after registration. The caller retains the original memory error; explicit wait retries while the same proxy remains live, intentionally leaving two callbacks. A second queued admission must stay blocked while the other original child and first queued child are held, proving membership/slot release occurs once.
- `group-listener-registration-oom`: the same probe observes the real TerminalRegistration userdata allocation callsite. Rejection occurs before registration. The driver subsequently joins and terminally publishes the existing linked proxy without a Group callback; both queued admissions stay blocked. Only the caller's later explicit Group wait can inspect that already-terminal memoized Task and retire the member inline. No Task capacity/state mutation or guessed allocation size is used.
- `group-map-admission-oom`: real scoped hash-allocation rejection must occur before any selected OS worker starts; a subsequent committed-map native-create rejection rolls membership/resources back. Both use original-error and exactly-once Receiver retain witnesses, followed by public empty waits and held-child/FIFO slot reuse. This is the no-start counter exception described above, not a join/terminal witness case.

The unchanged 16 are prestart, waiting, proxy-success, proxy-failure, cached-success-join, cached-failure-join, cached-cancel-join, slow-normal-join, accepted-child-reason, join-retry, prepare-userdata-oom, forwarding-stack-oom, native-fallback-copy-oom, wide-body-entry-oom, wide-cleanup-entry-oom, wide-prestart-cleanup-helper-oom.

Actual real join returns zero alone increment real_joins. Native OS EXIT tail and child cleanup remain separate gates. The new entry gate uses a dedicated native semaphore and releases during fixture cleanup; the child-started counter is separate from its native gate handshake. Same-token negative join still injects UV_EAGAIN before real join, preserving the actual pointer.

Helper-frame test repairs preserve all release/order assertions without additional collection counts or weaker oracles: dropping a source option or leaving a do block does not guarantee generated expression/capture roots are gone. Helpers return only peer/release witnesses; intentionally abandoned Thread/source endpoints/outcomes/cancellation payloads leave a real frame. Partial-adoption and duplicate endpoint tests similarly avoid keeping forced field/cast expressions in the observing frame.

Self-receiver and mutual queued-receiver tests explicitly close/drain a reachable receiver and observe packet-owned Sender EOF. They do not claim native RC cycles are automatically collectable. Existing native release/discard algorithms and last-Receiver pin were preserved; no cycle collector was added.

## Benchmark instrumentation requirements

Use final symbol/field anchors above; do not retain obsolete aliases for the frozen-v4 recipe. Old pre-yield registration attribution is invalid: `async.wait_external` registration occurs after coroutine yield, so count actual registrar/suspension causality in the private harness source. Proxy prearm is not a cleanup suspension. `final_wait:wait_cleanup` may complete inline; measure only its actual non-inline attach/yield/return. Native selected waiter notify now uses `uv.native_external_wake_notify(target)` followed by release; worker logical finish and actual token join remain distinct.

## Remaining integration gates (Main only)

Refresh isolated ABI-2 provider/aggregate/fixture outputs from these authored sources; do not reuse frozen benchmark SDKs as candidates. Recommended commands after the current-provider install:

```
make titan-stdlib-test-build
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]test_wake_prestart_and_unwinding_proxy_cancel_waits_for_worker_finish'
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]test_native_thread_retirement_exit_join_retry_and_allocation_faults'
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]test_native_endpoint_cycles_retire_through_explicit_receiver_close'
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]test_cancellation_reason_packet_roundtrips_and_self_cancel_precedence'
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]test_thread_group_limit_and_error_propagation'
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]test_group_admission_suspension_and_active_sibling_cancellation'
make titan-stdlib-test-run TITAN_FILTER='^thread[.]tests[.]'
make titan-stdlib-test-run
```

Run all 23 native child arguments through their parent filter after the canonical current-provider aggregate/fixture regeneration. Preserve all three actual failing-before proofs without confirmation reruns. Main owns completion of the post-transaction aggregate/full Thread/full mixed Linux suite, sanitizer/stress, current source-free normal/sanitized smoke, Windows NTFS, local x86_64 macOS, final native review and matched benchmark campaign. Paired docs/skills must add the pre-start admission/rollback guarantee while preserving the already aligned cancellation and Group retry/stderr policies. Main's 81-case pre-transaction pass and single causal admission AFTER pass are observed; no complete post-transaction/sanitizer/platform/campaign pass is claimed here.
