# Matched Thread RTT: measurement definitions and limits

This appendix defines the frozen final benchmark's measurements and interpretation. It is not a performance-results report. Empirical comparisons require the actual matched campaign's raw records, source/SDK receipts and quiescence evidence.

## Comparison boundary

The comparison is between the pre-wake resource-ownership snapshot and the final combined Thread implementation under the same common compiler fixes and frozen benchmark harness. It is **not a wake-only experiment**. The final intervention includes shared wake targets, actual OS join/native retirement, integration with generic async retirement, direct cancellation-payload transport with separate native request/result-kind tags, sticky child-root cancellation reasons, pre-start outcomes, and Group's memoized public proxy/owner-map design.

The final Group admission transaction is part of that intervention: private spawn receives the existing Group Map, inserts membership before OS-thread creation, and rolls membership/resources back under control ownership on failure. Standalone spawn passes nil. This does not introduce an extra Map, Task or public API. The source boundary is the final pre-start transaction in Thread receipt 0B97, not the earlier provider that passed 81 Thread cases.

Source and SDK receipts identify the measured inputs; a descriptive snapshot label is not a Git commit. ABI 2 and all existing version numbers remain unchanged. The immutable resource-v4 publication is a separate historical experiment. Its original/resource results do not supply final shared-wake results or the new admission evidence. Differences across unmatched campaigns must not be presented as a wake-only speedup.

## Timing endpoints and attribution

Ordinary request/reply RTT starts after an MPMC producer obtains its fixture permit and ends when that producer receives the reply. It excludes permit admission delay. The new request sidecar adds pre-permit and completion clocks without redefining that historical RTT metric.

`native_wake` is a causally attributed diagnostic, not the complete request/reply RTT. Its start clock immediately precedes the selected real native notification call. A usable sample requires a successful, unique, causative notification of an operation that actually suspended and completed normally. Cancelled, failed, non-unique, never-awaited or otherwise ineligible operations do not receive fabricated zero-cost wake samples.

The end-clock placement differs by wait path:

- **Ordinary waits:** after `wait_on_native_waiter` or the private wrapper around `async.wait_external` returns, **including the wait helper's defers**.
- **Cleanup joins:** at the normal **body end, before that function's own defers**, in legacy `Thread:wait_until_finished_cleanup` or native `ExternalWait:await`. Those defers include legacy `finish_handle`, or clearing `done`, clearing suspension and closing the final wait as applicable.

Thus not every endpoint is post-cleanup, and the two cleanup paths' own deferred work is not included by the same shorthand. This qualification supersedes the broader endpoint wording retained in the immutable frozen README/template/renderer. It requires no probe-code or harness-hash change.

Operation entry, initial-poll fast completion, actual suspension, selected notification and return are distinct events. A post-yield registration recheck that finds readiness is not a native suspension. A pending native waiter accepted after yield is attributed directly to its operation slot, not left in scheduler-local pending state where a sibling coroutine could inherit it. Binding a controller's primary waiter and shared target alias is not itself parking; selected native notification remains distinct from ordinary queue activity.

The start clock deliberately precedes the notification call because another OS thread can resume before that call returns. Notification success and selected-target eligibility determine usable attribution. A later post-return timestamp must not replace the causative start.

## MPMC admission and finite-run lane evidence

Both benchmark modes preallocate request timing storage before worker launch and the timed body. Every measured MPMC run writes a six-column `requests.tsv` sidecar after the body:

`request_id`, `producer`, `lane`, `permit_start_ns`, `send_start_ns`, `reply_received_ns`.

Clocks are relative to body start. Parsing requires the exact request-ID set and producer/lane partition, causal clock ordering, within-lane non-overlap, count agreement and body bounds. Missing or malformed required sidecars fail closed. Actual consumer operation counts are read after worker joins, not inferred from an intended distribution. Additional clocks/storage exist in both modes; this campaign is not claimed to be instruction-for-instruction identical to the older fixture.

The metrics remain separate:

- Admission wait: `send_start_ns - permit_start_ns`.
- Post-permit RTT: `reply_received_ns - send_start_ns`.
- Including-admission time: `reply_received_ns - permit_start_ns`.

Full lane records retain counts, first starts, last completions and inter-completion gaps. Summary diagnostics include worst-lane admission p99, worst-lane including-admission p99, maximum inter-completion gap, first-start spread and last-completion skew. Ranges retain measured rounds and batch medians. Paired changes use actual within-pair observations, not subtraction of separately pooled medians.

A lane with no completed requests is valid when the finite run has fewer requests than lanes. One completion has no inter-completion gap: it is unavailable, not zero. The fixture accepts positive producer/lane/consumer dimensions, at most 64 consumers, at most 512 producer/lane pairs and at most 1,000,000 requests.

These observations characterize a finite workload and its admission policy. They do not prove FIFO completion, a starvation bound or fairness under an unbounded competing workload. Observed consumer counts are a distribution, not a fairness theorem.

## Diagnostic interpretation and provenance

Instrumented runs expose allocation/ownership, actual UV close callbacks, successful-loop retirement, lifecycle, waiter and worker-tail diagnostics. Uninstrumented runs provide the end-to-end performance comparison. Diagnostic overhead is not production throughput; passing calibration does not prove zero measurement overhead.

A close request is not a close callback. A terminal root coroutine is not an OS join. An early proxy result is not proof of worker/native retirement. Lifecycle and tail records must be interpreted against the complete source boundary. Missing/ineligible latency observations remain unavailable rather than becoming zero-cost work.

Each private provider is rebuilt for the full official 26-root standard-library set under the recorded production compile/link policy, not a selected dependency slice. Build metadata records the ABI, provider receipt, source-probe transformations, consumer, native payload archive, Lua executable/archive, SDK content map, helper/payload hashes and tool identities. Source-probe records identify exact owners and before/after hashes, explicitly recognize the two supported wait contracts, and fail on unknown anchors instead of silently choosing another implementation.

Common reconstruction inputs contain authored source snapshots, the retained resource overlay, the exact common two-file compiler overlay, approved dependency rocks and licenses. The final candidate additionally needs its actual final production overlay and SDK receipt. A borrowed executable/SDK is not a substitute. Recorded absolute paths map to relocatable archive members without rewriting raw bytes.

## Limits

Benchmark performance and probe calibration do not replace the complete Thread behavior/fault suite, sanitizer checks, source-free SDK consumers or native Windows/macOS gates. Only integrator-exercised checks are evidence for those gates. A Linux RTT campaign alone does not establish platform-wide or complete Thread correctness.

A one-shot quiet-system observation is not CPU isolation or an exclusive reservation. Publication must preserve actual host/governor/boost and quiescence facts, paired order, repetitions, ranges and noisy or regressing rows. It must not hide regressions, mix unmatched compiler/source inputs or infer historical admission-fairness improvements where the old campaign did not record the necessary clocks.
